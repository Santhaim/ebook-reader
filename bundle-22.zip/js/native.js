// 안드로이드 껍데기(window.AndroidApp)와 이어 주는 곳 — 브라우저에서 시험할 땐 흉내만 낸다.
const A = window.AndroidApp;
export const native = !!A;
const has = (fn) => native && typeof A[fn] === 'function';

let dim = null;  // 브라우저: 밝기 = 화면을 덮는 검은 막
function dimLayer() {
  if (!dim) {
    dim = document.createElement('div');
    dim.style.cssText = 'position:fixed;inset:0;background:#000;pointer-events:none;z-index:9999;opacity:0;transition:opacity .08s';
    document.body.appendChild(dim);
  }
  return dim;
}

export const bridge = {
  // v = 0.01~1(창 밝기) · -1 = 폰 밝기로 돌려놓기
  setBrightness(v) {
    if (has('setBrightness')) A.setBrightness(v);
    else dimLayer().style.opacity = v < 0 ? 0 : String(Math.min(0.85, (1 - v) * 0.9));
  },
  getBrightness() { return has('getBrightness') ? A.getBrightness() : 0.7; },
  // 자동 밝기: 껍데기가 조도 센서로 창 밝기를 바꾼다 · factor = 끌어서 정한 배수(1 = 기본) — 껍데기 1.6부터
  canAutoBrightness() { return has('setAutoBrightness'); },
  setAutoBrightness(on, factor = 1) { if (has('setAutoBrightness')) A.setAutoBrightness(!!on, factor); },
  keepScreenOn(on) { if (has('keepScreenOn')) A.keepScreenOn(!!on); },
  setImmersive(on) { if (has('setImmersive')) A.setImmersive(!!on); },
  // 화면 회전: auto 폰 설정 따라 · portrait 세로 고정 · landscape 가로 고정 — 껍데기 1.4부터(그 전 껍데기는 설정만 기억)
  canSetOrientation() { return has('setOrientation'); },
  setOrientation(mode) { if (has('setOrientation')) A.setOrientation(mode); },
  // 읽는 동안: 껍데기가 화면 둘레를 비키지 않는다(막대가 나타나고 사라져도 쪽 크기 그대로) · 껍데기 2판부터
  setReading(on) { if (has('setReading')) A.setReading(!!on); },
  setVolumeKeys(on) { if (has('setVolumeKeys')) A.setVolumeKeys(!!on); },
  // false = 글을 고르면 안드로이드 기본 메뉴 대신 앱 단추만(읽기 화면) · true = 기본 메뉴(입력 칸)
  setNativeSelection(on) { if (has('setNativeSelection')) A.setNativeSelection(!!on); },
  setBars(color, lightIcons) { if (has('setBars')) A.setBars(color, !!lightIcons); },
  isNight() { return has('isNight') ? A.isNight() : matchMedia('(prefers-color-scheme: dark)').matches; },
  share(text, title) {
    if (has('share')) A.share(text, title || '');
    else if (navigator.share) navigator.share({ text }).catch(() => {});
    else this.copy(text);
  },
  copy(text) {
    if (has('copy')) A.copy(text);
    else navigator.clipboard?.writeText(text).catch(() => {});
  },
  saveText(name, text) {
    if (has('saveText')) { A.saveText(name, text); return; }
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([text], { type: 'text/plain;charset=utf-8' }));
    a.download = name;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 4000);
  },
  version() { return has('version') ? A.version() : 'web'; },
  // 바깥 주소는 폰 브라우저로(껍데기가 app.local 밖으로 가는 이동을 브라우저에 넘긴다)
  openUrl(url) {
    if (native) location.href = url;
    else window.open(url, '_blank');
  },
  // 받아 둔 화면 새 판으로 지금 바꾸기(껍데기 1.2부터 · 그 전 껍데기는 앱을 완전히 닫았다 열어야 바뀐다)
  canApplyUpdate() { return has('applyUpdate'); },
  applyUpdate() { if (has('applyUpdate')) A.applyUpdate(); },
  // 소리 내어 읽기: 껍데기는 안드로이드 TTS, 브라우저는 speechSynthesis
  ttsAvailable() { return has('ttsSpeak') || 'speechSynthesis' in window; },
  ttsSpeak(text, id, rate) {
    if (has('ttsSpeak')) { A.ttsSpeak(text, String(id), rate || 1); return; }
    const u = new SpeechSynthesisUtterance(text);
    u.lang = 'ko-KR';
    u.rate = rate || 1;
    u.onend = () => window.onTtsDone?.(String(id));
    speechSynthesis.speak(u);
  },
  ttsStop() {
    if (has('ttsStop')) A.ttsStop();
    else if ('speechSynthesis' in window) speechSynthesis.cancel();
  },
  // 새벽 음성(Supertonic 3 · 폰 안에서 만듦) — 껍데기 1.7부터. 파일(401MB)은 한 번 받는다
  //   voiceSpeak: 문단 하나 + 다음 문단(미리 만들기) → 첫 소리 onTtsStart(id) · 끝 onTtsDone(id) · 실패 onVoiceError(글)
  //   받기: onVoiceProgress(받음, 전체) · onVoiceDone(ok, 글)
  canVoice() { return has('voiceSpeak'); },
  voiceState() {
    if (!has('voiceState')) return null;
    try { return JSON.parse(A.voiceState()); } catch { return null; }
  },
  voiceGet() { if (has('voiceGet')) A.voiceGet(); },
  voiceCancel() { if (has('voiceCancel')) A.voiceCancel(); },
  voiceDelete() { if (has('voiceDelete')) A.voiceDelete(); },
  voiceSpeak(text, id, rate, next, voice) { if (has('voiceSpeak')) A.voiceSpeak(text, String(id), rate || 1, next || '', voice); },
};
