// 뷰어 — 권 하나를 통째로 한 흐름에 넣고, 좌우 넘기기는 CSS 단(column)으로 쪽을 나눈다.
//   자리 = { s: 장(spine) 번호, b: 장 안 문단 번호, o: 문단 안 글자 위치 } → 글자 크기·폴드를 바꿔도 같은 문장으로 돌아온다
import { db } from './db.js';
import { readEpub, mimeOf } from './epub.js';
import { settings, setSetting, readerTheme, READER_THEMES, applyAppTheme } from './settings.js';
import { bridge, native } from './native.js';
import { $, $$, esc, icon, toast, sheet, ask, pushLayer, clamp, fmtDate, actionSheet } from './ui.js';
import { byPos, volName, siblingVolume, reportText, markQuote } from './books.js';
import { reportTools, sendNow } from './library.js';
import { inboxConf, sendComment, explain } from './reports.js';
import { fixesFor, resultsByReport, resultChip, matchesReport } from './news.js';
import { makeCurl } from './curl.js';
import { spineLabels, spineNums } from './regroup.js';
import { openZoom } from './zoom.js';
import { WEB_FONTS, loadFont, fontCached } from './fonts.js';
import { diagInit, diagNote, diagOpen } from './diag.js';

const BLOCK = 'p,h1,h2,h3,h4,h5,h6,li,pre,blockquote,dt,dd,figcaption,td,th,caption';
const MARGIN = { s: 16, m: 24, l: 36 };
const FONTS = {
  serif: { name: '명조', css: '"Noto Serif CJK KR","Noto Serif KR","Source Han Serif K","Batang",serif' },
  sans: { name: '고딕', css: 'sans-serif' },
  // 받아 쓰는 글꼴(fonts.js) — 받기 전·못 받으면 뒤의 폰 글꼴로
  ridi: { name: '리디바탕', css: '"RIDIBatang","Noto Serif CJK KR","Noto Serif KR",serif' },
  maru: { name: '마루 부리', css: '"MaruBuri","Noto Serif CJK KR","Noto Serif KR",serif' },
  gowun: { name: '고운바탕', css: '"Gowun Batang","Noto Serif CJK KR","Noto Serif KR",serif' },
  pretendard: { name: '프리텐다드', css: '"Pretendard",sans-serif' },
};
const HL_COLORS = ['y', 'g', 'b', 'p'];
const NOTE_KINDS = { hl: '형광펜', memo: '메모', report: '제보', bm: '책갈피' };

let R = null;      // 지금 연 책
let H = {};        // main: onClosed(), openBook(id, opts)
let relayT = 0;
let relayForce = false;   // 크기 말고 다른 까닭(글꼴·설정)으로 다시 나누기 — 크기가 같아도 나눈다

// ---------------- 열기·닫기 ----------------
export async function openBook(id, { at = null, findText = '', findChap = '' } = {}) {
  if (R) await closeBook(true);
  const book = await db.get('books', id);
  const file = await db.get('files', id);
  if (!book || !file) { toast('책 파일이 없어요'); return false; }
  let ep;
  try {
    ep = await readEpub(await file.arrayBuffer());
  } catch (e) {
    toast('책을 열 수 없어요: ' + e.message);
    return false;
  }
  const prog = await db.get('progress', id);
  R = { id, book, ep, prog, urls: [], notes: [], ranges: new Map(), screen: 0, screens: 1, spread: 1, menu: false, pos: { s: 0, b: 0, o: 0 }, ready: false, ttsAt: prog?.tts || null };
  try {
    await build();
  } catch (e) {
    console.error('책 펼치기 실패', e);
    toast('책을 펼치지 못했어요: ' + e.message);
    R = null;
    return false;
  }
  R.ready = true;
  R.notes = await db.notesOf(id);
  book.openedAt = Date.now();
  if (!Array.isArray(book.labels)) book.labels = await spineLabels(ep);   // 화면 판 20 전에 넣은 권 — 장 이름을 채워 둔다(regroup.js)
  if (book.nums === undefined) book.nums = spineNums(ep);                // 화면 판 32 전에 넣은 권 — 원래 장 번호(없으면 null)
  db.put('books', book);

  const scr = $('#scr-reader');
  diagOpen(document.body.classList.contains('reading') ? 'next' : 'lib');
  scr.hidden = false;  // 쪽 나누기는 화면에 보여야 잴 수 있다
  // 쪽을 다 나눌 때까지는 빈 쪽만 — 글꼴·창 크기를 기다리는 동안 나누기 전 흐름(표지·목차)이 비치지 않게
  scr.classList.add('opening', 'waiting');
  scr.classList.remove('relaying');
  const me = R;
  me.opening = true;
  let settled = 0;   // 크기가 다 자리 잡았다고 본 때
  try {
    applyTheme();
    applyTypo();
    const fresh = !document.body.classList.contains('reading');   // 서재에서 들어옴(막대가 숨는 동안 크기·값이 바뀐다)
    const grow = fresh ? barsGrowth() : null;   // 껍데기가 막대 자리를 비켜 둠 → 커질 창 크기
    diagNote('grow', grow ? `${grow.w}x${grow.h}` : '-');
    enterReaderMode();
    const enteredAt = performance.now();
    const waits = [];
    // 받아 쓰는 글꼴이면 받아 둔 것을 먼저 붙인다(쪽을 그 글꼴로 나누게) — 2초 넘게 걸리면 폰 글꼴로 먼저 열고, 다 오면 쪽을 다시 나눈다
    if (WEB_FONTS[settings.font]) {
      const fid = settings.font;
      const got = loadFont(fid).then(() => true, () => false);
      waits.push(Promise.race([got, new Promise((r) => setTimeout(() => r(null), 2000))]).then((ok) => {
        if (ok === null) got.then((late) => { if (late && R && settings.font === fid) { diagNote('font-late'); relayout(); } });
      }));
    }
    // 서재에서 들어오면 껍데기가 내비 막대 자리를 거둬 창이 커진다 — 커진 뒤에 나눠야 한 번에 맞는다
    //   (전엔 작은 창으로 나눴다가 0.1~0.2초 뒤 큰 창으로 다시 나눠 아래 줄·쪽 번호가 바뀌었다 · 두 쪽 보기면 오른쪽 쪽 글이 통째로 밀림
    //    — 사용자 «앱을 키면 글자 몇 줄이 재배열될 때가 있는데» 11-07)
    //   판 47 은 «크기 알림 한 번, 없으면 0.2초»만 기다렸다 → 바쁜 폰에서 창 바꿈이 0.2초보다 늦게 오면 같은 일이 났다
    //   (사용자 «저번에 고친 글자 재배열 지금 또 그런다» 11-14) → 셈한 크기가 될 때까지(늦어도 1.5초) 기다린다
    if (grow) waits.push(windowGrown(grow, 1500));
    await Promise.all(waits);
    // 막대가 숨은 뒤에도 카메라 자리 같은 값이 늦게 오는 폰(relayout 이 배운 openMin)은 들어간 때부터 그만큼 + 조용할 때까지 더
    if (fresh && openMin > 0) { diagNote('wait-learnt', openMin); await settleUntil(enteredAt + openMin, 1500); }
    if (fresh) settled = enteredAt;
    if (R !== me) return false;
    scr.classList.remove('waiting');
    showMenu(false);
    const found = findText ? findTextPos(findText, findChap) : null;   // «클로드 답장 → 읽기 화면에서 보기»
    const start = found || at || prog?.pos || { s: 0, b: 0, o: 0 };
    repaginate(start);
    if (!found && !at && lastPage(start, prog)) goEnd();
  } finally {
    me.opening = false;
    if (!R?.opening) scr.classList.remove('opening', 'waiting');
  }
  diagNote('shown', R.screen + 1, R.screens, R.W, R.H, R.spread);
  if (settled) {   // 서재에서 들어와 보이자마자 크기가 또 바뀌면 relayout 이 이 폰의 openMin 을 늘린다
    relayShownAt = performance.now();
    relayFrom = settled;
    relayKind = 'open';
  }
  paintNotes();
  paintFixes();
  return true;
}

// 새 판에서 고친 문장 — 번역기 결과 쪽지의 after 글을 이 권에서 찾아 초록 점선(30일 동안)
//   쪽지에 장(chap)이 있으면 그 장 안에서 먼저 찾는다(«“알겠습니다.”» 같은 짧은 대사는 권 전체엔 여러 번 나온다 · 10-25 번역기 세션 질문)
function chapSections(chap) {
  if (!chap) return null;
  const num = (s) => (String(s).match(/제\s*(\d+)\s*장/) || [])[1];
  const flat = (s) => String(s).replace(/\s+/g, '');
  const n = num(chap);
  const out = new Set();
  R.sections.forEach((sec, s) => {
    const lab = R.label[s] || '';
    if (!lab) return;
    if (n ? num(lab) === n : flat(lab).startsWith(flat(chap)) || flat(chap).startsWith(flat(lab))) out.add(s);
  });
  return out.size ? out : null;
}

function findText(text, chap = '') {
  const t = (text || '').replace(/\s+/g, ' ').trim();
  if (!t) return null;
  const secs = chapSections(chap);
  const pools = secs ? [R.tb.filter((el) => secs.has(R.info.get(el).s)), R.tb] : [R.tb];
  for (const pool of pools) {
    for (const probe of [t, t.slice(0, 24)]) {
      if (probe.length < 4 && probe !== t) continue;
      for (const el of pool) {
        const i = el.textContent.indexOf(probe);
        if (i >= 0) return { el, i, len: probe === t ? t.length : Math.min(t.length, el.textContent.length - i) };
      }
    }
  }
  return null;
}

function findTextPos(text, chap = '') {
  const hit = findText(text, chap);
  if (!hit) return null;
  const info = R.info.get(hit.el);
  return { s: info.s, b: info.b, o: hit.i };
}

async function paintFixes() {
  if (!R || !window.CSS?.highlights) return;
  const book = R.book;
  const items = await fixesFor(book);
  if (!R || R.book !== book) return;
  R.fixes = [];
  for (const it of items) {
    const hit = findText(it.after, it.chap);
    if (!hit) continue;   // 아직 옛 판이면 못 찾는다 — 새 판을 받으면 보인다
    const [n1, o1] = locate(hit.el, hit.i);
    const [n2, o2] = locate(hit.el, hit.i + hit.len);
    const rg = document.createRange();
    rg.setStart(n1, o1);
    rg.setEnd(n2, o2);
    R.fixes.push({ rg, it });
  }
  CSS.highlights.set('fixed', new Highlight(...R.fixes.map((f) => f.rg)));
}

function fixAt(x, y) {
  const c = document.caretRangeFromPoint?.(x, y);
  if (!c || !R.fixes) return null;
  for (const f of R.fixes) {
    try { if (f.rg.comparePoint(c.startContainer, c.startOffset) === 0) return f; } catch {}
  }
  return null;
}

function fixPop(f, x, y) {
  const it = f.it;
  const mine = !!(it.quote || it.memo) || R.notes.some((n) => matchesReport(it, n));
  const pop = $('#note-pop');
  pop.innerHTML = `<div class="pn"><span class="fx">고친 문장 · ${fmtDate(Date.parse(it.at))} 새 판</span></div>
    ${it.before && !it.reply ? `<div class="fo">전: <s>${esc(it.before)}</s></div>` : ''}
    ${it.why || mine ? `<div class="fo">${esc(it.why || '')}${mine ? `${it.why ? ' · ' : ''}내 제보` : ''}</div>` : ''}
    ${inboxConf() ? '<div class="pb-row"><button data-a="comment">답글 달기</button></div>' : ''}`;
  R.popNote = null;
  R.popFix = it;
  R.popFn = null;
  placePop(pop, f.rg.getClientRects().length ? f.rg.getClientRects() : [{ left: x, top: y, bottom: y }]);
}

// 주석 표시(findNotes) — 작은 글이라 둘레 16px 까지 눌러도 그 표시로
function fnAt(x, y) {
  let best = null;
  let bd = 16;
  for (const f of R.fns) {
    for (const r of f.mk.getClientRects()) {
      const d = Math.hypot(Math.max(r.left - x, 0, x - r.right), Math.max(r.top - y, 0, y - r.bottom));
      if (d < bd) { bd = d; best = f; }
    }
  }
  return best;
}

function fnPop(f) {
  const pop = $('#note-pop');
  pop.innerHTML = `<div class="pn fnt"><span class="fnh">주석 ${esc(f.note.n)}</span>${esc(f.note.text)}</div><div class="pb-row"><button data-a="fn-report">제보</button></div>`;
  R.popNote = null;
  R.popFix = null;
  R.popFn = f.note;
  placePop(pop, f.mk.getClientRects());
}

// 숨긴 주석 글 안 자리(찾기 결과·메모 목록)로 가면 → 그 주석 표시가 있는 쪽으로 가서 팝업을 띄운다
function goPosNote(pos, opts) {
  const note = R.fnOf.get(blockAt(pos));
  if (!note) { goPos(pos, opts); return; }
  const mk = note.marks[0];
  goPos(posFromDom(mk, 0));
  fnPop({ mk, note });
}

// 주석 글 제보 — 흐름에선 숨겨 고를 수 없으니 설명 전체를 고른 말로
function fnReport(note) {
  const last = note.els[note.els.length - 1];
  const i1 = R.info.get(note.els[0]);
  const i2 = R.info.get(last);
  const a = { s: i1.s, b: i1.b, o: note.cut };
  const b = { s: i2.s, b: i2.b, o: last.textContent.trimEnd().length };
  editNote({ type: 'report', a, b, text: note.text.replace(/\s+/g, ' '), note: '', ctx: reportContext(a, b) }, true);
}

// 고친 문장에 답글 — 다시 제보하지 않고 클로드 답에 덧붙이는 말(우편함으로 바로)
function commentSheet(it) {
  const s = sheet({
    title: '클로드에게 답글',
    body: `<div class="quote">${esc(it.after)}${it.why ? `<div class="qhint">클로드: ${esc(it.why)}</div>` : ''}</div>
      <textarea id="nt-text" rows="4" placeholder="덧붙일 말 — 예: 조금 더 부드럽게"></textarea>
      <div class="sheet-btns"><span class="sp"></span><button class="btn" data-a="send">보내기</button></div>`,
  });
  const ta = s.body.querySelector('#nt-text');
  setTimeout(() => ta.focus(), 250);
  s.body.onclick = async (e) => {
    const btn = e.target.closest('[data-a="send"]');
    if (!btn) return;
    const text = ta.value.trim();
    if (!text) { toast('덧붙일 말을 적어 주세요'); return; }
    btn.disabled = true;
    try {
      await sendComment(it, text);
      s.close();
      toast('클로드에게 답글을 보냈어요 · 답은 서재 위 종에서', 3000);
    } catch (err) {
      btn.disabled = false;
      toast(explain(err), 3500);
    }
  };
}

export async function closeBook(switching = false) {
  if (!R) return;
  ttsStop();
  hideSelPop();
  hideNotePop();
  if (R.menu) showMenu(false);
  clearTimeout(R.saveT);
  curlDone(false);
  curl?.clear();
  await saveProgress();
  for (const u of R.urls) URL.revokeObjectURL(u);
  if (window.CSS?.highlights) CSS.highlights.clear();
  $('#rd-flow').innerHTML = '';
  $('#bk-css').textContent = '';
  diagNote('close');
  R = null;
  clearTimeout(relayT);
  relayHideAt = 0;
  relayForce = false;
  $('#scr-reader').classList.remove('relaying');
  if (!switching) exitReaderMode();
}

export const isOpen = () => !!R;
export const openId = () => R?.id || null;

function enterReaderMode() {
  document.body.classList.add('reading');
  bridge.setReading(true);
  applyBrightness();
  bridge.keepScreenOn(settings.keepOn);
  bridge.setOrientation(settings.rotate);
  bridge.setVolumeKeys(settings.volKeys);
  bridge.setNativeSelection(false);
  bridge.setImmersive(true);
}

// 서재에선 껍데기가 지금 보이는 내비 막대·카메라 구멍 자리를 비켜 웹을 줄여 두고, 읽는 동안엔 안 비킨다(MainActivity.applyPadding · 껍데기 1.1부터)
//   → 막대가 보이고(--sat 이 다 찼음) 그 자리(--sa?-max)가 있으면 읽기에 들어갈 때 창이 그만큼 커진다 — 커질 창 크기(CSS px) · 안 커지면 null
function barsGrowth() {
  if (!bridge.canSetReading()) return null;
  const cs = getComputedStyle(document.documentElement);
  const px = (k) => parseFloat(cs.getPropertyValue(k)) || 0;
  if (px('--sat') < px('--sat-max')) return null;   // 막대가 숨어 있으면 껍데기도 안 비켜 뒀다
  const dw = px('--sal-max') + px('--sar-max');
  const dh = px('--sab-max');
  if (dw <= 0 && dh <= 0) return null;
  return { from: [innerWidth, innerHeight], w: innerWidth + dw, h: innerHeight + dh };
}

// 창이 그 크기가 될 때까지(2px 안쪽) — 커지긴 했는데 셈보다 덜 컸으면 0.3초 더 안 바뀔 때 · 끝내 안 바뀌면 ms 뒤에
//   (시간이 다 되면 한 프레임 더 본다 — 바쁜 폰에선 타이머가 그 프레임의 크기 알림(resize)보다 먼저 돌 수 있다)
function windowGrown(to, ms) {
  return new Promise((done) => {
    let quiet = 0;
    const fin = () => { clearTimeout(cap); clearTimeout(quiet); removeEventListener('resize', check); done(); };
    const check = () => {
      if (innerWidth >= to.w - 2 && innerHeight >= to.h - 2) { fin(); return; }
      if (innerWidth !== to.from[0] || innerHeight !== to.from[1]) { clearTimeout(quiet); quiet = setTimeout(fin, 300); }
    };
    const cap = setTimeout(() => requestAnimationFrame(fin), ms);
    addEventListener('resize', check);
    check();
  });
}

function exitReaderMode() {
  document.body.classList.remove('reading');
  bridge.setReading(false);
  bridge.setAutoBrightness(false);
  bridge.setBrightness(-1);
  bridge.dim(1);
  bridge.keepScreenOn(false);
  bridge.setOrientation('auto');
  bridge.setVolumeKeys(false);
  bridge.setNativeSelection(true);
  bridge.setImmersive(false);
  applyAppTheme();
}

// ---------------- 본문 만들기 ----------------
async function build() {
  const flow = $('#rd-flow');
  flow.innerHTML = '';
  const cssPaths = new Set();
  const styles = [];
  const frag = document.createDocumentFragment();
  R.sections = [];
  R.fns = [];           // 주석 표시 { mk, note } (findNotes)
  R.fnOf = new Map();   // 숨긴 주석 문단 → note
  for (let i = 0; i < R.ep.spine.length; i++) {
    const ch = await R.ep.chapter(i);
    ch.css.forEach((p) => p && cssPaths.add(p));
    styles.push(...ch.styles);
    const sec = document.createElement('section');
    sec.className = ('ch ' + ch.cls).trim();
    sec.dataset.s = i;
    sec.innerHTML = ch.html;
    splitTitles(sec);
    findNotes(sec);
    if (!sec.textContent.trim() && sec.querySelector('img,svg')) sec.classList.add('imgonly');
    frag.appendChild(sec);
    R.sections.push(sec);
  }
  const end = document.createElement('div');
  end.id = 'rd-end';
  frag.appendChild(end);
  flow.appendChild(frag);

  let css = '';
  for (const p of cssPaths) css += ((await R.ep.zip.text(p)) || '') + '\n';
  $('#bk-css').textContent = scopeCss(css + styles.join('\n'));

  await Promise.all($$('[data-zip]', flow).map(async (el) => {
    const blob = await R.ep.zip.blob(el.dataset.zip, mimeOf(el.dataset.zip));
    if (!blob) return;
    const u = URL.createObjectURL(blob);
    R.urls.push(u);
    if (el.localName === 'img') {
      el.src = u;
      // 크기를 알아야 쪽을 나눌 수 있다(가려진 창에선 decode 가 늦게 끝날 수 있어 1.5초만 기다림)
      await Promise.race([el.decode().catch(() => {}), new Promise((r) => setTimeout(r, 1500))]);
    } else el.setAttribute('href', u);
  }));

  // 문단 목록(안에 다른 문단이 없는 것만) · 누적 글자 수
  R.blocks = [];
  R.secBlocks = [];
  R.info = new Map();
  R.cum = [];
  let total = 0;
  for (const sec of R.sections) {
    const s = +sec.dataset.s;
    const list = $$(BLOCK, sec).filter((el) => !el.querySelector(BLOCK));
    if (!list.length && sec.textContent.trim()) list.push(sec);
    R.secBlocks[s] = list;
    list.forEach((el, b) => {
      R.info.set(el, { g: R.blocks.length, s, b });
      R.cum.push(total);
      total += el.textContent.length;
      R.blocks.push(el);
    });
  }
  R.total = Math.max(1, total);
  // 자리 찾기(이분 탐색)는 글자가 있는 문단만 — 빈 줄(p.blank)·숨긴 주석(.rd-fnb)은 상자가 없어 순서를 흐린다
  R.tb = R.blocks.filter((el) => /\S/.test(el.textContent) && !isFnb(el));

  // 장 이름: 목차 → 없으면 장 첫 제목
  R.label = [];
  let last = '';
  for (let i = 0; i < R.sections.length; i++) {
    const t = R.ep.toc.filter((x) => x.s === i)[0];
    if (t) last = t.label;
    else if (!R.ep.toc.length) last = R.sections[i].querySelector('h1,h2,h3')?.textContent.trim() || last;
    R.label[i] = last;
  }
  addTocPage();
}

// 긴 장 제목은 «제N장» / 제목 두 줄로 — 제목을 한 덩이(.rd-ht · inline-block)로 싸 두면 한 줄에 다 안 들어갈 때만 통째로 다음 줄로 간다
//   (전엔 제목 가운데에서 꺾였다 — 사용자 «제목이 너무 길면 처음부터 두 줄로» 10-31) · 글만 든 제목만 · 글자는 빈칸까지 그대로(장 이름·자리 셈은 textContent)
const TITLE_NO = /^\s*제\s?\d[\d,]*\s?[장화회절편부권막]\s+(?=\S)/;
function splitTitles(sec) {
  for (const h of sec.querySelectorAll('h1,h2,h3')) {
    const t = h.firstChild;
    if (h.childNodes.length !== 1 || t.nodeType !== 3) continue;
    const m = TITLE_NO.exec(t.data);
    if (!m) continue;
    const ht = document.createElement('span');
    ht.className = 'rd-ht';
    ht.append(t.splitText(m[0].length));
    h.append(ht);
  }
}

// 주석 — 본문 «(주1)»·«(주석 1)» 을 누르면 장 끝 «주1: …»·«주석 1: …» 설명을 팝업으로(사용자 «가끔 주석 달릴 때가 있는데 팝업식으로» 11-01)
//   표시는 작게 위로(span.rd-fn) · 짝 지은 장 끝 설명과 그 뒤에 이어진 글·빈 줄은 흐름에서 숨긴다(.rd-fnb — 팝업·찾기·제보로만)
//   글자는 하나도 안 바꾼다(감싸고 숨기기만 → 문단 번호·글자 자리·장 이름 그대로) · 표시가 빠진 설명·설명이 없는 표시는 그대로 둔다
const FN_MARK = /[(（]\s*주(?:석)?\s?(\d{1,2})\s*[)）]/g;
const FN_BODY = /^\s*(?:[(（]\s*)?주(?:석)?\s?(\d{1,2})\s*(?:[)）]\s*[:：.]?|[:：.])\s*/;
const isFnb = (el) => el.classList.contains('rd-fnb');
function findNotes(sec) {
  const list = $$(BLOCK, sec).filter((el) => !el.querySelector(BLOCK));
  const head = (el) => /^H[1-6]$/.test(el.tagName);
  const bodies = [];
  list.forEach((el, i) => {
    const m = !head(el) && FN_BODY.exec(el.textContent);
    if (m) bodies.push({ i, n: m[1], cut: m[0].length });
  });
  if (!bodies.length) return;
  // 표시 → 그 뒤에 오는 첫 같은 번호 설명
  const marks = [];
  list.forEach((el, i) => {
    if (head(el) || bodies.some((b) => b.i === i)) return;
    for (const [t] of textNodes(el)) {
      for (const m of t.data.matchAll(FN_MARK)) {
        const body = bodies.find((b) => b.i > i && b.n === m[1]);
        if (body) marks.push({ t, at: m.index, len: m[0].length, body });
      }
    }
  });
  if (!marks.length) return;
  const notes = new Map();
  for (const body of new Set(marks.map((m) => m.body))) {
    const els = [list[body.i]];
    const blank = [];
    for (let j = body.i + 1; j < list.length && !head(list[j]) && !bodies.some((b) => b.i === j); j++) {
      (/\S/.test(list[j].textContent) ? els : blank).push(list[j]);   // 설명 뒤에 이어진 글(25권처럼 둘로 나뉜 설명)
    }
    const text = [els[0].textContent.slice(body.cut), ...els.slice(1).map((el) => el.textContent)].map((s) => s.trim()).filter(Boolean).join('\n');
    const note = { n: body.n, cut: body.cut, els, text, marks: [] };
    notes.set(body, note);
    for (const el of [...els, ...blank]) el.classList.add('rd-fnb');
    for (const el of els) R.fnOf.set(el, note);
  }
  // 뒤에서부터 감싼다(한 글 마디 안 앞 표시의 자리가 안 밀리게)
  const found = [];
  for (const m of marks.reverse()) {
    const mid = m.t.splitText(m.at);
    mid.splitText(m.len);
    const mk = document.createElement('span');
    mk.className = 'rd-fn';
    mid.before(mk);
    mk.append(mid);
    const note = notes.get(m.body);
    note.marks.unshift(mk);
    found.unshift({ mk, note });
  }
  R.fns.push(...found);
}

// 책의 CSS 는 .bk 안에서만 먹게 선택자 앞에 붙인다(body → 장 section)
function scopeCss(text) {
  try {
    const sh = new CSSStyleSheet();
    sh.replaceSync(text);
    return [...sh.cssRules].map(scopeRule).join('\n');
  } catch {
    return '';
  }
}
function scopeRule(rule) {
  if (rule instanceof CSSStyleRule) {
    const sel = rule.selectorText.split(',').map((s) => {
      s = s.trim().replace(/^(html|:root)\b\s*/, '');
      if (!s) return '.bk';
      return /^body\b/.test(s) ? '.bk section.ch' + s.slice(4) : '.bk ' + s;
    }).join(', ');
    return `${sel} { ${rule.style.cssText} }`;
  }
  if (rule instanceof CSSMediaRule) return `@media ${rule.conditionText} { ${[...rule.cssRules].map(scopeRule).join('\n')} }`;
  return '';
}

// ---------------- 모양 ----------------
function applyTypo() {
  const st = $('#scr-reader').style;
  st.setProperty('--fs', settings.fs + 'px');
  st.setProperty('--lh', settings.lh);
  st.setProperty('--pm', settings.pm + 'em');
  st.setProperty('--ti', settings.indent ? '1em' : '0');
  st.setProperty('--ta', settings.justify ? 'justify' : 'start');
  st.setProperty('--font', (FONTS[settings.font] || FONTS.serif).css);
}

function applyTheme() {
  const t = readerTheme();
  const el = $('#scr-reader');
  el.dataset.rt = t.key;
  el.classList.toggle('rdark', t.dark);
  el.style.setProperty('--rbg', t.bg);
  el.style.setProperty('--rink', t.ink);
  el.style.setProperty('--rsub', t.sub);
  bridge.setBars(t.bg, !t.dark);
}

function layout(keepCurl = false) {
  if (!R) return;
  const view = $('#rd-view');
  const flow = $('#rd-flow');
  const W = view.clientWidth;
  const Hh = view.clientHeight;
  if (!W || !Hh) return;
  if (!keepCurl) {   // keepCurl = 넘기기 시작에 끊어 둔 곳을 거둘 때(curlBegin) — 다시 나누기 전에 떠 둔 지금 쪽 사본은 그대로 쓴다
    curlDone(false);
    curl?.clear();   // 종이책 넘김의 쪽 사본은 쪽을 새로 나누면 다시 만든다(R.gen)
  }
  R.gen = (R.gen || 0) + 1;
  const m = MARGIN[settings.margin] || 24;
  R.W = W;
  R.H = Hh;
  diagNote('layout', W, Hh);
  flow.style.setProperty('--ph', Hh + 'px');
  const reader = $('#scr-reader');
  if (settings.mode === 'scroll') {
    R.scroll = true;
    R.tocCol = null;
    R.spread = 1;
    view.classList.add('scroll');
    reader.classList.remove('two');
    Object.assign(flow.style, { left: '', width: '', height: '', columnCount: '', columnGap: '', transform: '', transition: '', padding: `0 ${m}px 40px` });
    reader.style.setProperty('--mx', m + 'px');
    return;
  }
  R.scroll = false;
  view.classList.remove('scroll');
  view.scrollTop = 0;
  // 넓은 화면(폴드를 폈을 때·가로 폰)은 두 쪽 — 가운데 접는 선 둘레는 비운다
  const two = settings.spread === 'auto' && W >= 600 && W / Hh >= 0.75;
  const spread = two ? 2 : 1;
  const gap = two ? Math.max(2 * m, 56) : 2 * m;
  const cw = Math.floor((W - 2 * m - (spread - 1) * gap) / spread);
  const used = spread * cw + (spread - 1) * gap;
  const left = (W - used) / 2;
  Object.assign(flow.style, {
    left: left + 'px', width: used + 'px', height: Hh + 'px', padding: '0',
    columnCount: String(spread), columnGap: gap + 'px', transition: 'none', transform: 'translateX(0)',
  });
  Object.assign(R, { spread, gap, cw, pitch: cw + gap, left });
  reader.style.setProperty('--mx', left + 'px');
  reader.classList.toggle('two', two);
  const fl = flow.getBoundingClientRect().left;
  R.columns = Math.max(1, Math.floor(($('#rd-end').getBoundingClientRect().left - fl + 1) / R.pitch) + 1);
  R.screens = Math.ceil(R.columns / spread);
  const colOfEl = (el) => {
    const r = el?.getClientRects()[0];
    return r ? Math.floor((r.left - fl + 1) / R.pitch) : -1;
  };
  R.secCol = R.sections.map((sec) => Math.max(0, colOfEl(sec)));
  // 흐름의 덩어리(장·목차 쪽)마다 시작 단 — 덩어리는 늘 새 단에서 시작한다(종이책 넘김이 그 쪽이 든 덩어리만 복사)
  R.kids = [...flow.children].filter((el) => el.id !== 'rd-end');
  let last = 0;
  R.kidCol = R.kids.map((el) => (last = Math.max(last, colOfEl(el))));
  const ti = R.kids.findIndex((el) => el.classList.contains('rd-toc'));
  R.tocCol = ti < 0 ? null : [R.kidCol[ti], (R.kidCol[ti + 1] ?? R.columns) - 1];
  if (ti >= 0) {
    // 목차 쪽 번호 = 아래 쪽 표시와 같은 셈(두 쪽 보기면 단 번호) — 다 잰 뒤에 한꺼번에 쓴다(쓰고 재고를 섞으면 매번 다시 나눈다)
    const items = $$('.rd-toc-it', R.kids[ti]);
    const nums = items.map((it) => {
      const sec = R.sections[+it.dataset.s];
      const c = colOfEl((it.dataset.frag && sec?.querySelector('#' + CSS.escape(it.dataset.frag))) || sec);
      return c < 0 ? '' : String(c + 1);
    });
    items.forEach((it, i) => { const n = it.lastElementChild; if (n.textContent !== nums[i]) n.textContent = nums[i]; });
  }
}

// 글자 크기·폴드·회전이 바뀌면 같은 문장으로 돌아간다(R.pos 는 그대로 — 여러 번 바꿔도 밀리지 않게)
//   sized = 창·쪽 칸 크기 알림(ResizeObserver·resize) — 지난번에 나눈 크기 그대로면 안 나눈다(읽기 화면이 처음 보일 때 오는
//   0 → 크기 알림에 열자마자 권 전체를 한 번 더 나누고 있었다) · 여는 중(R.opening)엔 openBook 이 다 기다린 뒤에 나눈다
//   창·쪽 칸 크기가 바뀌면(폴드 펴고 접기·돌리기·다른 화면에서 다시 켜기) 다 자리 잡을 때까지 글을 가렸다가 한 번에 보인다 — 전엔 옛 쪽이
//   새 창에 어긋난 채 0.1초 넘게 비치다가 다시 나뉘었고, 카메라 자리·막대 값이 따로 늦게 오면 한 번 더 나뉘었다
//   (사용자 «폴드5 펼쳐보니 여전히 재배열 뜸 · 펼친거 닫고 다시 앱 들어가면 또 글자 재배열 보인다» 11-14) → 가린 동안엔 마지막 크기 알림 뒤
//   0.16초 조용할 때까지 모아서 한 번에(늦어도 가린 지 1.2초) · 안 가린 다시 나누기(글자 크기 같은 설정)는 예전처럼 0.09초
//   다시 보인 지 1초 안에 또 바뀌면(카메라 자리·막대 값이 늦게 오는 폰) 그 폰은 다음부터 «그만큼은 늘 가린다»(이 폰에 적어 둠 · 1초까지)
//   — 펴고 접기(relayMin · 가린 때부터)와 책 열기(openMin · 읽기 화면에 들어간 때부터)를 따로 배운다
const learnt = (k) => { try { return Math.min(1000, Math.max(0, +localStorage.getItem(k) || 0)); } catch { return 0; } };
let relayMin = learnt('ebook.relayMin');
let openMin = learnt('ebook.openMin');
let relayHideAt = 0;      // 글을 가린 때(0 = 안 가림)
let relayShownAt = -1e9;  // 마지막으로 다시 보인 때(책을 열어 보인 때도)
let relayFrom = 0;        // 그 덩이의 시작(가린 때 · 책 열기면 읽기 화면에 들어간 때)
let relayKind = '';       // 그 덩이가 size(펴고 접기 등)인가 open(책 열기)인가
function learnLate(now) {
  const need = Math.min(1000, Math.round(now - relayFrom) + 60);
  const key = relayKind === 'open' ? 'ebook.openMin' : 'ebook.relayMin';
  if (relayKind === 'open') openMin = Math.max(openMin, need);
  else relayMin = Math.max(relayMin, need);
  try { localStorage.setItem(key, String(relayKind === 'open' ? openMin : relayMin)); } catch { /* 이번만 */ }
  diagNote('learn', relayKind, need);
}
function relayout(sized = false) {
  if (!sized) relayForce = true;
  const scr = $('#scr-reader');
  const now = performance.now();
  if (sized && R && !R.opening && !relayHideAt) {
    const v = $('#rd-view');
    if (v.clientWidth !== R.W || v.clientHeight !== R.H) {
      // 배우는 건 작은 늦은 값(카메라 자리·막대 · 100px 안)만 — 보이자마자 돌리거나 자판을 연 건 그 폰의 버릇이 아니다
      if (now - relayShownAt < 1000 && Math.abs(v.clientWidth - R.W) < 100 && Math.abs(v.clientHeight - R.H) < 100) learnLate(now);
      relayHideAt = now;
      R.relaying = true;
      scr.classList.add('relaying');
      diagNote('hide', v.clientWidth, v.clientHeight);
    }
  }
  clearTimeout(relayT);
  const wait = relayHideAt ? Math.max(0, Math.min(Math.max(160, relayHideAt + relayMin - now), relayHideAt + 1200 - now)) : 90;
  relayT = setTimeout(() => {
    const force = relayForce;
    relayForce = false;
    const from = relayHideAt;
    relayHideAt = 0;
    try {
      if (!R || R.opening) return;
      const v = $('#rd-view');
      if (!force && v.clientWidth === R.W && v.clientHeight === R.H) return;
      diagNote('relayout', force ? 'force' : 'size');
      repaginate(R.pos);
      if (R.menu) updateInfo();
    } finally {
      if (R) R.relaying = false;
      if (from) {
        scr.classList.remove('relaying');
        relayShownAt = performance.now();
        relayFrom = from;
        relayKind = 'size';
        diagNote('show');
      }
    }
  }, wait);
}

// 책을 열 때 배운 시간(읽기 화면에 들어간 때부터)까지 기다린 뒤, 크기 알림이 0.08초 없을 때까지(늦어도 cap)
function settleUntil(at, cap) {
  return new Promise((done) => {
    const v = $('#rd-view');
    let t = 0;
    const arm = (ms) => { clearTimeout(t); t = setTimeout(fin, Math.max(ms, at - performance.now())); };
    const ro = new ResizeObserver(() => arm(80));
    const fin = () => { clearTimeout(t); clearTimeout(c); ro.disconnect(); removeEventListener('resize', poke); done(); };
    const poke = () => arm(80);
    const c = setTimeout(fin, cap);
    addEventListener('resize', poke);
    ro.observe(v);
    arm(80);
  });
}

// 쪽을 새로 나누면 쪽 경계가 처음부터 다시 정해져서, 읽던 문장이 새 쪽 한가운데(두 쪽이면 오른쪽 쪽 아래)에
// 놓일 수 있다 — 폴드를 펴면 이미 읽은 글이 1~2쪽 다시 보였다(10-25 제보). 그래서 읽던 문장 바로 앞에서
// 단을 끊어 그 문장이 쪽(두 쪽이면 왼쪽 쪽) 맨 위에 오게 한다. 끊는 곳은 하나만 두고, 다음에 다시 나눌 때 옮긴다.
//   끊은 곳 바로 앞 쪽은 덜 차고(두 쪽이면 빈 쪽도 하나) — 그쪽으로 돌아가면 끊은 곳을 거두고 원래대로 다시 나눈다(healAnchor ·
//   사용자 «폴드 두 쪽 보기에서 쪽 중간에 글이 끊기고 오른쪽 쪽이 통째로 빔 · 껐다 켜도 똑같네» 10-31)
function repaginate(pos) {
  placeAnchor(pos);
  layout();
  if (fixParity()) layout();
  goPos(pos, { keep: true });
}

function clearAnchor() {
  const flow = $('#rd-flow');
  for (const el of $$('.rd-anchor', flow)) el.classList.remove('rd-anchor');
  for (const el of $$('.rd-brk,.rd-pad', flow)) {
    const parent = el.parentNode;
    el.remove();
    parent.normalize();
  }
  R.anchorEl = null;
}

function placeAnchor(pos) {
  clearAnchor();
  if (settings.mode === 'scroll' || !pos) return;
  const el = blockAt(pos);
  if (!el || isFnb(el) || (pos.o <= 0 && pos.b <= 0)) return;  // 장 첫머리는 원래 새 쪽 · 숨긴 주석 안 자리는 그 장 끝 쪽(rectOfPos)
  if (pos.o <= 0) {
    el.classList.add('rd-anchor');
    R.anchorEl = el;
    return;
  }
  const [node, off] = locate(el, pos.o);
  if (node.nodeType !== 3) {
    el.classList.add('rd-anchor');
    R.anchorEl = el;
    return;
  }
  const br = document.createElement('span');
  br.className = 'rd-brk';
  const fn = node.parentElement.closest('.rd-fn');
  if (fn) fn.before(br);   // 쪽이 주석 표시에서 시작하면 그 표시 앞에서 끊는다(작게 올린 글 안에 끊는 곳을 넣지 않게)
  else {
    const rg = document.createRange();
    rg.setStart(node, off);
    rg.collapse(true);
    rg.insertNode(br);
  }
  R.anchorEl = br;
}

// 두 쪽 보기에서 읽던 문장이 오른쪽 쪽에 섰으면 빈 쪽 하나를 넣어 왼쪽 쪽으로 보낸다
function fixParity() {
  if (R.scroll || R.spread !== 2 || !R.anchorEl) return false;
  const r = R.anchorEl.getClientRects()[0];
  if (!r || colOf(r.left) % 2 === 0) return false;
  const pad = document.createElement(R.anchorEl.classList.contains('rd-brk') ? 'span' : 'div');
  pad.className = 'rd-pad';
  R.anchorEl.before(pad);
  return true;
}

// 끊어 둔 곳이 선 화면(없으면 -1) — 그 앞 화면엔 덜 찬 쪽·빈 쪽이 있을 수 있다
function anchorScreen() {
  if (!R?.anchorEl || R.scroll) return -1;
  const r = R.anchorEl.getClientRects()[0];
  return r ? Math.floor(colOf(r.left) / R.spread) : -1;
}

// 끊어 둔 곳을 거두고 원래대로 다시 나눈다 — 그 앞 화면들은 번호도 글도 그대로고, 덜 찼던 쪽만 뒤 글로 마저 찬다
//   (끊은 곳 앞 글은 처음부터 원래대로 흘렀으니 덜 찬 쪽의 첫 글자까지는 쪽 경계가 같다) → 부른 쪽이 같은 화면 번호로 setScreen
function healAnchor(keepCurl = false) {
  clearAnchor();
  layout(keepCurl);
}

// ---------------- 자리 계산 ----------------
function blockAt(pos) {
  const list = R.secBlocks[pos?.s];
  if (!list || !list.length) return null;
  return list[clamp(pos.b, 0, list.length - 1)];
}

function textNodes(el) {
  const out = [];
  const w = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
  let n;
  let acc = 0;
  while ((n = w.nextNode())) { out.push([n, acc]); acc += n.data.length; }
  return out;
}

function locate(el, offset) {
  let last = null;
  for (const [n, base] of textNodes(el)) {
    if (offset < base + n.data.length) return [n, Math.max(0, offset - base)];
    last = n;
  }
  return last ? [last, last.data.length] : [el, 0];
}

function posFromDom(node, off) {
  let el = node.nodeType === 3 ? node.parentElement : node;
  let blk = el;
  while (blk && !R.info.has(blk)) blk = blk.parentElement;
  if (!blk) {
    const sec = el?.closest?.('section.ch') || R.sections[0];
    const s = +sec.dataset.s;
    const list = R.secBlocks[s] || [];
    const next = list.find((b) => node.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING);
    if (next) { const i = R.info.get(next); return { s: i.s, b: i.b, o: 0 }; }
    return { s, b: Math.max(0, list.length - 1), o: 0 };
  }
  const i = R.info.get(blk);
  const rg = document.createRange();
  rg.setStart(blk, 0);
  try { rg.setEnd(node, off); } catch { return { s: i.s, b: i.b, o: 0 }; }
  return { s: i.s, b: i.b, o: rg.toString().length };
}

// 숨긴 주석 글(.rd-fnb) 안 자리(옛 판에서 장 끝 주석을 읽던 자리·그 글의 메모) → 그 앞 보이는 글의 끝 = 그 장 끝 쪽
function seen(pos) {
  const el = blockAt(pos);
  if (!el || !isFnb(el)) return pos;
  const list = R.secBlocks[pos.s];
  for (let b = R.info.get(el).b - 1; b >= 0; b--) {
    const t = list[b].textContent.trimEnd();
    if (/\S/.test(t) && !isFnb(list[b])) return { s: pos.s, b, o: t.length - 1 };
  }
  return { s: pos.s, b: 0, o: 0 };
}

function rectOfPos(pos) {
  if (pos?.toc) {
    const r = $('.rd-toc', $('#rd-flow'))?.getClientRects()[0];
    if (r) return r;
  }
  pos = seen(pos);
  const el = blockAt(pos);
  if (!el) return R.sections[clamp(pos?.s ?? 0, 0, R.sections.length - 1)]?.getClientRects()[0] || null;
  const [node, off] = locate(el, pos.o);
  if (node.nodeType === 3 && node.data.length) {
    const rg = document.createRange();
    const o = Math.min(off, node.data.length - 1);
    rg.setStart(node, o);
    rg.setEnd(node, o + 1);
    const rs = rg.getClientRects();
    if (rs.length) return rs[0];
  }
  return el.getClientRects()[0] || null;
}

function colOf(x) {
  return Math.floor((x - $('#rd-flow').getBoundingClientRect().left + 1) / R.pitch);
}

function screenOf(pos) {
  if (pos?.toc && R.tocCol) return clamp(Math.floor(R.tocCol[0] / R.spread), 0, R.screens - 1);
  const r = rectOfPos(pos);
  return r ? clamp(Math.floor(colOf(r.left) / R.spread), 0, R.screens - 1) : 0;
}

function gIndex(pos) {
  const el = blockAt(pos);
  if (el) return R.info.get(el).g;
  const later = R.blocks.find((b) => R.info.get(b).s >= (pos?.s ?? 0));
  return later ? R.info.get(later).g : R.blocks.length;
}

function pctOf(pos) {
  const g = gIndex(pos);
  const base = g < R.cum.length ? R.cum[g] : R.total;
  return clamp(((base + (blockAt(pos) ? pos.o : 0)) / R.total) * 100, 0, 100);
}

// 이 쪽(화면)의 첫 글자 자리 — 목차 쪽이면 { toc: 1 }(s 는 목차 다음 장: 읽은 % 셈용)
function posAtScreen(n) {
  const B = R.tb;
  const c0 = n * R.spread;
  if (R.tocCol && c0 >= R.tocCol[0] && c0 <= R.tocCol[1]) return { s: R.tocS, b: 0, o: 0, toc: 1 };
  if (!B.length) return { s: 0, b: 0, o: 0 };
  const fl = $('#rd-flow').getBoundingClientRect().left;
  const col = (x) => Math.floor((x - fl + 1) / R.pitch);
  const rg = document.createRange();
  const lastCol = (el) => {
    rg.selectNodeContents(el);
    const rs = rg.getClientRects();
    return rs.length ? col(rs[rs.length - 1].left) : -1;
  };
  let lo = 0;
  let hi = B.length - 1;
  let ans = B.length - 1;
  while (lo <= hi) {
    const mid = (lo + hi) >> 1;
    if (lastCol(B[mid]) >= c0) { ans = mid; hi = mid - 1; } else lo = mid + 1;
  }
  const el = B[ans];
  const info = R.info.get(el);
  rg.selectNodeContents(el);
  const first = rg.getClientRects()[0];
  if (!first || col(first.left) >= c0) {
    // 문단이 이 쪽에서 시작 — 앞에 그림만 있는 장(표지)이면 그 장을 가리킨다
    const sc = R.secCol?.findLastIndex?.((c) => c <= c0) ?? -1;
    if (sc >= 0 && sc < info.s && R.sections[sc].classList.contains('imgonly')) return { s: sc, b: 0, o: 0 };
    return { s: info.s, b: info.b, o: 0 };
  }
  return { s: info.s, b: info.b, o: charWhere(el, (r) => col(r.left) >= c0) };
}

// 조건을 처음 만족하는 글자(이분 탐색 — 글자 순서대로 단·줄이 늘어난다)
function charWhere(el, ok) {
  const nodes = textNodes(el);
  const total = nodes.length ? nodes[nodes.length - 1][1] + nodes[nodes.length - 1][0].data.length : 0;
  const rg = document.createRange();
  const test = (k) => {
    let i = nodes.length - 1;
    while (i > 0 && nodes[i][1] > k) i--;
    const [n, base] = nodes[i];
    const o = Math.min(k - base, n.data.length - 1);
    rg.setStart(n, o);
    rg.setEnd(n, o + 1);
    const r = rg.getClientRects()[0];
    return r ? ok(r) : false;
  };
  let lo = 0;
  let hi = total - 1;
  let ans = 0;
  while (lo <= hi) {
    const mid = (lo + hi) >> 1;
    if (test(mid)) { ans = mid; hi = mid - 1; } else lo = mid + 1;
  }
  return ans;
}

// 스크롤 보기: 화면 맨 위 글자
function posAtScroll() {
  const B = R.tb;
  if (!B.length) return { s: 0, b: 0, o: 0 };
  const top = $('#rd-view').getBoundingClientRect().top + 2;
  const rg = document.createRange();
  let lo = 0;
  let hi = B.length - 1;
  let ans = B.length - 1;
  while (lo <= hi) {
    const mid = (lo + hi) >> 1;
    rg.selectNodeContents(B[mid]);
    const rs = rg.getClientRects();
    if (rs.length && rs[rs.length - 1].bottom > top) { ans = mid; hi = mid - 1; } else lo = mid + 1;
  }
  const el = B[ans];
  const info = R.info.get(el);
  rg.selectNodeContents(el);
  const first = rg.getClientRects()[0];
  if (!first || first.top >= top) return { s: info.s, b: info.b, o: 0 };
  return { s: info.s, b: info.b, o: charWhere(el, (r) => r.top >= top - 1) };
}

// ---------------- 움직이기 ----------------
function setScreen(n, anim) {
  curlDone(false);   // 넘기던 장은 접고(쪽 이동·듣기·밀대가 먼저)
  R.screen = clamp(n, 0, R.screens - 1);
  const flow = $('#rd-flow');
  flow.style.transition = anim && settings.anim === 'slide' ? 'transform .26s cubic-bezier(.2,.7,.3,1)' : 'none';
  flow.style.transform = `translateX(${-R.screen * R.spread * R.pitch}px)`;
}

// keep = 쪽을 다시 나눈 뒤(기준 문장 그대로) · 아니면(목차·검색·메모로 이동) 그 쪽의 첫 글자를 새 기준으로
function goPos(pos, { flash = null, keep = false } = {}) {
  if (!R) return;
  const p = pos && R.sections[pos.s] ? pos : { s: 0, b: 0, o: 0 };
  if (R.scroll) {
    const view = $('#rd-view');
    const r = rectOfPos(p);
    if (r) view.scrollTop += r.top - view.getBoundingClientRect().top - (p.o ? 6 : 0);
    R.pos = p;
  } else {
    if (!keep && screenOf(p) < anchorScreen()) healAnchor();   // 끊어 둔 곳 앞으로 가면 원래대로 다시 나눈 뒤에
    setScreen(screenOf(p), false);
    R.pos = keep ? p : posAtScreen(R.screen);
  }
  if (flash) flashRange(flash);
  afterMove(!keep);
}

function atEnd() {
  if (R.scroll) {
    const v = $('#rd-view');
    return v.scrollTop + v.clientHeight >= v.scrollHeight - 4;
  }
  return R.screen >= R.screens - 1;
}

// 다 읽은 권을 새 판으로 바꿔 끼우면 그 권 자리는 «마지막 쪽»(pos.end · regroup.js) — 열면 맨 끝 쪽으로
//   화면 판 34까지 바꿔 끼운 권은 마지막 장 첫머리로 적혔다(end 없음 · 장 하나만큼 앞 — 사용자 «판이 바뀌면 다 읽은 거 들어가도 9쪽 정도 앞쪽» 10-31)
//   → 다 읽은 권이 마지막 장 첫머리에 있으면 그것도 마지막 쪽으로
function lastPage(pos, prog) {
  return !!pos.end || (!!prog?.done && !pos.toc && !pos.b && !pos.o && pos.s === R.sections.length - 1);
}

function goEnd() {
  if (R.scroll) {
    const v = $('#rd-view');
    v.scrollTop = v.scrollHeight;
    R.pos = posAtScroll();
  } else {
    setScreen(R.screens - 1, false);
    R.pos = posAtScreen(R.screen);
  }
  afterMove(false);
}

function turn(dir) {
  // 여는 중(빈 쪽 · 쪽을 아직 안 나눔)에 볼륨키·방향키가 오면 «권 끝»으로 칠 수 있다 · 창이 바뀌어 글을 가린 동안은 옛 쪽 자리로 셈하게 된다
  if (!R || R.opening || R.relaying) return;
  diagNote('turn', dir);
  hideNotePop();
  if (R.scroll) {
    const v = $('#rd-view');
    if (dir > 0 && atEnd()) { endOfBook(); return; }
    v.scrollBy({ top: dir * (v.clientHeight - 48), behavior: settings.anim === 'slide' ? 'smooth' : 'auto' });
    return;
  }
  curlFinish();   // 넘어가던 장은 다 넘기고 다음으로
  const n = R.screen + dir;
  if (n < 0) { setScreen(0, true); startOfBook(); return; }
  if (n >= R.screens) { setScreen(R.screen, true); endOfBook(); return; }
  if (settings.anim === 'curl' && curlBegin(dir)) {
    curlRun(1, R.spread === 2 ? 620 : 500, easeInOut);
    return;
  }
  const heal = n < anchorScreen();
  if (heal) healAnchor();   // 끊어 둔 곳 앞 쪽 — 원래대로 다시 나눠 같은 번호 화면으로(밀기 효과 없이)
  setScreen(n, !heal);
  R.pos = posAtScreen(n);
  afterMove();
}

async function endOfBook() {
  R.prog = { ...(R.prog || {}), done: true };
  await saveProgress();
  if (settings.nextVol) {
    const nx = await siblingVolume(R.book, 1);
    if (nx) {
      toast(`${volName(nx)}으로 넘어가요`);
      const p = await db.get('progress', nx.id);
      await H.openBook(nx.id, { at: p && !p.done ? p.pos : { s: 0, b: 0, o: 0 } });
      return;
    }
  }
  toast(R.book.series ? '마지막 권의 마지막 쪽이에요' : '마지막 쪽이에요');
}

async function startOfBook() {
  const pv = settings.nextVol && (await siblingVolume(R.book, -1));
  toast(pv ? `첫 쪽이에요 · 앞 권은 ${volName(pv)}` : '첫 쪽이에요');
}

// user = 읽는 사람이 옮긴 것(쪽 넘김·목차·검색·밀대·듣기) — 쪽을 다시 나눠 같은 자리로 돌아온 건 아니다
function afterMove(user = true) {
  if (user) R.moved = true;
  updateInfo();
  clearTimeout(R.saveT);
  R.saveT = setTimeout(saveProgress, 500);
  if (R.searchHit && R.searchHitAt !== R.screen) { CSS.highlights?.delete('search'); R.searchHit = null; }
}

// 다 읽음 = 마지막 쪽에 있을 때 — 다 읽은 권도 앞으로 돌아가면 읽는 자리의 %로(사용자 «다 읽은 책은 앞쪽으로 가도 다 읽었다고만 뜸» 10-31)
//   열고 아직 안 옮겼으면 그대로(«다 읽음으로 표시»·다시 묶을 때 다 읽음으로 넘어온 권은 마지막 쪽이 아니어도)
async function saveProgress() {
  if (!R?.ready) return;
  const end = atEnd();
  const done = end || (!!R.prog?.done && !R.moved);
  R.prog = { id: R.id, pos: R.pos, pct: end ? 100 : Math.round(pctOf(R.pos) * 10) / 10, done, at: Date.now(), chap: chapOf(R.pos), tts: R.ttsAt || null };
  await db.put('progress', R.prog);
}

function bookTitle() { return volName(R.book); }
const chapOf = (pos) => (pos?.toc ? '목차' : R.label[pos?.s] || '');

// 쪽 위·아래 글(장 이름 · 쪽 번호) — 지금 쪽에도, 종이책 넘김의 쪽 사본에도
function pageInfo(screen, pos, end) {
  const pct = Math.floor(end ? 100 : pctOf(pos));
  let fl = '';
  let fr = `${pct}%`;
  if (!R.scroll) {
    const c0 = screen * R.spread;
    if (R.spread === 2) {
      fl = String(c0 + 1);
      fr = `${Math.min(c0 + 2, R.columns)} / ${R.columns}쪽 · ${pct}%`;
    } else fl = `${screen + 1} / ${R.screens}쪽`;
  }
  return { chap: chapOf(pos), pct, fl, fr };
}

function updateInfo() {
  if (!R) return;
  const { chap, pct, fl, fr } = pageInfo(R.screen, R.pos, atEnd());
  $('#rd-hb').textContent = bookTitle();
  $('#rd-hc').textContent = chap;
  $('#rd-title').textContent = bookTitle();
  let page = `${pct}%`;
  let left = '';
  if (!R.scroll) {
    const c0 = R.screen * R.spread;
    page = `<b>${R.spread === 2 ? `${c0 + 1}-${Math.min(c0 + 2, R.columns)}` : R.screen + 1}</b> / ${R.spread === 2 ? R.columns : R.screens}쪽`;
    const secCol = R.secCol || [];
    const si = secCol.findLastIndex((c) => c <= c0);
    const nextCol = secCol.find((c, i) => i > si && c > c0) ?? R.columns;
    left = ` · 이 장 남은 쪽 ${Math.max(0, Math.ceil((nextCol - c0) / R.spread) - 1)}`;
    const sl = $('#rd-slider');
    sl.max = String(R.screens - 1);
    sl.value = String(R.screen);
  } else {
    const sl = $('#rd-slider');
    sl.max = '1000';
    sl.value = String(Math.round(pct * 10));
  }
  $('#rd-fl').textContent = fl;
  $('#rd-fr').textContent = fr;
  $('#rd-pchap').innerHTML = `<b>${esc(chap)}</b>${left}`;
  $('#rd-ppage').innerHTML = page;
  updateRibbon();
}

// ---------------- 손가락 ----------------
// 그림(맨 앞 표지·삽화) 위에서 두 손가락으로 벌리거나 두 번 톡 = 그림 크게 보기(zoom.js) — 사용자 «책 맨 앞 표지 확대 가능하게»(10-29)
//   그림 위 한 번 톡은 0.28초 기다렸다가(두 번째 톡이 없으면) 원래대로(메뉴·쪽 넘김) — 기다림은 그림 위에서만
function imgAt(x, y) {
  const m = document.elementFromPoint(x, y)?.closest?.('#rd-flow img, #rd-flow svg');
  if (!m) return null;
  if (m.tagName === 'IMG') return m.currentSrc || m.src || null;
  const im = m.querySelector('image');
  return im ? im.href?.baseVal || im.getAttribute('href') || im.getAttribute('xlink:href') : null;
}
let imgTap = null;
function tapOrZoom(x, y) {
  const src = !R.menu && imgAt(x, y);
  if (!src) { tapAt(x, y); return; }
  if (imgTap && Date.now() - imgTap.t < 300 && Math.hypot(x - imgTap.x, y - imgTap.y) < 40) {
    clearTimeout(imgTap.timer);
    imgTap = null;
    openZoom(src);
    return;
  }
  clearTimeout(imgTap?.timer);
  imgTap = { t: Date.now(), x, y, timer: setTimeout(() => { imgTap = null; if (R) tapAt(x, y); }, 280) };
}

let lastTouch = 0;
function bindGestures() {
  const view = $('#rd-view');
  let g = null;
  view.addEventListener('touchstart', (e) => {
    lastTouch = Date.now();
    if (R && e.touches.length === 2 && !R.menu) {   // 그림 위 두 손가락 = 벌리기를 그림 크게 보기가 이어받는다
      const [a, b] = e.touches;
      const src = imgAt((a.clientX + b.clientX) / 2, (a.clientY + b.clientY) / 2) || imgAt(a.clientX, a.clientY) || imgAt(b.clientX, b.clientY);
      if (src) { if (g?.mode === 'bright') briEnd(); g = null; openZoom(src, { touches: e.touches }); return; }
    }
    if (!R || e.touches.length !== 1) { g = null; return; }
    curlFinish();   // 넘어가던 장은 다 넘기고 새로 잡는다
    const t = e.touches[0];
    const sel = !document.getSelection().isCollapsed;
    g = { x: t.clientX, y: t.clientY, t: Date.now(), mode: sel ? 'none' : null, dx: 0, dy: 0, sel, vx: 0, mt: performance.now() };
  }, { passive: true });
  view.addEventListener('touchmove', (e) => {
    if (!g || g.mode === 'none') return;
    const t = e.touches[0];
    const now = performance.now();
    g.vx = g.vx * 0.5 + ((t.clientX - g.x - g.dx) / Math.max(1, now - g.mt)) * 0.5;   // 최근 빠르기(px/ms)
    g.mt = now;
    g.dx = t.clientX - g.x;
    g.dy = t.clientY - g.y;
    if (!g.mode) {
      if (Math.abs(g.dx) < 12 && Math.abs(g.dy) < 12) return;
      const horiz = Math.abs(g.dx) > Math.abs(g.dy);
      if (R.scroll) {
        const edge = g.x - view.getBoundingClientRect().left < view.clientWidth * 0.14;
        g.mode = !horiz && edge ? 'bright' : 'none';
      } else g.mode = horiz ? 'drag' : 'bright';
      if (g.mode === 'bright') briStart();
      if (g.mode !== 'none') { hideSelPop(); hideNotePop(); }
    }
    if (g.mode === 'drag') { e.preventDefault(); dragTo(g); }
    else if (g.mode === 'bright') { e.preventDefault(); briMove(g.dy); }
  }, { passive: false });
  view.addEventListener('touchend', (e) => {
    lastTouch = Date.now();
    if (!g) return;
    const gg = g;
    g = null;
    if (gg.mode === 'drag') dragEnd(gg);
    else if (gg.mode === 'bright') briEnd();
    else if (gg.mode === null && !gg.sel && Date.now() - gg.t < 450) {
      e.preventDefault();
      tapOrZoom(gg.x, gg.y);
    }
  });
  view.addEventListener('touchcancel', () => {
    if (g?.mode === 'drag') { if (R.curl) curlRun(0, 200, easeOut); else setScreen(R.screen, true); }
    if (g?.mode === 'bright') briEnd();
    g = null;
  });
  // PC 시험: 클릭·휠·화살표
  view.addEventListener('click', (e) => {
    if (Date.now() - lastTouch < 700 || !R) return;
    if (!document.getSelection().isCollapsed) return;
    tapOrZoom(e.clientX, e.clientY);
  });
  let wheelT = 0;
  view.addEventListener('wheel', (e) => {
    if (!R || R.scroll) return;
    e.preventDefault();
    if (Date.now() - wheelT < 250) return;
    wheelT = Date.now();
    turn(e.deltaY > 0 || e.deltaX > 0 ? 1 : -1);
  }, { passive: false });
  document.addEventListener('keydown', (e) => {
    if (!R || e.target.closest?.('input,textarea')) return;
    if (['ArrowRight', 'PageDown', ' '].includes(e.key)) { e.preventDefault(); turn(1); }
    if (['ArrowLeft', 'PageUp'].includes(e.key)) { e.preventDefault(); turn(-1); }
  });
}

// 끄는 동안 글이 손가락을 따라오는 건 «밀기»·«종이책»일 때만 — «바로»면 글은 가만히 있다가 손을 떼면 다음 쪽이 바로 나온다
//   «종이책»: 처음 민 쪽으로 지금 쪽을 잡고(앞으로 = 오른쪽 끝 · 뒤로 = 왼쪽 끝), 손가락이 간 만큼 접혀 넘어간다
function dragTo(g) {
  const dx = g.dx;
  if (settings.anim === 'curl') {
    if (g.curl === undefined) g.curl = curlBegin(dx < 0 ? 1 : -1, g.y - $('#scr-reader').getBoundingClientRect().top);
    if (!g.curl) return;
    const W = $('#scr-reader').clientWidth;
    g.curl.t = clamp((g.curl.dir > 0 ? -dx : dx) / W, 0, 1);
    g.curl.fy = g.dy * 0.5;
    curl.pose(g.curl.t, g.curl.fy);
    return;
  }
  if (settings.anim !== 'slide') return;
  if (dx > 0 && R.screen - 1 < anchorScreen()) return;   // 앞 화면이 끊어 둔 곳 앞(덜 찬 쪽)이면 안 따라온다 — 놓으면 원래대로 다시 나눠 넘긴다(turn)
  const base = -R.screen * R.spread * R.pitch;
  const edge = (R.screen === 0 && dx > 0) || (R.screen === R.screens - 1 && dx < 0);
  const flow = $('#rd-flow');
  flow.style.transition = 'none';
  flow.style.transform = `translateX(${base + (edge ? dx / 3 : dx)}px)`;
}

function dragEnd(g) {
  const c = g.curl;
  if (c && R.curl === c) {
    // 3할 넘게 넘겼거나 넘기는 쪽으로 휙 밀었으면 마저 넘기고, 아니면 제자리로 눕힌다
    const v = c.dir > 0 ? -g.vx : g.vx;
    const go = (c.t > 0.3 && v > -0.15) || (v > 0.3 && c.t > 0.03);
    curlRun(go ? 1 : 0, go ? 140 + 360 * (1 - c.t) : 120 + 260 * c.t, easeOut);
    return;
  }
  const dx = g.dx;
  const fast = Math.abs(dx) / Math.max(1, Date.now() - g.t) > 0.35;
  if (dx < -60 || (dx < -20 && fast)) turn(1);
  else if (dx > 60 || (dx > 20 && fast)) turn(-1);
  else setScreen(R.screen, true);
}

function tapAt(x, y) {
  curlFinish();
  if (R.menu) { showMenu(false); return; }
  if (!$('#note-pop').hidden) { hideNotePop(); return; }
  const fn = fnAt(x, y);
  if (fn) { fnPop(fn); return; }
  const hit = noteAt(x, y);
  if (hit) { notePop(hit, x, y); return; }
  const fixHit = fixAt(x, y);
  if (fixHit) { fixPop(fixHit, x, y); return; }
  const at = document.elementFromPoint(x, y);
  const lnk = at?.closest?.('.lnk');
  if (lnk) { followLink(lnk); return; }
  const r = $('#rd-view').getBoundingClientRect();
  const fx = (x - r.left) / r.width;
  // 목차 쪽의 장 → 그 장으로. 양옆 넘김 자리(점선·쪽 번호 쪽)는 장 이름 글자를 누를 때만 — 목차 쪽에서도 오른쪽을 누르면 다음 쪽
  const ti = at?.closest?.('.rd-toc-it');
  if (ti && (R.scroll || at.closest('.t') || (fx >= 0.3 && fx <= 0.7))) { goTarget(+ti.dataset.s, ti.dataset.frag); return; }
  if (R.scroll) {
    const fy = (y - r.top) / r.height;
    if (fy < 0.22) turn(-1);
    else if (fy > 0.78) turn(1);
    else showMenu(true);
    return;
  }
  if (fx < 0.3) turn(-1);
  else if (fx > 0.7) turn(1);
  else showMenu(true);
}

function followLink(a) {
  if (a.dataset.ext) {
    ask(`바깥 링크를 열까요?\n${a.dataset.ext}`, '열기').then((ok) => ok && window.open(a.dataset.ext, '_blank'));
    return;
  }
  const s = R.ep.spine.findIndex((sp) => sp.path === a.dataset.path);
  if (s >= 0) goTarget(s, a.dataset.frag);
}

function goTarget(s, frag) {
  const sec = R.sections[s];
  if (!sec) return;
  const el = frag ? sec.querySelector('#' + CSS.escape(frag)) : null;
  goPos(el ? posFromDom(el, 0) : { s, b: 0, o: 0 });
}

// ---------------- 종이책 넘김 ----------------
// 사용자 «진짜 종이책 넘기는 효과»(10-25) — 넘어가는 동안만 쪽 사본 둘을 본문 위에 겹친다(curl.js 가 자르고 뒤집는다).
//   흐름의 덩어리(장·목차 쪽)는 늘 새 단에서 시작하니, 그 쪽이 든 덩어리만 복사해도 쪽 나눔이 본문과 같다
//   사본은 다음 넘김에 다시 쓴다(같은 장 안이면 옮기기만) · 쪽을 새로 나누면(R.gen) 다시 만든다
let curl = null;
const easeOut = (k) => 1 - (1 - k) ** 3;
const easeInOut = (k) => (1 - Math.cos(Math.PI * k)) / 2;

function kidAt(c) {
  let i = 0;
  while (i + 1 < R.kids.length && R.kidCol[i + 1] <= c) i++;
  return i;
}

// 쪽 사본 하나(위 글 · 본문 · 아래 글 · 책갈피 리본) — screen 쪽을 보여 준다
function fillPage(slot, screen) {
  const c0 = screen * R.spread;
  const i = kidAt(c0);
  const j = kidAt(Math.min(c0 + R.spread - 1, R.columns - 1));
  let st = slot._st;
  if (!st || st.gen !== R.gen || st.i !== i || st.j !== j) {
    slot.innerHTML = '<div class="chd"><span></span><span></span></div><div class="cvw"></div><div class="cft"><span></span><span></span></div><div class="crib" hidden></div>';
    const fl = document.createElement('div');
    fl.className = 'bk rd-cflow';
    for (let k = i; k <= j; k++) fl.appendChild(R.kids[k].cloneNode(true));
    fl.firstElementChild.style.breakBefore = 'auto';   // 맨 앞 덩어리는 단 첫머리(목차 쪽의 «새 단에서» 가 빈 단을 만들지 않게)
    const m = $('#rd-flow').style;
    Object.assign(fl.style, { left: m.left, width: m.width, height: m.height, columnCount: m.columnCount, columnGap: m.columnGap });
    fl.style.setProperty('--ph', m.getPropertyValue('--ph'));
    slot.querySelector('.cvw').appendChild(fl);
    st = slot._st = { gen: R.gen, i, j, fl, pairs: R.kids.slice(i, j + 1).map((o, k) => [o, fl.children[k]]) };
  }
  st.fl.style.transform = `translateX(${-(c0 - R.kidCol[i]) * R.pitch}px)`;
  const inf = pageInfo(screen, posAtScreen(screen), screen >= R.screens - 1);
  const [hb, hc] = slot.firstElementChild.children;
  hb.textContent = bookTitle();
  hc.textContent = inf.chap;
  const [f1, f2] = slot.querySelector('.cft').children;
  f1.textContent = inf.fl;
  f2.textContent = inf.fr;
  slot.querySelector('.crib').hidden = !R.notes.some((n) => n.type === 'bm' && screenOf(n.a) === screen);
  return st.pairs;
}

// 형광펜·메모·고친 문장 같은 칠(CSS Highlight)을 사본에도 — 같은 자리의 글자 범위를 만들어 같은 묶음에 더하고, 다 넘기면 뺀다
function mirrorMarks(pairs) {
  const added = [];
  if (!window.CSS?.highlights) return added;
  const path = (root, node) => {
    const p = [];
    for (let n = node; n !== root; n = n.parentNode) p.push(Array.prototype.indexOf.call(n.parentNode.childNodes, n));
    return p.reverse();
  };
  const at = (root, p) => p.reduce((n, i) => n?.childNodes[i], root);
  const map = (node) => {
    for (const [o, c] of pairs) if (o.contains(node)) return at(c, path(o, node));
    return null;
  };
  CSS.highlights.forEach((hl) => {
    for (const rg of [...hl]) {
      const a = map(rg.startContainer);
      const b = a && map(rg.endContainer);
      if (!b) continue;
      try {
        const r2 = document.createRange();
        r2.setStart(a, rg.startOffset);
        r2.setEnd(b, rg.endOffset);
        hl.add(r2);
        added.push([hl, r2]);
      } catch {}
    }
  });
  return added;
}

// dir 쪽으로 넘기기 시작 — 넘길 쪽이 없으면 null · y = 손가락 높이(없으면 아래 귀퉁이를 잡는다)
function curlBegin(dir, y = null) {
  curlDone(false);
  if (R.scroll || !R.kids?.length || R.opening || R.relaying) return null;   // 여는 중·창이 바뀌어 가린 동안은 옛 쪽 자리
  diagNote('turn', dir);
  const to = R.screen + dir;
  if (to < 0 || to >= R.screens) return null;
  curl ||= makeCurl($('#scr-reader'));
  const host = $('#scr-reader').getBoundingClientRect();
  const spread = R.spread === 2;
  // 끊어 둔 곳(placeAnchor) 앞으로 넘기면 원래대로 다시 나눈 쪽으로 간다 — 지금 쪽(과 한 쪽 뒷면)은 다시 나누기 전에 떠서
  //   본문 위에 덮어 두고(front · 넘기는 동안 본문은 안 보임) 다시 나눈다 · 넘겨 갈 쪽은 그 뒤에 뜬다(화면 번호는 그대로)
  const heal = to < anchorScreen();
  const kept = heal ? mirrorMarks([...fillPage(curl.front, R.screen), ...(spread ? [] : fillPage(curl.back, R.screen))]) : [];
  if (heal) healAnchor(true);
  // 한 쪽: 밑 = 넘겨 갈 쪽 · 뒷면 = 지금 쪽이 비친다(앞뒤 모두 지금 쪽이 들린다) · 두 쪽: 둘 다 넘겨 갈 펼침
  //   한 쪽 뒷면에 넘겨 갈 쪽을 읽히게 붙이면 반쯤 넘어간 뒤로 밑 쪽과 같은 글이 옆으로 겹쳐 보인다(10-26 비교) → 비침을 진하게
  const pairs = [...fillPage(curl.under, to), ...(heal && !spread ? [] : fillPage(curl.back, spread ? to : R.screen))];
  const t = readerTheme();
  const vr = $('#rd-view').getBoundingClientRect();
  curl.setup({
    W: host.width, H: host.height,
    kind: (spread ? 'spread-' : 'single-') + (dir > 0 ? 'fwd' : 'back'),
    sx: vr.left - host.left + R.left + R.cw + R.gap / 2,   // 두 쪽 사이 접는 선
    cy: y == null ? host.height : clamp(y, 0, host.height),
    lift: y == null ? 0.1 : 0.05,
    paper: paperBack(t), dark: t.dark, front: heal,
  });
  R.curl = { dir, to, t: 0, fy: 0, goal: null, raf: 0, marks: [...kept, ...mirrorMarks(pairs)], heal };
  curl.pose(0, 0);
  curl.show(true);
  return R.curl;
}

// 장의 뒷면 색 — 밝은 배경은 살짝 어둡게, 어두운 배경은 살짝 밝게
function paperBack(t) {
  const c = parseInt(t.bg.slice(1), 16);
  const ch = [c >> 16, (c >> 8) & 255, c & 255].map((v) => Math.round(t.dark ? v + (255 - v) * 0.07 : v * 0.965));
  return `rgb(${ch.join(',')})`;
}

// goal 1 = 다 넘기기 · 0 = 제자리로
function curlRun(goal, ms, ease) {
  const c = R?.curl;
  if (!c) return;
  cancelAnimationFrame(c.raf);
  c.goal = goal;
  const t0 = c.t;
  const fy0 = c.fy;
  const s0 = performance.now();
  const tick = (now) => {
    if (R?.curl !== c) return;
    const k = Math.min(1, (now - s0) / ms);
    c.t = t0 + (goal - t0) * ease(k);
    c.fy = fy0 * (1 - k);
    curl.pose(c.t, c.fy);
    if (k < 1) c.raf = requestAnimationFrame(tick);
    else curlDone(goal === 1);
  };
  c.raf = requestAnimationFrame(tick);
}

function curlDone(ok) {
  const c = R?.curl;
  if (!c) return;
  cancelAnimationFrame(c.raf);
  R.curl = null;
  for (const [hl, rg] of c.marks) hl.delete(rg);
  if (ok) {
    setScreen(c.to, false);
    R.pos = posAtScreen(c.to);
    afterMove();
  } else if (c.heal) repaginate(R.pos);   // 끊은 곳을 거두고 넘기다 말았으면 다시 끊는다 — 넘기기 전 쪽 그대로(R.pos 는 그 쪽 첫 글자)
  curl.show(false);
}

// 넘어가던 장(손을 뗀 뒤 움직이는 중)은 곧장 끝낸다 — 빨리 연달아 누를 때
function curlFinish() {
  if (R?.curl && R.curl.goal != null) curlDone(R.curl.goal === 1);
}

// ---------------- 밝기(화면을 누른 채 위아래로) ----------------
//   자동 밝기(보기 설정)를 켜면 화면 밝기는 폰의 자동 밝기 그대로 두고, 끌기는 그 위에 얇은 검은 막만 씌운다(폰 밝기의 몇 % · brightDim)
//   — 사용자 «자동 밝기 시 최대 밝기가 휴대폰 밝기여야 · 책 보다 전환하면 밝아졌다 어두워지네»(10-28): 폰 밝기보다 밝아질 수 없고, 앱을 오가도 출렁이지 않는다
//   (화면 판 21~24 는 껍데기가 조도 센서로 창 밝기를 직접 정했다 → 폰 자동 밝기와 값이 달라 오갈 때 튀었다 · 껍데기 쪽 setAutoBrightness 는 이제 끔으로만 부른다)
//   끄면 끌어서 정한 값(창 밝기 · 없으면 폰 밝기)
const autoBri = () => settings.brightAuto;
function applyBrightness() {
  bridge.setAutoBrightness(false);
  if (autoBri()) {
    bridge.setBrightness(-1);
    bridge.dim(settings.brightDim);
  } else {
    bridge.dim(1);
    bridge.setBrightness(settings.brightness ?? -1);
  }
}

let briHideT = 0;
function briStart() {
  R.briAuto = autoBri();
  R.bri0 = R.briAuto ? settings.brightDim : settings.brightness ?? bridge.getBrightness();
  R.briV = null;
  showBri(R.bri0);
}
function briMove(dy) {
  const v = clamp(R.bri0 - dy / (R.H * 0.7), R.briAuto ? 0.15 : 0.02, 1);
  R.briV = v;
  if (R.briAuto) bridge.dim(v);
  else bridge.setBrightness(v);
  showBri(v);
}
function briEnd() {
  if (R?.briV != null) setSetting(R.briAuto ? 'brightDim' : 'brightness', Math.round(R.briV * 100) / 100);
  clearTimeout(briHideT);
  briHideT = setTimeout(() => { $('#rd-bri').hidden = true; }, 700);
}
// 자동이면 «자동 70%»(폰 자동 밝기의 70% — 100% 가 끝)
function showBri(v) {
  clearTimeout(briHideT);
  const el = $('#rd-bri');
  el.hidden = false;
  el.querySelector('i').style.width = Math.round(v * 100) + '%';
  el.querySelector('b').textContent = R.briAuto ? `자동 ${Math.round(v * 100)}%` : Math.round(v * 100) + '%';
}

// ---------------- 메뉴 ----------------
function showMenu(on) {
  if (!R) return;
  if (on === R.menu) return;
  R.menu = on;
  $('#rd-top').hidden = !on;
  $('#rd-bot').hidden = !on;
  if (on) {
    hideSelPop();
    hideNotePop();
    updateInfo();
    R.menuLayer = pushLayer(() => showMenu(false));
  } else {
    R.menuLayer?.();
    R.menuLayer = null;
    $('#rd-set').hidden = true;
    $$('#rd-nav button').forEach((b) => b.classList.remove('on'));
  }
  bridge.setImmersive(!on);
}

function toggleSettings() {
  const panel = $('#rd-set');
  panel.hidden = !panel.hidden;
  $('#rd-nav [data-a="set"]').classList.toggle('on', !panel.hidden);
  if (!panel.hidden) renderSettings();
}

function opt(key, value, label, cls = '') {
  return `<button class="opt${settings[key] === value ? ' on' : ''} ${cls}" data-k="${key}" data-v="${esc(JSON.stringify(value))}">${label}</button>`;
}
function stepper(key, label, fmt) {
  return `<div class="stp"><button class="b" data-step="${key}" data-d="-1" aria-label="${label} 줄이기">−</button><span class="v">${fmt(settings[key])}</span><button class="b" data-step="${key}" data-d="1" aria-label="${label} 늘리기">＋</button></div>`;
}
const STEPS = {
  fs: { min: 12, max: 32, step: 1, fmt: (v) => v },
  lh: { min: 1.3, max: 2.8, step: 0.1, fmt: (v) => v.toFixed(1) },
  pm: { min: 0, max: 2, step: 0.25, fmt: (v) => v.toFixed(2).replace(/0$/, '') },
  ttsRate: { min: 0.7, max: 1.6, step: 0.05, fmt: (v) => `×${v.toFixed(2)}` },
};

function renderSettings() {
  const sw = Object.entries(READER_THEMES).map(([k, t]) => `<button class="sw${settings.theme === k ? ' on' : ''}" data-k="theme" data-v='"${k}"' style="background:${t.bg}" aria-label="${t.name}"></button>`).join('');
  $('#rd-set').innerHTML = `
    <div class="srow"><div class="k">글꼴</div><div class="opts">${Object.entries(FONTS).map(([k, f]) => opt('font', k, f.name, k)).join('')}</div><span class="hint wrap">리디바탕·마루 부리·고운바탕·프리텐다드는 처음 고를 때 한 번 받아요(0.4~0.7MB)</span></div>
    <div class="srow"><div class="k">글자 크기</div>${stepper('fs', '글자 크기', STEPS.fs.fmt)}</div>
    <div class="srow"><div class="k">줄 간격</div>${stepper('lh', '줄 간격', STEPS.lh.fmt)}</div>
    <div class="srow"><div class="k">여백</div>${opt('margin', 's', '좁게')}${opt('margin', 'm', '보통')}${opt('margin', 'l', '넓게')}</div>
    <div class="srow"><div class="k">배경</div><button class="sw auto${settings.theme === 'auto' ? ' on' : ''}" data-k="theme" data-v='"auto"' aria-label="자동">자동</button>${sw}</div>
    <div class="srow"><div class="k">넘기기</div>${opt('mode', 'page', '좌우로 넘기기')}${opt('mode', 'scroll', '위아래 스크롤')}</div>
    <div class="srow"><div class="k">그 밖</div><label class="chk"><input type="checkbox" data-k="keepOn"${settings.keepOn ? ' checked' : ''}><i></i>화면 꺼짐 방지</label><label class="chk"><input type="checkbox" data-k="nextVol"${settings.nextVol ? ' checked' : ''}><i></i>다음 권 이어서</label></div>
    <div class="srow"><div class="k">화면 회전</div>${opt('rotate', 'auto', '폰 따라')}${opt('rotate', 'portrait', '세로 고정')}${opt('rotate', 'landscape', '가로 고정')}${native && !bridge.canSetOrientation() ? '<span class="hint wrap">앱을 1.4 로 새로 깔면 돼요</span>' : ''}</div>
    <div class="srow more"><div class="k">두 쪽 보기</div>${opt('spread', 'auto', '펴면 자동')}${opt('spread', 'one', '늘 한 쪽')}</div>
    <div class="srow"><div class="k">넘김 효과</div>${opt('anim', 'none', '바로')}${opt('anim', 'curl', '종이책')}${opt('anim', 'slide', '밀기')}</div>
    <div class="srow"><div class="k">문단 간격</div>${stepper('pm', '문단 간격', STEPS.pm.fmt)}</div>
    <div class="srow"><div class="k">문단 모양</div><label class="chk"><input type="checkbox" data-k="indent"${settings.indent ? ' checked' : ''}><i></i>들여쓰기</label><label class="chk"><input type="checkbox" data-k="justify"${settings.justify ? ' checked' : ''}><i></i>양쪽 정렬</label></div>
    <div class="srow"><div class="k">볼륨키</div><label class="chk"><input type="checkbox" data-k="volKeys"${settings.volKeys ? ' checked' : ''}><i></i>볼륨키로 넘기기(아래 = 다음 쪽)</label></div>
    <div class="srow"><div class="k">밝기</div><label class="chk"><input type="checkbox" data-k="brightAuto"${settings.brightAuto ? ' checked' : ''}><i></i>자동 밝기</label>${(settings.brightAuto ? settings.brightDim < 1 : settings.brightness != null) ? '<button class="opt" data-a="bri-reset">폰 밝기로</button>' : ''}<span class="hint wrap">${!settings.brightAuto ? '화면을 누른 채 위아래로 끌기' : `폰 자동 밝기 그대로${settings.brightDim < 1 ? `의 ${Math.round(settings.brightDim * 100)}%` : ''} · 화면을 누른 채 끌면 그보다 어둡게`}</span></div>
    ${voiceRows()}
    <div class="srow"><div class="k">앱 테마</div>${opt('appTheme', 'auto', '폰 따라')}${opt('appTheme', 'light', '밝게')}${opt('appTheme', 'dark', '어둡게')}</div>`;
}

function onSettingsClick(e) {
  const t = e.target.closest('button,input');
  if (!t) return;
  if (t.dataset.a === 'bri-reset') {   // 자동이면 검은 막을 걷고(폰 자동 밝기 그대로) · 아니면 폰 밝기로
    setSetting(settings.brightAuto ? 'brightDim' : 'brightness', settings.brightAuto ? 1 : null);
    applyBrightness();
    renderSettings();
    return;
  }
  if (t.dataset.a === 'tts-try') { ttsTry(); return; }
  if (t.dataset.a === 'voice-get') { bridge.voiceGet(); setTimeout(renderSettings, 300); return; }
  if (t.dataset.a === 'voice-stop') { bridge.voiceCancel(); setTimeout(renderSettings, 500); return; }
  if (t.dataset.a === 'voice-del') {
    ask('새벽 음성 파일(401MB)을 지울까요?\n다시 쓰려면 또 받아야 해요.', '지우기', { danger: true }).then((ok) => {
      if (!ok) return;
      if (R?.tts?.on) ttsStop();
      bridge.voiceDelete();
      setTimeout(renderSettings, 300);
    });
    return;
  }
  if (t.dataset.step) {
    const k = t.dataset.step;
    const s = STEPS[k];
    setSetting(k, Math.round(clamp(settings[k] + s.step * +t.dataset.d, s.min, s.max) * 100) / 100);
    applied(k);
    return;
  }
  if (t.dataset.k === 'font') { pickFont(JSON.parse(t.dataset.v)); return; }
  if (t.dataset.k && t.localName === 'button') {
    setSetting(t.dataset.k, JSON.parse(t.dataset.v));
    applied(t.dataset.k);
  }
}

// 받아 쓰는 글꼴은 처음 고를 때 받는다 — 받는 동안은 지금 글꼴 그대로, 다 받으면 바꾸고 쪽을 다시 나눈다 · 못 받으면 그대로 두고 알림
async function pickFont(id) {
  const w = WEB_FONTS[id];
  if (w) {
    const fresh = !(await fontCached(id));
    if (fresh) toast(`글꼴 받는 중… ${w.name} ${(w.kb / 1024).toFixed(1)}MB`, 20000);
    try {
      await loadFont(id);
    } catch {
      toast('글꼴을 못 받았어요 · 인터넷이 되면 다시 골라 주세요', 3500);
      return;
    }
    if (fresh) toast(`글꼴을 바꿨어요 · ${w.name}`, 1800);
  }
  setSetting('font', id);
  applied('font');
}
function onSettingsChange(e) {
  const t = e.target;
  if (t.type === 'checkbox' && t.dataset.k) {
    setSetting(t.dataset.k, t.checked);
    applied(t.dataset.k);
  }
}

function applied(k) {
  if (['fs', 'lh', 'pm', 'indent', 'justify', 'font'].includes(k)) { applyTypo(); relayout(); }
  if (['margin', 'mode', 'spread'].includes(k)) relayout();
  if (k === 'theme') applyTheme();
  if (k === 'appTheme') { applyAppTheme(); applyTheme(); }
  if (k === 'keepOn') bridge.keepScreenOn(settings.keepOn);
  if (k === 'rotate') bridge.setOrientation(settings.rotate);
  if (k === 'brightAuto') applyBrightness();
  if (k === 'volKeys') bridge.setVolumeKeys(settings.volKeys);
  if (k === 'ttsVoice' || k === 'ttsRate') ttsUpdate();
  renderSettings();
}

// ---------------- 목차 ----------------
function tocList() {
  return R.ep.toc.length ? R.ep.toc : R.sections.map((sec, s) => ({ label: R.label[s] || `${s + 1}`, s, frag: '', depth: 0 })).filter((t, i, a) => t.label && (i === 0 || a[i - 1].label !== t.label));
}

// 책 안의 목차 쪽 — 사용자 «표지 다음 장에 목차, 누르면 그 장으로»(10-25). 첫 장 바로 앞(표지 다음)에 쪽으로 넣는다.
//   장(R.sections)이 아니라서 장 번호·문단 목록·찾기·듣기엔 안 들어가고, 쪽 번호는 쪽을 나눌 때마다 layout() 이 채운다
function addTocPage() {
  const list = tocList().filter((t) => R.sections[t.s] && !R.sections[t.s].classList.contains('imgonly'));
  if (list.length < 2 || ownTocPage()) return;
  const at = Math.min(...list.map((t) => t.s));
  const sec = document.createElement('section');
  sec.className = 'rd-toc';
  sec.innerHTML = '<div class="rd-toc-h">목차</div>' + list.map((t) => `<div class="rd-toc-it" data-s="${t.s}" data-frag="${esc(t.frag || '')}"${t.depth ? ` style="padding-left:${(t.depth * 1.2).toFixed(1)}em"` : ''}><span class="t">${esc(t.label)}</span><span class="d"></span><span class="n"></span></div>`).join('');
  R.sections[at].before(sec);
  R.tocS = at;
}

// 책에 목차 쪽이 이미 들어 있으면(앞쪽 장 하나가 거의 다 다른 장으로 가는 링크) 하나 더 넣지 않는다
function ownTocPage() {
  const bare = (s) => s.replace(/\s+/g, '').length;
  return R.sections.slice(0, 6).some((sec) => {
    const links = $$('.lnk[data-path]', sec);
    return new Set(links.map((a) => a.dataset.path)).size >= 3 && links.reduce((n, a) => n + bare(a.textContent), 0) > bare(sec.textContent) * 0.5;
  });
}

function openToc() {
  const toc = tocList();
  const cur = R.pos.toc ? -1 : R.pos.s;
  let curIdx = -1;
  toc.forEach((t, i) => { if (t.s <= cur) curIdx = i; });
  const s = sheet({
    title: '목차', cls: 'tall',
    body: `<div class="toc">${toc.map((t, i) => `<button class="toc-it${i === curIdx ? ' cur' : ''}" data-i="${i}" style="padding-left:${16 + t.depth * 16}px">${esc(t.label)}</button>`).join('')}</div>`,
  });
  s.body.onclick = (e) => {
    const b = e.target.closest('.toc-it');
    if (!b) return;
    const t = toc[+b.dataset.i];
    s.close();
    showMenu(false);
    goTarget(t.s, t.frag);
  };
  s.body.querySelector('.cur')?.scrollIntoView({ block: 'center' });
}

// ---------------- 검색 ----------------
function openSearch(q0 = '') {
  const s = sheet({
    title: '책 안에서 찾기', cls: 'tall',
    body: '<div class="sbox"><input id="rd-q" type="search" placeholder="찾을 말" enterkeyhint="search"></div><div class="sres" id="rd-sres"></div>',
  });
  const input = s.body.querySelector('#rd-q');
  const res = s.body.querySelector('#rd-sres');
  let hits = [];
  const run = () => {
    const q = input.value.trim();
    hits = [];
    if (!q) { res.innerHTML = ''; return; }
    const ql = q.toLowerCase();
    for (const el of R.blocks) {
      const t = el.textContent;
      const tl = t.toLowerCase();
      let i = tl.indexOf(ql);
      while (i >= 0 && hits.length < 500) {
        hits.push({ el, o: i, len: q.length, t });
        i = tl.indexOf(ql, i + ql.length);
      }
      if (hits.length >= 500) break;
    }
    res.innerHTML = `<div class="sres-n">${hits.length >= 500 ? '500곳 넘게' : hits.length + '곳'}</div>` + hits.map((h, i) => {
      const info = R.info.get(h.el);
      const a = Math.max(0, h.o - 24);
      return `<button class="sres-it" data-i="${i}"><span class="c">${esc(R.label[info.s] || '')}${R.fnOf.has(h.el) ? ' · 주석' : ''}</span>${a > 0 ? '…' : ''}${esc(h.t.slice(a, h.o))}<b>${esc(h.t.slice(h.o, h.o + h.len))}</b>${esc(h.t.slice(h.o + h.len, h.o + h.len + 40))}…</button>`;
    }).join('');
  };
  let t = 0;
  input.oninput = () => { clearTimeout(t); t = setTimeout(run, 200); };
  input.onkeydown = (e) => { if (e.key === 'Enter') { clearTimeout(t); run(); input.blur(); } };
  res.onclick = (e) => {
    const b = e.target.closest('.sres-it');
    if (!b) return;
    const h = hits[+b.dataset.i];
    const info = R.info.get(h.el);
    s.close();
    showMenu(false);
    const [n1, o1] = locate(h.el, h.o);
    const [n2, o2] = locate(h.el, h.o + h.len);
    const rg = document.createRange();
    rg.setStart(n1, o1);
    rg.setEnd(n2, o2);
    goPosNote({ s: info.s, b: info.b, o: h.o }, { flash: rg });
  };
  input.value = q0;
  if (q0) run();
  setTimeout(() => input.focus(), 250);
}

function flashRange(rg) {
  if (!window.CSS?.highlights) return;
  CSS.highlights.set('search', new Highlight(rg));
  R.searchHit = rg;
  R.searchHitAt = R.screen;
}

// ---------------- 형광펜·메모·제보·책갈피 ----------------
function rangeOfNote(n) {
  const ea = blockAt(n.a);
  const eb = blockAt(n.b);
  if (!ea || !eb) return null;
  const mk = (a, ao, b, bo) => {
    const [sn, so] = locate(a, ao);
    const [en, eo] = locate(b, bo);
    const rg = document.createRange();
    rg.setStart(sn, so);
    rg.setEnd(en, eo);
    return rg;
  };
  const rg = mk(ea, n.a.o, eb, n.b.o);
  const norm = (s) => s.replace(/\s+/g, '');
  if (!n.text || norm(rg.toString()) === norm(n.text)) return rg;
  // 새 판에서 문장이 조금 움직였으면 같은 문단에서 인용문을 다시 찾는다
  if (ea === eb) {
    const i = ea.textContent.indexOf(n.text);
    if (i >= 0) return mk(ea, i, ea, i + n.text.length);
  }
  return rg;
}

function paintNotes() {
  if (!R || !window.CSS?.highlights) return;
  const groups = { 'hl-y': [], 'hl-g': [], 'hl-b': [], 'hl-p': [], memo: [], report: [] };
  R.ranges = new Map();
  for (const n of R.notes) {
    if (n.type === 'bm') continue;
    const rg = rangeOfNote(n);
    if (!rg) continue;
    R.ranges.set(n.id, rg);
    groups[n.type === 'hl' ? 'hl-' + (n.color || 'y') : n.type]?.push(rg);
  }
  for (const [k, list] of Object.entries(groups)) CSS.highlights.set(k, new Highlight(...list));
  updateRibbon();
}

function noteAt(x, y) {
  const c = document.caretRangeFromPoint?.(x, y);
  if (!c) return null;
  for (const n of [...R.notes].reverse()) {
    const rg = R.ranges.get(n.id);
    try { if (rg && rg.comparePoint(c.startContainer, c.startOffset) === 0) return n; } catch {}
  }
  return null;
}

async function addNote(n) {
  n.id = Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  n.bookId = R.id;
  n.at = Date.now();
  n.chap = chapOf(n.a);
  n.vol = bookTitle();
  await db.put('notes', n);
  R.notes.push(n);
  paintNotes();
  return n;
}

async function updateNote(n) {
  await db.put('notes', n);
  paintNotes();
}

async function deleteNote(n) {
  await db.del('notes', n.id);
  R.notes = R.notes.filter((x) => x.id !== n.id);
  paintNotes();
}

// 제보에는 고른 말이 든 문장 전체와 앞뒤 문장을 붙인다 — 짧은 말(«네.»)만 골라도 번역기 쪽에서 문단을 바로 찾게(10-25 번역기 세션 부탁)
const SENT_END = /[.!?…]+[”’」』"')\]]*(?=\s|$)/g;
function sentenceRanges(t) {
  const out = [];
  let s = 0;
  for (const m of t.matchAll(SENT_END)) {
    const e = m.index + m[0].length;
    if (e > s) out.push([s, e]);
    s = e;
    while (s < t.length && /\s/.test(t[s])) s++;
  }
  if (s < t.length) out.push([s, t.length]);
  return out.length ? out : [[0, t.length]];
}

function reportContext(a, b) {
  const ea = blockAt(a);
  const eb = blockAt(b);
  if (!ea || !eb) return null;
  const ta = ea.textContent;
  const tb = eb.textContent;
  const ra = sentenceRanges(ta);
  const rb = sentenceRanges(tb);
  const ia = Math.max(0, ra.findIndex(([, e]) => a.o < e));
  let ib = rb.findIndex(([, e]) => Math.max(0, b.o - 1) < e);
  if (ib < 0) ib = rb.length - 1;
  let sent;
  if (ea === eb) sent = ta.slice(ra[ia][0], rb[Math.max(ib, ia)][1]);
  else {
    const g1 = R.info.get(ea).g;
    const g2 = R.info.get(eb).g;
    const parts = [ta.slice(ra[ia][0])];
    for (let g = g1 + 1; g < g2; g++) parts.push(R.blocks[g].textContent);
    parts.push(tb.slice(0, rb[ib][1]));
    sent = parts.join('\n');
  }
  // 앞뒤 문장: 같은 문단에서, 없으면 같은 장의 이웃 문단에서(숨긴 주석 글은 이웃이 없다)
  const near = (el, step) => {
    const list = R.tb;
    const i = list.indexOf(el);
    const n = i < 0 ? null : list[i + step];
    return n && R.info.get(n).s === R.info.get(el).s ? n : null;
  };
  const one = (el, last) => {
    if (!el) return '';
    const t = el.textContent;
    const r = sentenceRanges(t);
    const [s, e] = last ? r[r.length - 1] : r[0];
    return t.slice(s, e);
  };
  const prev = ia > 0 ? ta.slice(ra[ia - 1][0], ra[ia - 1][1]) : one(near(ea, -1), true);
  const next = ib < rb.length - 1 ? tb.slice(rb[ib + 1][0], rb[ib + 1][1]) : one(near(eb, 1), false);
  const clean = (s) => s.replace(/[ \t]+/g, ' ').trim();
  return { sent: clean(sent), prev: clean(prev), next: clean(next) };
}

// 안 보낸 제보를 우편함으로 → 지금 연 책의 메모 목록에도 «보냄» 표시
async function sendToInbox() {
  const r = await sendNow();
  if (r?.ids && R) for (const n of R.notes) if (r.ids.includes(n.id)) n.sentAt = r.at;
  if (!r && R && inboxConf()) toast('제보는 담아 뒀어요 · 인터넷이 되면 다시 보내요', 3500);
}

function editNote(n, isNew) {
  const kind = n.type === 'report' ? '제보' : '메모';
  const quote = n.type === 'report' && n.ctx?.sent
    ? `${markQuote(n.ctx.sent, n.text)}<div class="qhint">앞뒤 문장도 같이 담겨요</div>`
    : esc(n.text);
  const s = sheet({
    title: isNew ? `${kind} 남기기` : `${kind} 고치기`,
    body: `<div class="quote">${quote}</div>
      <textarea id="nt-text" rows="4" placeholder="${n.type === 'report' ? '어떻게 고치면 좋을지 적어 주세요(비워 둬도 돼요)' : '메모'}">${esc(n.note || '')}</textarea>
      <div class="sheet-btns">${isNew ? '' : '<button class="btn ghost danger-t" data-a="del">지우기</button>'}<span class="sp"></span><button class="btn" data-a="save">저장</button></div>`,
  });
  const ta = s.body.querySelector('#nt-text');
  setTimeout(() => ta.focus(), 250);
  s.body.onclick = async (e) => {
    const a = e.target.closest('[data-a]')?.dataset.a;
    if (a === 'save') {
      n.note = ta.value.trim();
      if (n.type === 'report' && !isNew) delete n.sentAt;  // 고친 제보는 다시 보낸다
      if (isNew) await addNote(n);
      else await updateNote(n);
      s.close();
      if (n.type === 'report' && inboxConf()) sendToInbox();  // 우편함이 이어져 있으면 바로 번역기로
      else toast(n.type === 'report' ? '제보에 담았어요' : '메모를 남겼어요');
    } else if (a === 'del') {
      await deleteNote(n);
      s.close();
    }
  };
}

// 고른 글 위에 뜨는 단추
let selT = 0;
function onSelectionChange() {
  clearTimeout(selT);
  selT = setTimeout(() => {
    if (!R || R.menu) return;
    const s = document.getSelection();
    if (!s.rangeCount || s.isCollapsed) { hideSelPop(); return; }
    const rg = s.getRangeAt(0);
    if (!$('#rd-flow').contains(rg.commonAncestorContainer)) { hideSelPop(); return; }
    R.sel = rg.cloneRange();
    placePop($('#sel-pop'), rg.getClientRects());
  }, 160);
}

function placePop(pop, rects) {
  if (!rects.length) return;
  const first = rects[0];
  const last = rects[rects.length - 1];
  pop.hidden = false;
  const pw = pop.offsetWidth;
  const ph = pop.offsetHeight;
  const top0 = $('#rd-view').getBoundingClientRect().top;
  let y = first.top - ph - 12;
  if (y < top0) y = last.bottom + 34;
  pop.style.left = clamp(first.left, 8, innerWidth - pw - 8) + 'px';
  pop.style.top = clamp(y, 8, innerHeight - ph - 8) + 'px';
}

function hideSelPop() { $('#sel-pop').hidden = true; if (R) R.sel = null; }

async function onSelAction(act) {
  const rg = R?.sel;
  if (!rg) return;
  const text = rg.toString().replace(/\s+/g, ' ').trim();
  const a = posFromDom(rg.startContainer, rg.startOffset);
  const b = posFromDom(rg.endContainer, rg.endOffset);
  document.getSelection().removeAllRanges();
  hideSelPop();
  if (!text) return;
  if (act.startsWith('hl-')) await addNote({ type: 'hl', color: act.slice(3), a, b, text });
  else if (act === 'memo') editNote({ type: act, a, b, text, note: '' }, true);
  else if (act === 'report') editNote({ type: act, a, b, text, note: '', ctx: reportContext(a, b) }, true);
  else if (act === 'copy') { bridge.copy(text); toast('복사했어요'); }
  else if (act === 'search') openSearch(text);
}

// 칠해 둔 곳을 누르면
function notePop(n, x, y) {
  const pop = $('#note-pop');
  const colors = n.type === 'hl' ? HL_COLORS.map((c) => `<button class="dot c-${c}${n.color === c ? ' on' : ''}" data-c="${c}" aria-label="색"></button>`).join('') : '';
  pop.innerHTML = `${n.note ? `<div class="pn">${esc(n.note)}</div>` : ''}<div class="pb-row">${colors}
    ${n.type === 'hl' ? '<button data-a="memo">메모</button>' : `<button data-a="edit">${n.type === 'report' ? '제보 고치기' : '메모 고치기'}</button>`}
    <button data-a="copy">복사</button><button data-a="del" class="danger-t">지우기</button></div>`;
  R.popNote = n;
  R.popFix = null;
  R.popFn = null;
  const rg = R.ranges.get(n.id);
  placePop(pop, rg ? rg.getClientRects() : [{ left: x, top: y, bottom: y }]);
}
function hideNotePop() { const p = $('#note-pop'); if (p) p.hidden = true; }

async function onNotePop(e) {
  const n = R?.popNote;
  if (!n) {   // 고친 문장 해설·주석은 누르면 닫힘 — «답글 달기»·«제보»만 받는다
    const fix = R?.popFix;
    const fn = R?.popFn;
    hideNotePop();
    if (fix && e.target.closest('[data-a="comment"]')) commentSheet(fix);
    if (fn && e.target.closest('[data-a="fn-report"]')) fnReport(fn);
    return;
  }
  const c = e.target.closest('[data-c]')?.dataset.c;
  const a = e.target.closest('[data-a]')?.dataset.a;
  if (c) { n.color = c; await updateNote(n); hideNotePop(); return; }
  hideNotePop();
  if (a === 'memo') { n.type = 'memo'; editNote(n, false); }
  else if (a === 'edit') editNote(n, false);
  else if (a === 'copy') { bridge.copy(n.text); toast('복사했어요'); }
  else if (a === 'del') deleteNote(n);
}

// 책갈피: 이 쪽에 있으면 빼고, 없으면 꽂는다
function bmHere() {
  return R.notes.filter((n) => n.type === 'bm').find((n) => (R.scroll ? onScrollScreen(n.a) : screenOf(n.a) === R.screen));
}
function onScrollScreen(pos) {
  const r = rectOfPos(pos);
  const v = $('#rd-view').getBoundingClientRect();
  return r && r.top >= v.top - 2 && r.top < v.bottom;
}
async function toggleBookmark() {
  const here = bmHere();
  if (here) { await deleteNote(here); toast('책갈피를 뺐어요'); return; }
  const el = R.pos.toc ? null : blockAt(R.pos);
  const text = el ? el.textContent.slice(R.pos.o, R.pos.o + 60).trim() : R.pos.toc ? '목차' : '';
  await addNote({ type: 'bm', a: { ...R.pos }, b: { ...R.pos }, text });
  toast('책갈피를 꽂았어요');
}
function updateRibbon() {
  if (!R) return;
  const on = !!bmHere();
  $('#rd-ribbon').hidden = !on;
  $('#rd-bm').classList.toggle('on', on);
}

async function openNotes(tab = 'hl') {
  const results = await resultsByReport(R.notes);
  const s = sheet({ title: '메모·제보', cls: 'tall' });
  const draw = () => {
    const by = (t) => R.notes.filter((n) => n.type === t).sort(byPos);
    const tabs = Object.entries(NOTE_KINDS).map(([k, name]) => `<button class="tab${tab === k ? ' on' : ''}" data-tab="${k}">${name} ${by(k).length}</button>`).join('');
    const list = by(tab);
    const tools = tab === 'report' && list.length ? reportTools(list) : '';
    s.body.innerHTML = `<div class="tabs">${tabs}</div>${tools}${list.length ? list.map((n) => `<div class="note-it" data-id="${n.id}">
        ${n.type === 'hl' ? `<span class="dot c-${n.color || 'y'}"></span>` : ''}<div class="q">${n.ctx?.sent ? markQuote(n.ctx.sent, n.text) : esc(n.text || '')}</div>
        ${n.note ? `<div class="nt">→ ${esc(n.note)}</div>` : ''}
        <div class="meta">${esc(chapOf(n.a))} · ${fmtDate(n.at)}${n.type === 'report' ? resultChip(n, results.get(n.id)) : ''}<button class="ib sm" data-a="del" aria-label="지우기">${icon('trash')}</button></div></div>`).join('')
      : `<div class="empty-note">${tab === 'bm' ? '위 막대의 책갈피 단추로 이 쪽을 꽂아 두세요.' : '문장을 꾹 눌러 고른 뒤 위에 뜨는 단추를 누르세요.'}</div>`}`;
  };
  draw();
  s.body.onclick = async (e) => {
    const tb = e.target.closest('[data-tab]');
    if (tb) { tab = tb.dataset.tab; draw(); return; }
    const a = e.target.closest('[data-a]')?.dataset.a;
    const it = e.target.closest('.note-it');
    const reps = R.notes.filter((n) => n.type === 'report');
    if (a === 'inbox') {
      await sendToInbox();
      draw();
    } else if (a === 'send' || a === 'copy' || a === 'save') {
      const text = reportText(reps, new Map([[R.id, R.book]]));
      if (a === 'send') bridge.share(text, '제보 보내기');
      else if (a === 'copy') { bridge.copy(text); toast('복사했어요'); }
      else bridge.saveText(`제보-${new Date().toISOString().slice(0, 10)}.txt`, text);
    } else if (a === 'clear') {
      if (await ask(`이 책의 제보 ${reps.length}건을 모두 지울까요?`, '모두 지우기', { danger: true })) {
        for (const n of reps) await db.del('notes', n.id);
        R.notes = R.notes.filter((n) => n.type !== 'report');
        paintNotes();
        toast('제보를 모두 지웠어요');
        draw();
      }
    } else if (a === 'del' && it) {
      const n = R.notes.find((x) => x.id === it.dataset.id);
      if (n) { await deleteNote(n); draw(); }
    } else if (it) {
      const n = R.notes.find((x) => x.id === it.dataset.id);
      s.close();
      showMenu(false);
      if (n) goPosNote(n.a);
    }
  };
}

// ---------------- 듣기(TTS) ----------------
//   새벽 음성(껍데기 1.7 · Supertonic 3 · 폰 안에서 만듦 · 파일 받은 뒤) 또는 폰 음성(안드로이드 TTS)
//   껍데기 1.9(readStart): «여기서부터 권 끝까지»의 문단 글을 한 번에 넘기면 껍데기가 알아서 이어 읽는다 — 화면을 꺼도 멈추지 않는다
//     (사용자 «유튜브 프리미엄처럼 화면 꺼도 듣기» 10-28 · 알림·잠금화면 단추 · 화면은 알림을 받아 쪽·칠하기만 따라간다 = T.plan)
//   그 전 껍데기: 문단 하나씩 넘기고 끝나면 다음 문단(새벽 음성은 «지금 문단 + 다음 문단»을 넘겨 다음 것을 미리 만들게 한다)
export const VOICES = { F1: '여자 1', F2: '여자 2', F3: '여자 3', F4: '여자 4', F5: '여자 5', M1: '남자 1', M2: '남자 2', M3: '남자 3', M4: '남자 4', M5: '남자 5' };
// 듣기 글 = 빈칸을 하나로 줄인 문단 글 · 주석 표시 «(주1)»는 빈칸으로 읽힌다(«주 일»이라 소리 내지 않게 — 길이가 같아 rawOffset 자리 셈 그대로) · 숨긴 주석 글은 안 읽는다
function ttsSrc(el) {
  if (!el.querySelector('.rd-fn')) return el.textContent;
  return textNodes(el).map(([n]) => (n.parentElement.closest('.rd-fn') ? ' '.repeat(n.data.length) : n.data)).join('');
}
const blockText = (el) => (isFnb(el) ? '' : ttsSrc(el).replace(/\s+/g, ' ').trim());
const voiceHave = () => bridge.canVoice() && !!bridge.voiceState()?.have;
const wantVoice = () => settings.ttsVoice !== 'phone' && !!VOICES[settings.ttsVoice];
let tryVoice = false;   // 보기 설정 «들어 보기» 중(그 실패는 읽기를 멈추지 않고 알리기만)

// 멈춘 자리(R.ttsAt = { s, b, t } · t = 그 문단 글(빈칸 하나로 줄인 것)의 몇 번째 글자 = 들리던 묶음의 첫 글자)
//   사용자 «중단하고 다시 읽으면 페이지 맨 윗문단부터 읽네»(10-27) → 그 문단이 지금 쪽에 보이면 거기서 이어 읽는다
//   (쪽을 넘겼으면 그 쪽 첫 문단부터 · 권을 닫았다 열어도 진도(prog.tts)에 남는다 · 묶음 자리는 껍데기 1.8 새벽 음성 — 그 밖엔 문단 처음)
function onScreen(el) {
  const rs = [...el.getClientRects()];
  if (R.scroll) {
    const v = $('#rd-view').getBoundingClientRect();
    return rs.some((r) => r.bottom > v.top && r.top < v.bottom);
  }
  return rs.some((r) => Math.floor(colOf(r.left) / R.spread) === R.screen);
}

function ttsStart() {
  if (!bridge.ttsAvailable()) { toast('이 기기에선 듣기를 쓸 수 없어요'); return; }
  showMenu(false);
  tryVoice = false;
  let el = blockAt(R.pos);
  let skip = 0;
  const at = R.ttsAt;
  const ae = at && blockAt({ s: at.s, b: at.b, o: 0 });
  if (ae && R.info.get(ae).b === at.b && onScreen(ae)) {
    el = ae;
    skip = at.t > 0 && at.t < blockText(ae).length ? at.t : 0;
  }
  const voice = wantVoice() && voiceHave();
  if (!voice && wantVoice() && bridge.canVoice()) toast('새벽 음성 파일이 아직 없어 폰 음성으로 읽어요 · 보기 설정 → 새벽 음성 «받기»');
  R.tts = { g: el ? R.info.get(el).g : 0, on: true, id: 0, voice, skip, base: 0, plan: bridge.canRead(), state: 'playing' };
  ttsLabel(voice ? '준비 중' : '');
  $('#rd-tts').hidden = false;
  if (R.tts.plan) ttsPlan();
  else ttsSay();
}

function ttsLabel(s = '') {
  $('#rd-tts').textContent = R?.tts?.state === 'paused' ? '▶ 이어 듣기' : '■ 듣기 멈춤' + (s ? ` · ${s}` : '');
}

// 문단 하나를 «지금 읽는 곳»으로 — 칠하기(묶음 알림이 오기 전까지는 문단 전체) · 그 글자가 있는 쪽으로
function ttsPara(g, off = 0) {
  const T = R.tts;
  const el = R.blocks[g];
  const info = el && R.info.get(el);
  if (!info) return;
  R.ttsAt = { s: info.s, b: info.b, t: off };
  if (!(T.voice && T.chunks)) {   // 묶음 알림이 오는 껍데기(1.8+ 새벽 음성)는 묶음이 들릴 때 그 묶음만 칠한다(문단 전체가 잠깐 칠해졌다 줄어드는 깜빡임 없이)
    const rg = document.createRange();
    rg.selectNodeContents(el);
    CSS.highlights?.set('tts', new Highlight(rg));
  }
  if (R.scroll) {
    el.scrollIntoView({ block: 'center', behavior: document.visibilityState === 'hidden' ? 'auto' : 'smooth' });
    R.pos = { s: info.s, b: info.b, o: 0 };
    afterMove();
    return;
  }
  const sc = screenOf({ s: info.s, b: info.b, o: rawOffset(el, off) });
  if (sc !== R.screen) ttsTurn(sc);
}

// 껍데기 1.9 — 여기서부터 권 끝까지 한 번에(장 이름은 바뀔 때만 c) + 표지(알림·잠금화면 그림)
async function ttsPlan() {
  const T = R.tts;
  const items = [];
  let last = null;
  for (let g = T.g; g < R.blocks.length; g++) {
    const text = blockText(R.blocks[g]);
    if (!text) continue;
    const c = R.label[R.info.get(R.blocks[g]).s] || '';
    items.push(c !== last ? { id: String(g), text, c } : { id: String(g), text });
    last = c;
  }
  if (!items.length) { ttsStop(); toast('이 권을 끝까지 읽었어요'); return; }
  T.g = +items[0].id;
  if (T.skip >= items[0].text.length) T.skip = 0;
  ttsPara(T.g, T.skip);
  let cover = '';
  try {
    const blob = await db.get('covers', R.id);
    if (blob) cover = await new Promise((res) => { const fr = new FileReader(); fr.onload = () => res(String(fr.result)); fr.onerror = () => res(''); fr.readAsDataURL(blob); });
  } catch { /* 표지 없이 */ }
  if (!R?.tts?.on || R.tts !== T) return;   // 그 사이 멈춤
  bridge.readStart({ engine: T.voice ? 'voice' : 'phone', voice: settings.ttsVoice, rate: settings.ttsRate, items, off: T.skip, book: bookTitle(), cover });
}

// 읽는 중 목소리·빠르기를 바꾸면(보기 설정) 다음 문단부터
function ttsUpdate() {
  const T = R?.tts;
  if (!T?.on || !T.plan) return;
  T.voice = wantVoice() && (T.voice || voiceHave());
  bridge.readUpdate({ engine: T.voice ? 'voice' : 'phone', voice: settings.ttsVoice, rate: settings.ttsRate });
}

// 그 전 껍데기 — 문단 하나씩
function ttsSay() {
  const T = R?.tts;
  if (!T?.on) return;
  while (T.g < R.blocks.length && !blockText(R.blocks[T.g])) T.g++;
  if (T.g >= R.blocks.length) { ttsStop(); toast('이 권을 끝까지 읽었어요'); return; }
  const el = R.blocks[T.g];
  T.id++;
  clearTimeout(T.turnT);
  // 이어 읽기면 첫 문단은 멈춘 묶음부터
  let text = blockText(el);
  let k = T.skip > 0 && T.skip < text.length ? T.skip : 0;
  while (k && text[k] === ' ') k++;
  T.base = k;
  T.skip = 0;
  if (T.base) text = text.slice(T.base);
  // 읽는 중에 목소리를 바꾸면 다음 문단부터(폰 음성 ↔ 새벽 음성도)
  const voice = wantVoice() && (T.voice || voiceHave());
  if (voice !== T.voice) { if (T.voice) bridge.ttsStop(); T.voice = voice; }
  ttsPara(T.g, T.base);
  if (T.voice) {
    let next = '';
    for (let g = T.g + 1; g < R.blocks.length && !next; g++) next = blockText(R.blocks[g]);
    bridge.voiceSpeak(text, T.id, settings.ttsRate, next, settings.ttsVoice);
  } else bridge.ttsSpeak(text, T.id, settings.ttsRate);
}

// 알림이 지금 읽는 문단의 것인가 — 목록(1.9)은 문단 번호, 그 전엔 넘긴 순번
const ttsMine = (T, id) => (T.plan ? +id >= 0 : String(T.id) === String(id));

window.onTtsDone = (id) => {
  if (id === 'try') { tryVoice = false; return; }
  const T = R?.tts;
  if (!T?.on || T.plan) return;   // 목록은 껍데기가 다음 문단을 잇는다
  if (ttsMine(T, id)) { T.g++; ttsSay(); }
};
// 묶음이 들리기 시작함(1.8+: off·len = 문단 글의 몇 번째 글자부터 몇 자 · ms = 그 묶음 소리 길이 · 1.7 은 첫 묶음에만 id 하나 · 폰 음성 목록은 len 0)
window.onTtsStart = (id, off, len, ms) => {
  const T = R?.tts;
  if (!T?.on || !ttsMine(T, id)) return;
  if (T.plan && +id !== T.g) { T.g = +id; ttsPara(T.g, off || 0); }   // 껍데기가 다음 문단으로 넘어감
  if (T.state === 'paused') T.state = 'playing';
  ttsLabel('');
  const t0 = T.base + (off || 0);
  if (R.ttsAt) R.ttsAt = { ...R.ttsAt, t: t0 };
  if (len > 0) { T.chunks = true; ttsFollow(t0, len, ms); }
};

// 폰 음성: 엔진이 읽는 낱말 자리를 알려 주면(껍데기 1.8+ · 엔진마다 다름) 쪽만 목소리에 맞춘다
window.onTtsRange = (id, start) => {
  const T = R?.tts;
  if (!T?.on || T.voice || R.scroll || !ttsMine(T, id) || (T.plan && +id !== T.g)) return;
  const el = R.blocks[T.g];
  const info = el && R.info.get(el);
  if (!info) return;
  const sc = screenOf({ s: info.s, b: info.b, o: rawOffset(el, T.base + start) });
  if (sc > R.screen) ttsTurn(sc);
};

// 껍데기 1.9 — 알림·잠금화면·이어폰 단추로 멈춤/이어서/그만 · 권 끝
window.onReadState = (st) => {
  const T = R?.tts;
  if (!T?.on || !T.plan) return;
  if (st === 'stopped') { ttsStop(true); return; }
  T.state = st;
  ttsLabel('');
};
window.onReadEnd = () => {
  if (!R?.tts?.on) return;
  ttsStop(true);
  toast('이 권을 끝까지 읽었어요');
};

// 화면을 다시 켜면 껍데기가 읽는 곳으로 맞춘다(꺼져 있는 동안 화면 쪽 알림은 늦게 오거나 몰려 온다)
function ttsSync() {
  const T = R?.tts;
  if (!T?.on || !T.plan) return;
  const n = bridge.readNow();
  if (!n || n.state === 'idle') { ttsStop(true); return; }
  T.state = n.state;
  ttsLabel('');
  if (+n.id >= 0) { T.g = +n.id; ttsPara(T.g, n.off || 0); }
}

// 빈칸을 줄인 글(blockText)의 t 번째 글자 → 문단 원래 글(textContent)의 자리
function rawOffset(el, t) {
  const s = ttsSrc(el);
  let i = 0;
  let k = 0;
  while (i < s.length && /\s/.test(s[i])) i++;
  while (i < s.length && k < t) {
    if (/\s/.test(s[i])) { while (i < s.length && /\s/.test(s[i])) i++; } else i++;
    k++;
  }
  return i;
}

// 지금 들리는 묶음만 칠하고, 쪽을 목소리에 맞춘다 — 사용자 «문단을 다 읽어야 쪽이 넘어가는데 음성에 따라 넘어가게»(10-27)
//   묶음이 다음 쪽에서 시작하면 바로, 묶음 안에서 쪽이 바뀌면 그 글자에 닿을 때(소리 길이 × 글자 비율) 넘긴다
function ttsFollow(t0, len, ms) {
  const T = R.tts;
  clearTimeout(T.turnT);
  const el = R.blocks[T.g];
  const info = el && R.info.get(el);
  if (!info) return;
  const t1 = Math.min(t0 + len, blockText(el).length);
  const at = (t) => { const [n, o] = locate(el, rawOffset(el, t)); return [n, o]; };
  try {
    const rg = document.createRange();
    rg.setStart(...at(t0));
    rg.setEnd(...at(t1));
    CSS.highlights?.set('tts', new Highlight(rg));
  } catch { /* 칠하기는 못 해도 읽기는 그대로 */ }
  const posOf = (t) => ({ s: info.s, b: info.b, o: rawOffset(el, t) });
  if (R.scroll) {
    const r = rectOfPos(posOf(t0));
    const v = $('#rd-view').getBoundingClientRect();
    if (r && (r.top < v.top || r.bottom > v.bottom - 24)) { $('#rd-view').scrollBy({ top: r.top - v.top - v.height / 3, behavior: 'smooth' }); }
    return;
  }
  const sc0 = screenOf(posOf(t0));
  if (sc0 !== R.screen) ttsTurn(sc0);
  // 묶음 안에서 처음으로 다음 쪽에 놓인 글자(쪽 번호는 글 순서대로 늘어난다 → 이분 탐색)
  if (t1 - t0 < 2 || screenOf(posOf(t1 - 1)) <= sc0) return;
  let lo = t0 + 1;
  let hi = t1 - 1;
  while (lo < hi) {
    const mid = (lo + hi) >> 1;
    if (screenOf(posOf(mid)) > sc0) hi = mid; else lo = mid + 1;
  }
  const sc1 = screenOf(posOf(lo));
  const tok = (T.tok = (T.tok || 0) + 1);
  T.turnT = setTimeout(() => { if (R?.tts?.on && R.tts.tok === tok) ttsTurn(sc1); }, (ms || 0) * ((lo - t0) / len));
}

// 다음 쪽이면 보통 넘김처럼(종이책·밀기 효과 그대로) — 화면이 꺼져 있거나 알림이 몰려 오면(1초 안에 또) 효과 없이
function ttsTurn(sc) {
  if (sc === R.screen) return;
  const now = performance.now();
  const burst = now - (R.ttsTurnAt || 0) < 1000;
  R.ttsTurnAt = now;
  if (sc === R.screen + 1 && !R.menu && !burst && document.visibilityState === 'visible') { turn(1); return; }
  if (sc < anchorScreen()) healAnchor();   // 읽던 문단 첫머리가 끊어 둔 곳 앞 쪽이면(듣기를 문단 처음부터) 원래대로 다시 나눠서
  setScreen(sc, false);
  R.pos = posAtScreen(sc);
  afterMove();
}
window.onVoiceError = (msg) => {
  if (tryVoice) { tryVoice = false; toast(`새벽 음성으로 못 읽었어요 · ${msg}`); return; }
  if (!R?.tts?.on) return;
  ttsStop();
  toast(`새벽 음성으로 못 읽었어요 · ${msg}`);
};
window.onTtsInterrupted = () => { if (R?.tts?.on && !R.tts.plan) ttsStop(); };   // 전화·다른 앱 소리(1.8 까지 · 1.9 는 껍데기가 멈췄다 이어서)
// already = 껍데기가 이미 그만둠(알림 ■ · 권 끝)
function ttsStop(already = false) {
  if (R?.tts?.on) {   // 멈춘 자리(R.ttsAt)를 진도와 같이 남긴다
    clearTimeout(R.saveT);
    R.saveT = setTimeout(saveProgress, 300);
  }
  if (R?.tts) { R.tts.on = false; clearTimeout(R.tts.turnT); }
  if (!already) bridge.ttsStop();
  CSS.highlights?.delete('tts');
  $('#rd-tts').hidden = true;
}

// 보기 설정 «들어 보기» — 고른 목소리·빠르기로 한 문장
function ttsTry() {
  if (R?.tts?.on) ttsStop();
  const line = '안녕하세요, 새벽글빛이에요. 오늘은 어떤 이야기를 읽어 드릴까요?';   // 🔴 책 글은 넣지 말 것(화면 묶음은 공개)
  if (settings.ttsVoice !== 'phone' && voiceHave()) { tryVoice = true; bridge.voiceSpeak(line, 'try', settings.ttsRate, '', settings.ttsVoice); }
  else bridge.ttsSpeak(line, 'try', settings.ttsRate);
}

// 새벽 음성 파일 받기 — 보기 설정이 열려 있으면 그 줄을 다시 그린다
window.onVoiceProgress = () => { if (R && !$('#rd-set').hidden) renderSettings(); };
window.onVoiceDone = (ok, msg) => {
  toast(ok ? '새벽 음성을 받았어요 · 이제 «듣기»가 새벽 음성으로 읽어요' : `새벽 음성을 다 못 받았어요 · ${msg}`);
  if (R && !$('#rd-set').hidden) renderSettings();
};

function voiceRows() {
  const MB = (n) => Math.round(n / 1e6);
  const speed = `<div class="srow"><div class="k">듣기 속도</div>${stepper('ttsRate', '듣기 속도', STEPS.ttsRate.fmt)}<button class="opt" data-a="tts-try">들어 보기</button></div>`;
  if (!bridge.canVoice()) {
    return `<div class="srow"><div class="k">목소리</div>${opt('ttsVoice', 'phone', '폰 음성')}${native ? '<span class="hint wrap">앱을 1.7 로 새로 깔면 자연스러운 «새벽 음성»을 쓸 수 있어요</span>' : ''}</div>${speed}`;
  }
  const v = bridge.voiceState() || {};
  let file;
  if (v.have) file = `<span class="hint">받아 둠 · ${MB(v.total)}MB</span><button class="opt" data-a="voice-del">지우기</button>`;
  else if (v.busy) file = `<span class="hint">받는 중 ${Math.floor((v.got / v.total) * 100)}% · ${MB(v.got)}/${MB(v.total)}MB</span><button class="opt" data-a="voice-stop">그만</button>`;
  else file = `<button class="opt" data-a="voice-get">받기 · ${MB(v.total || 401e6)}MB</button><span class="hint wrap">${v.error ? `못 받았어요(${esc(v.error)}) · 다시 누르면 이어서 받아요` : '와이파이에서 받으세요 · 한 번 받으면 인터넷 없이 읽어요'}</span>`;
  const voices = Object.entries(VOICES).map(([k, n]) => opt('ttsVoice', k, n)).join('');
  return `<div class="srow"><div class="k">목소리</div><div class="opts">${voices}${opt('ttsVoice', 'phone', '폰 음성')}</div></div>${speed}
    <div class="srow"><div class="k">새벽 음성</div>${file}</div>`;
}

// ---------------- 바깥에서 부르는 것 ----------------
export function handleBack() {
  if (!R) return false;
  if (R.tts?.on) { ttsStop(); return true; }
  if (!document.getSelection().isCollapsed) { document.getSelection().removeAllRanges(); hideSelPop(); return true; }
  if (!$('#note-pop').hidden) { hideNotePop(); return true; }
  return false;
}

export function onAppPause() { if (R) saveProgress(); }
export function onAppResume() { if (R) { enterReaderMode(); ttsSync(); } }
export function onThemeChange() { if (R) applyTheme(); }

export function initReader(hooks) {
  H = hooks;
  bindGestures();
  // 폴드를 펴고 접거나 돌리면 크기가 바뀐다 → 같은 문장으로 다시 나눈다
  diagInit(() => !!R);
  new ResizeObserver(() => {
    if (!R) return;
    const v = $('#rd-view');
    diagNote('ro', v.clientWidth, v.clientHeight);
    relayout(true);
  }).observe($('#rd-view'));
  addEventListener('resize', () => {
    if (!R) return;
    diagNote('resize', innerWidth, innerHeight);
    relayout(true);
  });
  // 받아 쓰는 글꼴은 앱을 켜면 미리 붙여 둔다 — 켜자마자 «이어 읽기»를 눌러도 글꼴을 기다리는 빈 쪽이 길지 않게(못 붙이면 열 때 다시)
  if (WEB_FONTS[settings.font]) setTimeout(() => loadFont(settings.font).catch(() => {}), 300);
  $('#rd-view').addEventListener('scroll', () => {
    if (!R?.scroll) return;
    clearTimeout(R.scrollT);
    R.scrollT = setTimeout(() => { R.pos = posAtScroll(); afterMove(Date.now() - lastTouch < 4000); }, 120);   // 손으로 민 것만(목차·열기의 자리 맞춤 스크롤 말고)
  }, { passive: true });
  document.addEventListener('selectionchange', onSelectionChange);
  $('#sel-pop').addEventListener('click', (e) => { const b = e.target.closest('[data-act]'); if (b) onSelAction(b.dataset.act); });
  $('#sel-pop').addEventListener('mousedown', (e) => e.preventDefault());
  $('#note-pop').addEventListener('click', onNotePop);
  $('#rd-back').onclick = () => H.close();
  $('#rd-search').onclick = () => openSearch();
  $('#rd-bm').onclick = toggleBookmark;
  $('#rd-set').addEventListener('click', onSettingsClick);
  $('#rd-set').addEventListener('change', onSettingsChange);
  $('#rd-nav').onclick = (e) => {
    const a = e.target.closest('[data-a]')?.dataset.a;
    if (a === 'toc') openToc();
    else if (a === 'set') toggleSettings();
    else if (a === 'bm') openNotes('bm');
    else if (a === 'notes') openNotes('hl');
    else if (a === 'tts') ttsStart();
  };
  const sl = $('#rd-slider');
  sl.oninput = () => {
    if (!R || R.scroll) return;
    $('#rd-ppage').innerHTML = `<b>${+sl.value + 1}</b> / ${R.screens}쪽`;
  };
  sl.onchange = () => {
    if (!R) return;
    if (R.scroll) {
      const v = $('#rd-view');
      v.scrollTop = (v.scrollHeight - v.clientHeight) * (+sl.value / 1000);
      return;
    }
    if (+sl.value < anchorScreen()) healAnchor();
    setScreen(+sl.value, false);
    R.pos = posAtScreen(R.screen);
    afterMove();
  };
  $('#rd-tts').onclick = () => { if (R?.tts?.plan && R.tts.state === 'paused') bridge.readResume(); else ttsStop(); };   // 알림에서 멈췄으면 «이어 듣기»
  window.onVolumeKey = (k) => { if (R && !R.menu) turn(k === 'down' ? 1 : -1); };
  window.onTtsError = () => { ttsStop(); toast('이 폰의 TTS(소리 내어 읽기)를 쓸 수 없어요'); };
  // 메모·검색 칸에서는 붙여넣기 같은 기본 메뉴가 필요하다
  document.addEventListener('focusin', (e) => { if (R && e.target.closest('input,textarea')) bridge.setNativeSelection(true); });
  document.addEventListener('focusout', (e) => { if (R && e.target.closest('input,textarea')) bridge.setNativeSelection(false); });
}
