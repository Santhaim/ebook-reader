// 그림 크게 보기 — 사용자 «표지 눌렀을 때 크게 보게 · 책 맨 앞 표지 확대 가능하게»(10-29)
//   검은 바탕에 그림 하나 · 두 손가락 벌리기 = 확대(1~6배 · 손가락 가운데를 기준으로) · 끌기 = 옮기기(확대했을 때)
//   두 번 톡 = 2.5배 ↔ 맞춤 · 한 번 톡 = 확대했으면 맞춤으로, 맞춤이면 닫기 · 뒤로 = 닫기 · PC: 휠 = 확대, 두 번 누르기, 누르기
//   읽기 화면에서 그림 위 두 손가락으로 시작한 벌리기는 그대로 이어받는다(opts.touches) — 손가락 이벤트는 document 에서 받는다
//   opts.later = 더 선명한 그림을 줄 약속(묶음 표지: 서재의 작은 표지를 먼저 띄우고 책 안의 원본으로 바꿔 끼움 · 닫을 때 URL 해제)
import { pushLayer } from './ui.js';
import { bridge } from './native.js';
import { applyAppTheme } from './settings.js';

const MAX = 6;
let open = null;

export function openZoom(src, { later = null, touches = null } = {}) {
  if (open) open.close();
  const el = document.createElement('div');
  el.className = 'zoom';
  el.innerHTML = '<img alt=""><div class="zhint">두 손가락으로 확대 · 두 번 톡 = 크게 · 한 번 톡 = 닫기</div>';
  const img = el.querySelector('img');
  img.src = src;
  document.body.appendChild(el);
  requestAnimationFrame(() => el.classList.add('on'));
  if (!document.body.classList.contains('reading')) bridge.setBars('#000000', false);
  setTimeout(() => el.querySelector('.zhint')?.classList.add('off'), 2200);

  let s = 1;
  let tx = 0;
  let ty = 0;
  let laterUrl = null;
  const W = () => el.clientWidth;
  const H = () => el.clientHeight;
  const clampT = () => {
    if (s <= 1) { s = Math.max(s, 1); tx = 0; ty = 0; return; }
    tx = Math.min(0, Math.max(W() - W() * s, tx));
    ty = Math.min(0, Math.max(H() - H() * s, ty));
  };
  const draw = (anim) => {
    img.style.transition = anim ? 'transform .18s ease-out' : 'none';
    img.style.transform = `translate(${tx}px, ${ty}px) scale(${s})`;
  };
  // 화면 점 (fx, fy) 아래 그림 자리를 그대로 두고 배율만 바꾸기
  const zoomAt = (fx, fy, s1, anim) => {
    s1 = Math.min(MAX, Math.max(1, s1));
    tx = fx - (fx - tx) * (s1 / s);
    ty = fy - (fy - ty) * (s1 / s);
    s = s1;
    clampT();
    draw(anim);
  };

  // 손가락 — pinch: 시작 배율·자리·두 손가락 거리·가운데 / pan: 시작 자리·손가락
  let gest = null;
  let tap = null;   // 두 번 톡을 기다리는 한 번 톡
  const dist = (a, b) => Math.hypot(a.clientX - b.clientX, a.clientY - b.clientY);
  const mid = (a, b) => [(a.clientX + b.clientX) / 2, (a.clientY + b.clientY) / 2];
  const startPinch = (a, b) => { const [mx, my] = mid(a, b); gest = { kind: 'pinch', s0: s, tx0: tx, ty0: ty, d0: Math.max(10, dist(a, b)), mx, my }; };
  if (touches && touches.length >= 2) startPinch(touches[0], touches[1]);

  const onStart = (e) => {
    if (e.touches.length >= 2) { e.preventDefault(); startPinch(e.touches[0], e.touches[1]); return; }
    if (!el.contains(e.target)) return;
    e.preventDefault();
    const t = e.touches[0];
    gest = { kind: 'pan', x: t.clientX, y: t.clientY, tx0: tx, ty0: ty, moved: false, t: Date.now() };
  };
  const onMove = (e) => {
    if (!gest) return;
    e.preventDefault();
    if (gest.kind === 'pinch' && e.touches.length >= 2) {
      const [a, b] = [e.touches[0], e.touches[1]];
      const [mx, my] = mid(a, b);
      const s1 = Math.min(MAX, Math.max(0.6, gest.s0 * (dist(a, b) / gest.d0)));   // 조금 덜 줄어드는 것까지 따라가고 손을 떼면 맞춤으로
      tx = mx - (gest.mx - gest.tx0) * (s1 / gest.s0);
      ty = my - (gest.my - gest.ty0) * (s1 / gest.s0);
      s = s1;
      if (s >= 1) clampT();
      draw(false);
      return;
    }
    if (gest.kind === 'pan') {
      const t = e.touches[0];
      const dx = t.clientX - gest.x;
      const dy = t.clientY - gest.y;
      if (!gest.moved && Math.hypot(dx, dy) < 10) return;
      gest.moved = true;
      if (s > 1) { tx = gest.tx0 + dx; ty = gest.ty0 + dy; clampT(); draw(false); }
    }
  };
  const onEnd = (e) => {
    if (!gest) return;
    const g = gest;
    if (e.touches.length >= 2) return;
    if (g.kind === 'pinch') {
      // 두 손가락 중 하나만 뗐으면 남은 손가락으로 옮기기를 잇는다
      gest = e.touches.length === 1 ? { kind: 'pan', x: e.touches[0].clientX, y: e.touches[0].clientY, tx0: tx, ty0: ty, moved: true, t: 0 } : null;
      if (s < 1) { s = 1; clampT(); draw(true); }
      return;
    }
    gest = null;
    e.preventDefault();
    if (g.moved || Date.now() - g.t > 450) return;
    tapped(g.x, g.y);
  };
  const tapped = (x, y) => {
    if (tap && Date.now() - tap.t < 300 && Math.hypot(x - tap.x, y - tap.y) < 40) {
      clearTimeout(tap.timer);
      tap = null;
      if (s > 1.05) { s = 1; clampT(); draw(true); } else zoomAt(x, y, 2.5, true);
      return;
    }
    clearTimeout(tap?.timer);
    tap = { t: Date.now(), x, y, timer: setTimeout(() => { tap = null; if (s > 1.05) { s = 1; clampT(); draw(true); } else close(); }, 280) };
  };
  // PC(시험·마우스)
  const onWheel = (e) => { e.preventDefault(); zoomAt(e.clientX, e.clientY, s * (e.deltaY < 0 ? 1.25 : 0.8), true); };
  const onClick = (e) => { if (e.sourceCapabilities?.firesTouchEvents) return; tapped(e.clientX, e.clientY); };

  const opts = { capture: true, passive: false };
  document.addEventListener('touchstart', onStart, opts);
  document.addEventListener('touchmove', onMove, opts);
  document.addEventListener('touchend', onEnd, opts);
  document.addEventListener('touchcancel', onEnd, opts);
  el.addEventListener('wheel', onWheel, { passive: false });
  el.addEventListener('click', onClick);
  const unpush = pushLayer(() => close());

  if (later) {
    Promise.resolve(later).then((u) => {
      if (!u) return;
      if (!open || open.el !== el) { URL.revokeObjectURL(u); return; }
      laterUrl = u;
      const pre = new Image();
      pre.onload = () => { if (open?.el === el) img.src = u; };   // 다 받은 뒤 바꿔 끼워 빈 틈이 없게
      pre.src = u;
    }).catch(() => {});
  }

  function close() {
    if (!open || open.el !== el) return;
    open = null;
    unpush();
    clearTimeout(tap?.timer);
    document.removeEventListener('touchstart', onStart, opts);
    document.removeEventListener('touchmove', onMove, opts);
    document.removeEventListener('touchend', onEnd, opts);
    document.removeEventListener('touchcancel', onEnd, opts);
    el.classList.remove('on');
    setTimeout(() => { el.remove(); if (laterUrl) URL.revokeObjectURL(laterUrl); }, 180);
    if (!document.body.classList.contains('reading')) applyAppTheme();
  }
  open = { el, close, state: () => ({ s, tx, ty }) };
  return open;
}

export const zoomOpen = () => !!open;
export const zoomState = () => open?.state() || null;
