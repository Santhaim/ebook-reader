// 번역기와 주고받는 우편함 — 비공개 GitHub 저장소(기본 Santhaim/ebook-reports)
//   제보: 앱이 main 가지 inbox/ 에 올리고, PC 번역기 세션이 ebook-reader/tools/fetch_reports.py 로 가져가 지운다.
//   질문에 단 답·클로드 답에 단 답글: answers/ (같이 가져감) · 클로드의 결과 쪽지: replies/ (fetchReplies)
//   고친 권: PC 가 ebook-reader/tools/push_books.py 로 books 가지에 올리고(늘 최신 판만), 앱이 열 때 바뀐 권만 받는다.
//   열쇠(fine-grained 토큰 · 이 저장소 Contents 읽기/쓰기만)는 사용자가 앱에 직접 붙여 넣는다 — 이 폰 안에만 저장.
import { db } from './db.js';
import { volName, reportText } from './books.js';
import { bridge } from './native.js';
import { importFiles } from './importer.js';
import { noteMoves, applyMoves, hasPendingMoves } from './regroup.js';

const KEY = 'ebook.reports.v1';
const API = 'https://api.github.com';
export const DEFAULT_REPO = 'Santhaim/ebook-reports';

export function inboxConf() {
  try { return JSON.parse(localStorage.getItem(KEY) || 'null'); } catch { return null; }
}
export function saveInbox(conf) { localStorage.setItem(KEY, JSON.stringify(conf)); }
export function clearInbox() { localStorage.removeItem(KEY); }

// 폰 이름: 사용자 에이전트의 모델 번호(SM-S948N = S26 울트라 · SM-F946N = 폴드5)
export function deviceName() {
  const m = navigator.userAgent.match(/;\s*(SM-[A-Z0-9]+)/);
  return m ? m[1] : 'phone';
}

async function gh(conf, method, path, body) {
  const r = await fetch(`${API}/repos/${conf.repo}/${path}`, {
    method,
    headers: {
      Authorization: `Bearer ${conf.token}`,
      Accept: 'application/vnd.github+json',
      'X-GitHub-Api-Version': '2022-11-28',
      ...(body ? { 'Content-Type': 'application/json' } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
    // GitHub API 는 max-age=60 — 그대로 두면 WebView 가 1분 묵은 목록·sha 를 준다(10-28 S26 이 방금 올린 seen/PC.json 을 못 봄)
    cache: 'no-store',
  });
  if (!r.ok) {
    const e = new Error(`${r.status}`);
    e.status = r.status;
    throw e;
  }
  return r.status === 204 ? null : r.json();
}

const b64 = (s) => {
  let bin = '';
  for (const x of new TextEncoder().encode(s)) bin += String.fromCharCode(x);
  return btoa(bin);
};

export function explain(e) {
  if (e.status === 401) return '열쇠가 맞지 않아요(만료됐거나 잘못 붙여 넣었어요)';
  if (e.status === 403) return '열쇠에 쓰기 권한이 없어요(Contents: Read and write)';
  if (e.status === 404) return '저장소를 못 찾았어요(이름 또는 열쇠의 저장소 선택 확인)';
  return '보내지 못했어요 · 인터넷 연결을 확인해 주세요';
}

// 연결 확인 = 이 폰 이름표(devices/<모델>.json)를 써 본다 — 열쇠·저장소·쓰기 권한을 한 번에 확인
export async function testInbox(conf) {
  const path = `contents/devices/${deviceName()}.json`;
  let sha;
  try {
    sha = (await gh(conf, 'GET', path)).sha;
  } catch (e) {
    if (e.status !== 404) throw e;
  }
  const body = JSON.stringify({ device: deviceName(), app: bridge.version(), checkedAt: new Date().toISOString() }, null, 1);
  await gh(conf, 'PUT', path, { message: `연결 확인 ${deviceName()}`, content: b64(body), ...(sha ? { sha } : {}) });
}

// 아직 안 보낸 제보를 한 파일로 올리고 보냄 표시
export async function sendPending() {
  const conf = inboxConf();
  if (!conf) return { sent: 0, skipped: true };
  const [notes, books] = await Promise.all([db.all('notes'), db.all('books')]);
  const reps = notes.filter((n) => n.type === 'report' && !n.sentAt);
  if (!reps.length) return { sent: 0 };
  const bm = new Map(books.map((b) => [b.id, b]));
  const now = new Date();
  const stamp = now.toISOString().replace(/[-:]/g, '').replace(/\..+/, '').replace('T', '-');
  const name = `inbox/${stamp}-${deviceName()}-${Math.random().toString(36).slice(2, 6)}.json`;
  const items = reps.map((n) => {
    const b = bm.get(n.bookId);
    return {
      id: n.id,
      vol: b ? volName(b) : n.vol || '',
      series: b?.series || null,
      index: b?.seriesIndex ?? null,
      chap: n.chap || '',
      sentence: n.ctx?.sent || n.text,
      picked: n.text,
      prev: n.ctx?.prev || '',
      next: n.ctx?.next || '',
      note: n.note || '',
      at: new Date(n.at).toISOString(),
      pos: n.a,
    };
  });
  const doc = { device: deviceName(), sentAt: now.toISOString(), count: items.length, text: reportText(reps, bm), items };
  await gh(conf, 'PUT', `contents/${name}`, { message: `제보 ${items.length}건 (${deviceName()})`, content: b64(JSON.stringify(doc, null, 1)) });
  for (const n of reps) {
    n.sentAt = now.getTime();
    await db.put('notes', n);
  }
  return { sent: reps.length, ids: reps.map((n) => n.id), at: now.getTime() };
}

async function ghRaw(conf, path) {
  const r = await fetch(`${API}/repos/${conf.repo}/${path}`, {
    headers: { Authorization: `Bearer ${conf.token}`, Accept: 'application/vnd.github.raw', 'X-GitHub-Api-Version': '2022-11-28' },
    cache: 'no-store',
  });
  if (!r.ok) {
    const e = new Error(`${r.status}`);
    e.status = r.status;
    throw e;
  }
  return r;
}

const stampOf = (d) => d.toISOString().replace(/[-:]/g, '').replace(/\..+/, '').replace('T', '-');

// 질문의 답 — 이 폰에서 단 답 → 쪽지에 실려 온 답(다른 폰에서 단 것) → 그 답대로 고친 쪽지가 왔으면 «답함»
export function answerOf(it, list) {
  if (it.answered || it.answer) return it.answered || it.answer;
  const done = list.find((x) => x.reply === it.id);
  return done ? done.answer || {} : null;
}

// 결과 쪽지 받기 — 클로드가 replies/ 에 남긴 쪽지(고침·그대로 둠·질문)를 news 에 담는다.
//   받은 파일은 폰마다 «이름 → sha»로 기억 — 고쳐 다시 올린 쪽지(sha 가 바뀜)도 다시 받는다(읽음·답함은 그대로)
const SEEN_KEY = 'ebook.replies.sha';
export async function fetchReplies() {
  const conf = inboxConf();
  if (!conf) return { added: 0, changed: 0, questions: 0 };
  let list;
  try {
    list = await gh(conf, 'GET', 'contents/replies');
  } catch (e) {
    if (e.status === 404) return { added: 0, changed: 0, questions: 0 };
    throw e;
  }
  let seen;
  try { seen = JSON.parse(localStorage.getItem(SEEN_KEY) || '{}') || {}; } catch { seen = {}; }
  const files = list.filter((f) => f.type === 'file' && f.name.endsWith('.json'));
  const fresh = files.filter((f) => seen[f.name] !== f.sha).sort((a, b) => a.name.localeCompare(b.name));
  const added = new Set();
  for (const f of fresh) {
    const doc = await (await ghRaw(conf, `contents/${f.path}`)).json();
    let seq = 0;
    for (const it of doc.items || []) {
      if (!it.id) continue;
      const old = await db.get('news', it.id);
      await db.put('news', { ...it, seq: seq++, file: f.name, at: doc.at || old?.at || new Date().toISOString(), read: old?.read || false, answered: old?.answered || null, comments: old?.comments || null });
      if (!old) added.add(it.id);
    }
    seen[f.name] = f.sha;
  }
  const names = new Set(files.map((f) => f.name));
  for (const k of Object.keys(seen)) if (!names.has(k)) delete seen[k];   // 60일 지나 우편함에서 지운 쪽지
  localStorage.setItem(SEEN_KEY, JSON.stringify(seen));
  localStorage.removeItem('ebook.replies.seen');   // 화면 판 12까지 쓰던 이름 목록
  const synced = await pullSeen(conf).catch(() => 0);   // 다른 폰에서 읽은 것·단 답(아래)
  pushSeen();   // 이 폰 것도(바뀐 게 없으면 안 올림) — 앱을 켤 때 한 번은 올라가야 다른 폰이 이미 읽어 둔 것도 맞춘다
  const all = added.size ? await db.all('news') : [];
  const questions = all.filter((it) => added.has(it.id) && it.status === 'question' && !answerOf(it, all)).length;
  return { added: added.size, changed: fresh.length, questions, synced };
}

// ---------------- 읽음·답함을 폰끼리 맞추기(화면 판 26) ----------------
//   사용자 «폴드에서 답한 게 S26 에서도 보이는데 알림(종 숫자)은 안 사라져»(10-28) — 읽음·답함·답글이 폰마다 따로였다
//   폰마다 seen/<모델>.json 에 «읽은 쪽지 id · 단 답 · 단 답글»(최근 120일)을 올리고, 쪽지를 받을 때 다른 폰 것을 받아 같게 한다
//   PC 도구(fetch_reports·wait_reports·reply)는 seen/ 을 보지 않는다
const SEEN_SHAS = 'ebook.seen.sha';    // 다른 폰 파일 이름 → sha(이미 맞춘 것)
const SEEN_MINE = 'ebook.seen.mine';   // 내 파일 { sha, sig }

async function pullSeen(conf) {
  let files;
  try { files = await gh(conf, 'GET', 'contents/seen'); } catch (e) { if (e.status === 404) return 0; throw e; }
  let shas;
  try { shas = JSON.parse(localStorage.getItem(SEEN_SHAS) || '{}') || {}; } catch { shas = {}; }
  const mine = `${deviceName()}.json`;
  let changed = 0;
  for (const f of files) {
    if (f.type !== 'file' || f.name === mine || shas[f.name] === f.sha) continue;
    const doc = await (await ghRaw(conf, `contents/${f.path}`)).json();
    const touch = async (id, fn) => {
      const it = await db.get('news', id);
      if (it && fn(it)) { it.read = true; await db.put('news', it); changed++; }
    };
    for (const id of doc.ids || []) await touch(id, (it) => !it.read);
    for (const [id, a] of Object.entries(doc.answered || {})) await touch(id, (it) => !it.answered && !it.answer && (it.answered = a));
    for (const [id, cs] of Object.entries(doc.comments || {})) {
      await touch(id, (it) => {
        const have = new Set((it.comments || []).map((c) => c.id));
        const add = (cs || []).filter((c) => c?.id && !have.has(c.id));
        if (!add.length) return false;
        it.comments = [...(it.comments || []), ...add].sort((a, b) => (a.at || 0) - (b.at || 0));
        return true;
      });
    }
    shas[f.name] = f.sha;
  }
  localStorage.setItem(SEEN_SHAS, JSON.stringify(shas));
  return changed;
}

// 이 폰의 읽음·답함을 올린다 — 쪽지를 읽거나 답·답글을 단 뒤(바뀐 게 없으면 안 올림 · 겹치면 한 번 더)
let pushing = false;
let pushAgain = false;
export async function pushSeen() {
  const conf = inboxConf();
  if (!conf) return;
  if (pushing) { pushAgain = true; return; }
  pushing = true;
  try {
    do { pushAgain = false; await pushSeenOnce(conf); } while (pushAgain);
  } catch { /* 다음에 다시 */ } finally { pushing = false; }
}

async function pushSeenOnce(conf) {
  const since = Date.now() - 120 * 864e5;
  const list = (await db.all('news')).filter((it) => (Date.parse(it.at || 0) || 0) > since).sort((a, b) => String(a.id).localeCompare(String(b.id)));
  const ids = list.filter((it) => it.read).map((it) => it.id);
  const answered = {};
  const comments = {};
  for (const it of list) {
    if (it.answered) answered[it.id] = it.answered;
    if (it.comments?.length) comments[it.id] = it.comments;
  }
  const sig = JSON.stringify({ ids, answered, comments });
  let mine;
  try { mine = JSON.parse(localStorage.getItem(SEEN_MINE) || '{}') || {}; } catch { mine = {}; }
  if (mine.sig === sig) return;
  const path = `contents/seen/${deviceName()}.json`;
  const body = (sha) => ({
    message: `읽음 맞추기 (${deviceName()})`,
    content: b64(JSON.stringify({ device: deviceName(), at: new Date().toISOString(), ids, answered, comments }, null, 1)),
    ...(sha ? { sha } : {}),
  });
  let r;
  try {
    r = await gh(conf, 'PUT', path, body(mine.sha));
  } catch (e) {
    if (e.status !== 409 && e.status !== 422) throw e;   // 처음이거나 sha 가 옛것 → 지금 sha 로 한 번 더
    let cur = null;
    try { cur = (await gh(conf, 'GET', path)).sha; } catch (e2) { if (e2.status !== 404) throw e2; }
    r = await gh(conf, 'PUT', path, body(cur));
  }
  localStorage.setItem(SEEN_MINE, JSON.stringify({ sha: r?.content?.sha || null, sig }));
}

// 질문에 답하기 — answers/ 에 올리면 PC 지키미가 클로드(번역기 세션)를 깨운다
export async function sendAnswer(item, choice, text) {
  const conf = inboxConf();
  if (!conf) throw Object.assign(new Error('no-inbox'), { status: 0 });
  const now = new Date();
  const doc = {
    device: deviceName(),
    at: now.toISOString(),
    items: [{ reply: item.id, report: item.report || null, vol: item.vol, chap: item.chap || '', question: item.question || '', choice: choice || null, text: text || '' }],
  };
  const name = `answers/${stampOf(now)}-${deviceName()}-${Math.random().toString(36).slice(2, 6)}.json`;
  await gh(conf, 'PUT', `contents/${name}`, { message: `질문에 답 (${deviceName()})`, content: b64(JSON.stringify(doc, null, 1)) });
  item.answered = { choice: choice || null, text: text || '', at: now.getTime() };
  item.read = true;
  await db.put('news', item);
  pushSeen();   // 다른 폰도 «답함»으로
}

// 클로드 답에 답글 — 고친 문장·그대로 둔 답에 덧붙이는 말. answers/ 에 kind:'comment' 로 올린다(지키미가 클로드를 깨움)
//   클로드가 답글대로 다시 손본 결과는 reply = 이 쪽지 · comment = 답글 id 로 온다(reply.py 가 이어 줌)
export async function sendComment(item, text) {
  const conf = inboxConf();
  if (!conf) throw Object.assign(new Error('no-inbox'), { status: 0 });
  const now = new Date();
  const c = { id: `c-${now.getTime().toString(36)}${Math.random().toString(36).slice(2, 5)}`, text, at: now.getTime() };
  const doc = {
    device: deviceName(),
    at: now.toISOString(),
    items: [{
      kind: 'comment', id: c.id, reply: item.id, report: item.report || null, vol: item.vol, chap: item.chap || '',
      status: item.status, before: item.before || '', after: item.after || '', why: item.why || '', memo: item.memo || '', text,
    }],
  };
  const name = `answers/${stampOf(now)}-${deviceName()}-${Math.random().toString(36).slice(2, 6)}.json`;
  await gh(conf, 'PUT', `contents/${name}`, { message: `답글 (${deviceName()})`, content: b64(JSON.stringify(doc, null, 1)) });
  const cur = (await db.get('news', item.id)) || item;   // 읽기 화면에서 단 답글이면 item 이 옛것일 수 있다
  cur.comments = [...(cur.comments || []), c];
  cur.read = true;
  await db.put('news', cur);
  Object.assign(item, { comments: cur.comments, read: true });
  pushSeen();   // 다른 폰에도 이 답글이 보이게
  return c;
}

// 고친 권 받기 — books/index3.json 과 내 서재를 견줘 «내용이 바뀐 권»과 새 권만 받아 넣는다(새 판으로 바꿔 끼움)
//   견주는 값 = 내용 해시(수정 시각은 뺀 것 · push_books.py 가 계산) → 같은 판을 다시 받지 않는다
//   index2.json(화면 판 20부터 · v 2): 그 목록에 있는 묶음은 목록이 정본 — 목록에 없는 권(다시 묶여 없어진 권)은 서재에서 뺀다
//     옛 화면 판은 index.json 만 보는데 push_books.py 가 그건 비워 둔다 → 옛 판은 다시 묶은 권을 옛 방식(같은 번호 = 같은 자리)으로 못 바꿔 끼운다
//   index3.json(화면 판 32부터 · v 3): 장 번호를 부마다 다시 매긴 권(목차 data-n)이 들어온 뒤의 정본 — 판 31 이하는 그 권의 장 열쇠를
//     보이는 번호로 만들어 읽던 자리가 지워지거나 다른 장으로 간다 → push_books.py 가 index2.json 도 빈 목록으로 둔다(10-31)
//   바꿔 끼울 땐 읽던 자리·다 읽음·메모를 «같은 장»으로 옮긴다(regroup.js) · 다 받은 뒤에 바꾼다(받다가 끊기면 아무것도 안 바뀜)
//   받은 권은 한 권씩 따로 담아 둔다(dl · 내용 해시로) — 다 받기 전에 앱을 끄거나 화면 새 판으로 다시 떠도 다음엔 남은 권만 받는다
//     (사용자 «앱을 껐다 켜도 권이 안 바뀜» 10-31: 바뀐 권 66권 ≈53MB 를 한 번에 다 받아야만 바꿨다 — 받다 끄면 매번 처음부터)
//   읽는 중인 권만 그대로 두고(받아는 둔다) 나머지는 바로 바꿔 끼운다 → 그 권은 덮은 뒤 다음 확인 때(main.js booksLater)
async function bookIndex(conf) {
  for (const name of ['index3.json', 'index2.json', 'index.json']) {
    try {
      return await (await ghRaw(conf, `contents/books/${name}?ref=books`)).json();
    } catch (e) {
      if (e.status !== 404) throw e;
    }
  }
  return null;
}

// 받아 둔 권(아직 안 바꿔 끼운 것) — 서재 DB(ebook)와 따로 둔 작은 DB: 판 번호를 올리지 않아 옛 화면 판이 떠도 서재 DB 는 그대로 열린다
const dl = (() => {
  let opening = null;
  const open = () => (opening ||= new Promise((resolve, reject) => {
    const r = indexedDB.open('ebook-dl', 1);
    r.onupgradeneeded = () => r.result.createObjectStore('files');
    r.onsuccess = () => resolve(r.result);
    r.onerror = () => reject(r.error);
  }));
  const run = async (mode, fn) => {
    const req = fn((await open()).transaction('files', mode).objectStore('files'));
    return new Promise((resolve, reject) => { req.onsuccess = () => resolve(req.result); req.onerror = () => reject(req.error); });
  };
  return {
    get: (k) => run('readonly', (s) => s.get(k)),
    put: (k, blob) => run('readwrite', (s) => s.put(blob, k)),
    del: (k) => run('readwrite', (s) => s.delete(k)),
    keys: () => run('readonly', (s) => s.getAllKeys()),
  };
})();

// 바꿔 끼우는 중(그동안은 책을 안 연다 — 열린 권이 바뀌는 중인 권일 수 있다 · main.js)
let applying = false;
export const booksApplying = () => applying;

// 한 번에 하나만(겹쳐 돌면 같은 권을 두 번 바꿔 끼우고 옮긴다)
//   busy() = 지금 읽는(여는) 중인 권 id 또는 그 목록(그 권은 받아만 두고 안 바꿈) · onStep(«get»|«put», i, n) = 받기·넣기 진행
let updating = null;
export function fetchBookUpdates(opts = {}) {
  updating ||= updateBooks(opts).finally(() => { updating = null; });
  return updating;
}

async function updateBooks({ busy = () => null, onStep = null } = {}) {
  const conf = inboxConf();
  if (!conf) return null;
  const idx = await bookIndex(conf);
  if (!idx) return { none: true };
  const entries = idx.books || [];
  const keyOf = (e) => (e.series && e.index != null ? `s:${e.series}|${e.index}` : null);
  const local = await db.all('books');
  const byId = new Map(local.map((b) => [b.id, b]));
  const want = entries.filter((e) => {
    const b = keyOf(e) ? byId.get(keyOf(e)) : local.find((x) => x.fileName === e.file);
    return !b || b.chash !== e.hash;
  });
  const series = new Set(entries.map((e) => e.series).filter(Boolean));
  const listed = new Set(entries.map(keyOf).filter(Boolean));
  const gone = idx.v >= 2 ? local.filter((b) => b.series && series.has(b.series) && !listed.has(b.id)) : [];
  const res = { added: [], replaced: [], same: [], failed: [], removed: [], moved: 0, skipped: 0 };
  // 받아 둔 것 중 이번에 받을 판이 아닌 것(그사이 또 고쳐진 권의 옛 판 · 이미 넣은 것)은 버린다
  const need = new Set(want.map((e) => e.hash));
  for (const k of await dl.keys()) if (!need.has(k)) await dl.del(k);
  if (!want.length && !gone.length) {
    if (hasPendingMoves()) Object.assign(res, await applyMoves());   // 앞서 바꿔 끼우다 끊긴 것 마저
    return res;
  }
  let got = 0;
  for (const e of want) {
    if (!(await dl.get(e.hash))) await dl.put(e.hash, await (await ghRaw(conf, `contents/${e.path}?ref=books`)).blob());
    onStep?.('get', ++got, want.length);
  }
  // 다 받았다 — 읽는 중인 권만 빼고 바꿔 끼운다(지금 판으로 다시 봄: 받는 사이에 책을 열었을 수 있다)
  const open = new Set([busy()].flat().filter(Boolean));
  const now = want.filter((e) => !open.has(keyOf(e)));
  const later = gone.filter((b) => open.has(b.id));
  res.skipped = want.length - now.length + later.length;
  if (!now.length && gone.length === later.length) return res;
  applying = true;
  try {
    const files = [];
    const meta = {};
    for (const e of now) {
      files.push(new File([await dl.get(e.hash)], e.file, { type: 'application/epub+zip' }));
      meta[e.file] = { chash: e.hash };
    }
    const old = now.map((e) => byId.get(keyOf(e)) || local.find((x) => !keyOf(e) && x.fileName === e.file)).filter(Boolean);
    await noteMoves(old, gone.filter((b) => !open.has(b.id)), now.map((e) => keyOf(e)).filter(Boolean));
    Object.assign(res, await importFiles(files, (i, n) => onStep?.('put', i, n), meta));
    Object.assign(res, await applyMoves());
    for (const e of now) await dl.del(e.hash);
  } finally {
    applying = false;
  }
  return res;
}
