// 서재(묶음 표지 격자) · 묶음 안(권 목록) · 제보 모음
import { db } from './db.js';
import { settings, setSetting } from './settings.js';
import { $, $$, esc, icon, toast, sheet, ask, actionSheet, onLongPress, fmtDate } from './ui.js';
import { byIndex, byPos, isNewBook, isNewEdition, volName, volNum, volPad, reportText, markQuote } from './books.js';
import { bridge } from './native.js';
import { inboxConf, saveInbox, clearInbox, testInbox, sendPending, deviceName, explain, DEFAULT_REPO } from './reports.js';
import { openNews, renderNewsBadge, fixCounts, resultsByReport, resultChip } from './news.js';

let H = {};          // main 이 넘겨주는 것: openSeries, openBook, importClick, devImport, appTheme
let query = '';
let part = 0;        // 묶음 안 «부» 탭(0 = 전체)
let seriesKey = null;

const coverUrls = new Map();
async function coverUrl(id) {
  if (!coverUrls.has(id)) {
    const blob = await db.get('covers', id);
    coverUrls.set(id, blob ? URL.createObjectURL(blob) : null);
  }
  return coverUrls.get(id);
}
export function dropCover(id) {
  const u = coverUrls.get(id);
  if (u) URL.revokeObjectURL(u);
  coverUrls.delete(id);
}
function fillCovers(root) {
  for (const img of $$('img[data-cover]', root)) {
    coverUrl(img.dataset.cover).then((u) => { if (u) img.src = u; });
  }
}
const hue = (s) => [...s].reduce((h, c) => (h * 31 + c.charCodeAt(0)) % 360, 7);

async function loadBooks() {
  const [books, progress] = await Promise.all([db.all('books'), db.all('progress')]);
  const pm = new Map(progress.map((p) => [p.id, p]));
  for (const b of books) b.p = pm.get(b.id) || null;
  return books;
}

function summarize(list) {
  const done = list.filter((b) => b.p?.done).length;
  return {
    done,
    all: done === list.length,
    reading: list.filter((b) => b.p && !b.p.done).sort((a, b) => b.p.at - a.p.at)[0] || null,
    last: Math.max(0, ...list.map((b) => b.p?.at || 0)),
    added: Math.max(0, ...list.map((b) => b.addedAt || 0)),
    fresh: list.some((b) => isNewBook(b) || isNewEdition(b)),
  };
}

function makeItems(books) {
  const items = [];
  const bySeries = new Map();
  for (const b of books) {
    if (!b.series) { items.push({ kind: 'book', key: b.id, title: b.title, books: [b] }); continue; }
    let it = bySeries.get(b.series);
    if (!it) {
      it = { kind: 'series', key: b.series, title: b.series, books: [] };
      bySeries.set(b.series, it);
      items.push(it);
    }
    it.books.push(b);
  }
  for (const it of items) {
    it.books.sort(byIndex);
    Object.assign(it, summarize(it.books));
  }
  return items;
}

function status(it) {
  if (it.all) return { text: '다 읽음', pct: 100, done: true };
  if (it.kind === 'series') {
    const cur = it.reading;
    const pct = ((it.done + (cur ? (cur.p.pct || 0) / 100 : 0)) / it.books.length) * 100;
    if (cur) return { text: `${volNum(cur)}권 읽는 중`, pct };
    if (it.done) return { text: `${it.done}/${it.books.length}권 읽음`, pct };
    return { text: '안 읽음', pct: 0 };
  }
  const p = it.books[0].p;
  return p?.pct > 0 ? { text: `${Math.floor(p.pct)}% 읽음`, pct: p.pct } : { text: '안 읽음', pct: 0 };
}

function coverHtml(book, title, extra = '') {
  return `<span class="ph" style="--h:${hue(title)}">${esc(title)}</span><img data-cover="${esc(book.id)}" alt="">${extra}`;
}

function cardHtml(it) {
  const st = status(it);
  const stack = it.kind === 'series' && it.books.length > 1;
  const extra = (it.kind === 'series' ? `<span class="cnt">${it.books.length}권</span>` : '') + (it.fresh ? '<span class="newb">N</span>' : '');
  return `<button class="card" data-kind="${it.kind}" data-key="${esc(it.key)}">
    <div class="cv${stack ? ' stack' : ''}">${coverHtml(it.books[0], it.title, extra)}</div>
    <div class="tt">${esc(it.title)}</div>
    <div class="ss">${esc(st.text)}</div>
    <div class="pb${st.done ? ' done' : ''}"><i style="width:${st.pct.toFixed(1)}%"></i></div>
  </button>`;
}

export async function renderLibrary() {
  const books = await loadBooks();
  let items = makeItems(books);
  const any = items.length > 0;
  if (settings.libFilter === 'reading') items = items.filter((it) => !it.all && (it.reading || it.done > 0));
  if (settings.libFilter === 'done') items = items.filter((it) => it.all);
  const q = query.trim();
  if (q) items = items.filter((it) => it.title.includes(q) || it.books.some((b) => b.title.includes(q)));
  const sort = settings.libSort;
  items.sort(sort === 'title' ? (a, b) => a.title.localeCompare(b.title, 'ko')
    : sort === 'added' ? (a, b) => b.added - a.added
      : (a, b) => b.last - a.last || b.added - a.added);

  $$('#lib-chips .chip').forEach((c) => c.classList.toggle('on', c.dataset.f === settings.libFilter));
  $('#lib-sort-label').textContent = { recent: '최근 읽은 순', added: '추가한 순', title: '제목 순' }[sort];
  const grid = $('#lib-grid');
  grid.innerHTML = items.map(cardHtml).join('');
  fillCovers(grid);
  $('#lib-none').hidden = !any || items.length > 0;
  $('#lib-empty').hidden = any;
  $('#lib-chips').hidden = !any;

  const recent = books.filter((b) => b.p && !b.p.done).sort((a, b) => b.p.at - a.p.at)[0];
  const cont = $('#lib-cont');
  cont.hidden = !recent;
  if (recent) {
    cont.dataset.id = recent.id;
    cont.innerHTML = `<div class="cv sm">${coverHtml(recent, recent.title)}</div>
      <div class="x"><b>${esc(volName(recent))}</b><span>${esc([recent.p.chap, `${Math.floor(recent.p.pct || 0)}% 읽음`].filter(Boolean).join(' · '))}</span></div>
      <span class="play">${icon('play')}</span>`;
    fillCovers(cont);
  }
  renderNewsBadge();
}

export async function renderSeries(key, keepPart = false) {
  if (seriesKey !== key && !keepPart) part = 0;
  seriesKey = key;
  const books = (await loadBooks()).filter((b) => b.series === key).sort(byIndex);
  if (!books.length) return false;
  const sm = summarize(books);
  const target = sm.reading || books.find((b) => !b.p?.done) || books[0];
  const tp = target.p && !target.p.done ? Math.floor(target.p.pct || 0) : 0;
  const partOf = (b) => +((b.subtitle || '').match(/(\d+)\s*부/) || [])[1] || 0;
  const parts = [...new Set(books.map(partOf).filter(Boolean))].sort((a, b) => a - b);
  if (!parts.includes(part)) part = 0;

  $('#sr-title').textContent = key;
  $('#sr-head').innerHTML = `<div class="cv big">${coverHtml(books[0], key)}</div>
    <div class="sh-info"><div class="st">${esc(key)}</div>
      <div class="sm">전 ${books.length}권 · ${sm.done}권 다 읽음</div>
      <button class="btn" id="sr-go" data-id="${esc(target.id)}">${icon('play', 'sm')} ${esc(volNum(target))}권 ${tp > 0 ? `이어 읽기 · ${tp}%` : '읽기'}</button></div>`;
  $('#sr-tabs').hidden = parts.length < 2;
  $('#sr-tabs').innerHTML = [0, ...parts].map((p) => `<button class="tab${p === part ? ' on' : ''}" data-part="${p}">${p ? p + '부' : '전체'}</button>`).join('');
  const shown = part ? books.filter((b) => partOf(b) === part) : books;
  const fixes = await fixCounts();
  $('#sr-list').innerHTML = shown.map((b) => rowHtml(b, b === sm.reading, fixes.get(b.id) || 0)).join('');
  fillCovers($('#sr-head'));
  return true;
}

function rowHtml(b, cur, fixed = 0) {
  const done = !!b.p?.done;
  const pct = done ? 100 : b.p?.pct || 0;
  const tag = (isNewEdition(b) ? `<span class="tag">새 판 ${fmtDate(b.editionAt)}</span>` : isNewBook(b) ? '<span class="tag">새 권</span>' : '')
    + (fixed ? `<span class="tag ok">고친 곳 ${fixed}</span>` : '');
  const right = done ? '<div class="r done">다 읽음 ✓</div>'
    : pct > 0 || cur ? `<div class="r now">${Math.floor(pct)}%${cur ? '<br>읽는 중' : ''}</div>` : '<div class="r">안 읽음</div>';
  return `<button class="vrow${cur ? ' cur' : ''}" data-id="${esc(b.id)}">
    <div class="no">${b.seriesIndex == null ? '' : esc(volPad(b)) + '권'}</div>
    <div class="mid"><div class="a">${esc(b.subtitle || b.title)}${tag}</div><div class="pb${done ? ' done' : ''}"><i style="width:${pct}%"></i></div></div>
    ${right}</button>`;
}

async function bookMenu(id) {
  const b = await db.get('books', id);
  if (!b) return;
  const p = await db.get('progress', id);
  actionSheet(volName(b), [
    { label: '처음부터 읽기', fn: () => H.openBook(id, { at: { s: 0, b: 0, o: 0 } }) },
    p?.done
      ? { label: '안 읽음으로 되돌리기', fn: async () => { await db.del('progress', id); refresh(); } }
      : { label: '다 읽음으로 표시', fn: async () => { await db.put('progress', { ...(p || { id, pct: 0 }), id, done: true, pct: 100, at: p?.at || Date.now() }); refresh(); } },
    { label: '책 지우기', danger: true, fn: () => removeBooks([b], volName(b)) },
  ]);
}

async function seriesMenu(key) {
  const list = (await db.all('books')).filter((b) => b.series === key);
  actionSheet(key, [
    { label: '묶음 열기', fn: () => H.openSeries(key) },
    { label: `묶음 전체 지우기 (${list.length}권)`, danger: true, fn: () => removeBooks(list, key) },
  ]);
}

async function removeBooks(list, name) {
  const ok = await ask(`«${name}»${list.length > 1 ? ` ${list.length}권` : ''}을 지울까요?\n읽은 자리·형광펜·메모·제보도 같이 지워져요.`, '지우기', { danger: true });
  if (!ok) return;
  for (const b of list) { await db.removeBook(b.id); dropCover(b.id); }
  toast('지웠어요');
  refresh();
}

function refresh() {
  renderLibrary();
  if (!$('#scr-series').hidden && seriesKey) renderSeries(seriesKey, true).then((ok) => { if (!ok) H.back(); });
}

// ---------- 제보 모음(모든 책) ----------
export async function openReports() {
  const s = sheet({ title: '제보 모음', cls: 'tall' });
  const draw = async () => {
    const [notes, books] = await Promise.all([db.all('notes'), db.all('books')]);
    const results = await resultsByReport(notes);
    const bm = new Map(books.map((b) => [b.id, b]));
    const reps = notes.filter((n) => n.type === 'report');
    s.el.querySelector('.sheet-head b').textContent = `제보 모음 ${reps.length}건`;
    if (!reps.length) { s.body.innerHTML = '<div class="empty-note">제보가 없어요.<br>읽다가 문장을 꾹 눌러 «제보»를 고르면 여기 모여요.</div>'; return; }
    const order = [...new Set(reps.map((n) => n.bookId))].sort((x, y) => (bm.get(x) && bm.get(y) ? byIndex(bm.get(x), bm.get(y)) : 0));
    s.body.innerHTML = reportTools(reps)
      + order.map((id) => `<div class="note-group">${esc(bm.get(id) ? volName(bm.get(id)) : '지운 책')}</div>`
        + reps.filter((n) => n.bookId === id).sort(byPos).map((n) => `<div class="note-it" data-id="${esc(n.id)}" data-book="${esc(n.bookId)}">
          <div class="q">${n.ctx?.sent ? markQuote(n.ctx.sent, n.text) : esc(n.text)}</div>${n.note ? `<div class="nt">→ ${esc(n.note)}</div>` : ''}
          <div class="meta">${esc(n.chap || '')} · ${fmtDate(n.at)}${resultChip(n, results.get(n.id))}<button class="ib sm" data-a="del" aria-label="지우기">${icon('trash')}</button></div></div>`).join('')).join('');
    s.body.onclick = async (e) => {
      const a = e.target.closest('[data-a]')?.dataset.a;
      const it = e.target.closest('.note-it');
      if (a === 'inbox') {
        await sendNow();
        draw();
      } else if (a === 'send' || a === 'copy' || a === 'save') {
        const text = reportText(reps, bm);
        if (a === 'send') bridge.share(text, '제보 보내기');
        else if (a === 'copy') { bridge.copy(text); toast('복사했어요'); }
        else bridge.saveText(`제보-${new Date().toISOString().slice(0, 10)}.txt`, text);
      } else if (a === 'clear') {
        if (await ask(`제보 ${reps.length}건을 모두 지울까요?`, '모두 지우기', { danger: true })) {
          for (const n of reps) await db.del('notes', n.id);
          toast('제보를 모두 지웠어요');
          draw();
        }
      } else if (a === 'del' && it) {
        await db.del('notes', it.dataset.id);
        draw();
      } else if (it) {
        const n = reps.find((r) => r.id === it.dataset.id);
        s.close();
        if (n && bm.get(n.bookId)) H.openBook(n.bookId, { at: n.a });
      }
    };
  };
  draw();
}

// 제보 단추 줄 — 우편함이 이어져 있으면 «클로드에게 보내기»(안 보낸 것만), 아니면 다른 앱으로 «보내기»
export function reportTools(reps) {
  const pending = reps.filter((n) => !n.sentAt).length;
  const first = inboxConf()
    ? `<button class="btn" data-a="inbox"${pending ? '' : ' disabled'}>${icon('share', 'sm')} 클로드에게 보내기${pending ? ` ${pending}건` : ''}</button><button class="btn ghost" data-a="send">다른 앱으로</button>`
    : `<button class="btn" data-a="send">${icon('share', 'sm')} 보내기</button>`;
  return `<div class="note-tools">${first}<button class="btn ghost" data-a="copy">복사</button><button class="btn ghost" data-a="save">파일로 저장</button><button class="btn ghost danger-t" data-a="clear">모두 지우기</button></div>`;
}

// 안 보낸 제보를 우편함으로 — 결과는 알림으로
export async function sendNow(quiet = false) {
  if (!inboxConf()) return null;
  try {
    const r = await sendPending();
    if (r.sent && !quiet) toast(`클로드에게 제보 ${r.sent}건을 보냈어요`);
    return r;
  } catch (e) {
    if (!quiet) toast(explain(e), 3500);
    return null;
  }
}

// ---------- 제보 보낼 곳(클로드 우편함) ----------
const TOKEN_URL = 'https://github.com/settings/personal-access-tokens/new';
export function openInboxSettings() {
  const s = sheet({ title: '제보 보낼 곳(클로드)', cls: 'tall' });
  const draw = () => {
    const conf = inboxConf();
    if (conf) {
      s.body.innerHTML = `<div class="inbox-box"><b>연결됨</b><div>저장소 ${esc(conf.repo)}</div><div>이 폰 ${esc(deviceName())}</div>
        <p>제보를 저장하면 바로 클로드 우편함으로 가요. 인터넷이 없을 땐 모아 뒀다가 다음에 보내요.</p></div>
        <div class="inbox-box"><b>다른 폰도 연결하기</b>
          <p>여기서 «열쇠 복사» → 다른 폰의 «제보 보낼 곳» 열쇠 칸에 붙여 넣고 «연결 확인». GitHub 에 다시 들어갈 필요 없어요.</p>
          <p class="warn">열쇠를 카톡으로 옮겼다면 붙여 넣은 뒤 그 메시지는 지워 주세요.</p>
          <button class="btn ghost" data-a="copykey">열쇠 복사</button></div>
        <div class="sheet-btns"><button class="btn ghost danger-t" data-a="off">연결 끊기</button><span class="sp"></span><button class="btn" data-a="test">다시 확인</button></div>`;
      return;
    }
    s.body.innerHTML = `<div class="inbox-box"><p>다른 폰을 이미 연결했다면: 그 폰의 «제보 보낼 곳 → 열쇠 복사»로 가져와 아래 열쇠 칸에 붙여 넣고 «연결 확인»만 누르면 돼요.</p></div>
      <div class="inbox-box"><p>처음이라면: 제보를 PC 클로드(번역기 세션)로 바로 보내려면, 비공개 저장소 <b>${esc(DEFAULT_REPO)}</b>에만 쓸 수 있는 열쇠(토큰)를 한 번 만들어 붙여 넣어요.</p>
      <ol class="steps">
        <li>아래 «열쇠 만드는 화면 열기» → GitHub 로그인</li>
        <li><b>Token name</b>: 아무 이름(예: 새벽글빛 제보)</li>
        <li><b>Expiration</b>: 가장 긴 기간</li>
        <li><b>Repository access</b>: Only select repositories → <b>ebook-reports</b></li>
        <li><b>Permissions</b> → Repository permissions → <b>Contents</b>: Read and write</li>
        <li>맨 아래 <b>Generate token</b> → 나온 열쇠(github_pat_…) 복사</li>
        <li>여기로 돌아와 붙여 넣고 «연결 확인»</li>
      </ol>
      <button class="btn ghost" data-a="open">열쇠 만드는 화면 열기</button></div>
      <label class="fld">저장소<input id="ib-repo" value="${esc(DEFAULT_REPO)}" autocomplete="off" autocapitalize="off" spellcheck="false"></label>
      <label class="fld">열쇠(토큰)<input id="ib-token" type="password" placeholder="github_pat_…" autocomplete="off" autocapitalize="off" spellcheck="false"></label>
      <div class="sheet-btns"><span class="sp"></span><button class="btn" data-a="connect">연결 확인</button></div>`;
  };
  draw();
  s.body.onclick = async (e) => {
    const a = e.target.closest('[data-a]')?.dataset.a;
    if (a === 'open') bridge.openUrl(TOKEN_URL);
    else if (a === 'copykey') {
      bridge.copy(inboxConf()?.token || '');
      toast('열쇠를 복사했어요 · 다른 폰의 «제보 보낼 곳» 열쇠 칸에 붙여 넣으세요', 4000);
    } else if (a === 'connect' || a === 'test') {
      const conf = a === 'test' ? inboxConf() : {
        repo: s.body.querySelector('#ib-repo').value.trim().replace(/^https:\/\/github\.com\//, '').replace(/\/$/, ''),
        token: s.body.querySelector('#ib-token').value.trim(),
      };
      if (!conf?.repo || !conf?.token) { toast('저장소와 열쇠를 넣어 주세요'); return; }
      toast('확인하는 중…', 10000);
      try {
        await testInbox(conf);
        saveInbox(conf);
        toast('연결됐어요 · 이제 제보를 저장하면 바로 보내요', 3500);
        draw();
        sendNow(true);
      } catch (err) {
        toast(explain(err), 4000);
      }
    } else if (a === 'off') {
      if (await ask('제보 보낼 곳 연결을 끊을까요?\n이 폰에 저장한 열쇠를 지워요.', '연결 끊기', { danger: true })) {
        clearInbox();
        draw();
      }
    }
  };
}

function moreMenu() {
  const items = [
    { label: '제보 모음', fn: openReports },
    { label: '제보 보낼 곳(클로드)' + (inboxConf() ? ' · 연결됨' : ''), fn: openInboxSettings },
    { label: '고친 권 받기', fn: () => H.checkBooks() },
    { label: '앱 테마: ' + { auto: '폰 설정 따라', light: '밝게', dark: '어둡게' }[settings.appTheme], fn: () => actionSheet('앱 테마', [
      { label: '폰 설정 따라', fn: () => H.appTheme('auto') },
      { label: '밝게', fn: () => H.appTheme('light') },
      { label: '어둡게', fn: () => H.appTheme('dark') },
    ]) },
  ];
  if (H.devImport) items.push({ label: '시험 책 불러오기(개발)', fn: H.devImport });
  items.push({ label: `앱 정보 · 새벽글빛 ${bridge.version()}`, fn: () => {} });
  actionSheet('새벽글빛', items);
}

export function initLibrary(hooks) {
  H = hooks;
  $('#lib-add').onclick = () => H.importClick();
  $('#lib-empty-add').onclick = () => H.importClick();
  $('#lib-more').onclick = moreMenu;
  $('#lib-news').onclick = async () => { await H.refreshNews?.(); openNews(H); };
  $('#lib-sort').onclick = () => actionSheet('정렬', [
    { label: '최근 읽은 순', fn: () => { setSetting('libSort', 'recent'); renderLibrary(); } },
    { label: '추가한 순', fn: () => { setSetting('libSort', 'added'); renderLibrary(); } },
    { label: '제목 순', fn: () => { setSetting('libSort', 'title'); renderLibrary(); } },
  ]);
  $('#lib-search').onclick = () => {
    const box = $('#lib-searchbox');
    box.hidden = !box.hidden;
    if (!box.hidden) $('#lib-q').focus();
    else { query = ''; $('#lib-q').value = ''; renderLibrary(); }
  };
  $('#lib-q').oninput = (e) => { query = e.target.value; renderLibrary(); };
  $('#lib-chips').onclick = (e) => {
    const c = e.target.closest('.chip');
    if (c) { setSetting('libFilter', c.dataset.f); renderLibrary(); }
  };
  $('#lib-grid').onclick = (e) => {
    const c = e.target.closest('.card');
    if (!c) return;
    if (c.dataset.kind === 'series') H.openSeries(c.dataset.key);
    else H.openBook(c.dataset.key);
  };
  onLongPress($('#lib-grid'), '.card', (c) => (c.dataset.kind === 'series' ? seriesMenu(c.dataset.key) : bookMenu(c.dataset.key)));
  $('#lib-cont').onclick = (e) => { const id = e.currentTarget.dataset.id; if (id) H.openBook(id); };

  $('#sr-back').onclick = () => H.back();
  $('#sr-more').onclick = () => seriesKey && seriesMenu(seriesKey);
  $('#sr-head').onclick = (e) => { const g = e.target.closest('#sr-go'); if (g) H.openBook(g.dataset.id); };
  $('#sr-tabs').onclick = (e) => {
    const t = e.target.closest('.tab');
    if (t) { part = +t.dataset.part; renderSeries(seriesKey, true); }
  };
  $('#sr-list').onclick = (e) => { const r = e.target.closest('.vrow'); if (r) H.openBook(r.dataset.id); };
  onLongPress($('#sr-list'), '.vrow', (r) => bookMenu(r.dataset.id));
}
