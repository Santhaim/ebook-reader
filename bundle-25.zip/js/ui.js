// 화면 도우미 — 알림(토스트)·아래 시트·확인 창·길게 누르기·뒤로 가기 층
export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];
export const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
export const icon = (name, cls = '') => `<svg class="i ${cls}" aria-hidden="true"><use href="#i-${name}"/></svg>`;
export const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

export function fmtDate(ts) {
  const d = new Date(ts);
  return `${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

let toastTimer = 0;
export function toast(msg, ms = 2200) {
  const t = $('#toast');
  t.textContent = msg;
  t.classList.add('on');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('on'), ms);
}

// 뒤로 가기가 먼저 닫을 것들(시트·창·메뉴)을 쌓아 둔다
const layers = [];
export function pushLayer(close) {
  const layer = { close };
  layers.push(layer);
  return () => {
    const i = layers.indexOf(layer);
    if (i >= 0) layers.splice(i, 1);
  };
}
export const layerCount = () => layers.length;
export function closeTopLayer() {
  const top = layers[layers.length - 1];
  if (!top) return false;
  top.close();
  return true;
}

export function sheet({ title = '', body = '', cls = '', onClose } = {}) {
  const back = document.createElement('div');
  back.className = 'sheet-back';
  const el = document.createElement('div');
  el.className = 'sheet ' + cls;
  el.innerHTML = `<div class="sheet-grip"></div>${title ? `<div class="sheet-head"><b>${esc(title)}</b><span class="sheet-acts"></span><button class="ib sheet-x" aria-label="닫기">${icon('x')}</button></div>` : ''}<div class="sheet-body"></div>`;
  const bodyEl = el.querySelector('.sheet-body');
  if (typeof body === 'string') bodyEl.innerHTML = body;
  else if (body) bodyEl.appendChild(body);
  document.body.append(back, el);
  requestAnimationFrame(() => { back.classList.add('on'); el.classList.add('on'); });
  let closed = false;
  const unpush = pushLayer(() => close());
  function close() {
    if (closed) return;
    closed = true;
    unpush();
    back.classList.remove('on');
    el.classList.remove('on');
    setTimeout(() => { back.remove(); el.remove(); }, 230);
    onClose?.();
  }
  back.addEventListener('click', close);
  el.querySelector('.sheet-x')?.addEventListener('click', close);
  return { el, body: bodyEl, acts: el.querySelector('.sheet-acts'), close };
}

export function ask(msg, okLabel = '확인', { danger = false, cancelLabel = '취소' } = {}) {
  return new Promise((resolve) => {
    const back = document.createElement('div');
    back.className = 'modal-back';
    back.innerHTML = `<div class="modal"><p>${esc(msg).replace(/\n/g, '<br>')}</p><div class="modal-btns"><button class="btn ghost" data-v="0">${esc(cancelLabel)}</button><button class="btn ${danger ? 'danger' : ''}" data-v="1">${esc(okLabel)}</button></div></div>`;
    document.body.appendChild(back);
    requestAnimationFrame(() => back.classList.add('on'));
    const unpush = pushLayer(() => finish(false));
    function finish(v) {
      unpush();
      back.remove();
      resolve(v);
    }
    back.addEventListener('click', (e) => {
      const b = e.target.closest('button');
      if (b) finish(b.dataset.v === '1');
      else if (e.target === back) finish(false);
    });
  });
}

export function actionSheet(title, items) {
  const s = sheet({
    title,
    body: `<div class="acts">${items.map((it, i) => `<button class="act ${it.danger ? 'danger' : ''}" data-i="${i}">${esc(it.label)}</button>`).join('')}</div>`,
  });
  s.body.addEventListener('click', (e) => {
    const b = e.target.closest('.act');
    if (!b) return;
    s.close();
    items[+b.dataset.i].fn();
  });
  return s;
}

// 길게 누르기(0.5초) — 누른 뒤 뜨는 click 은 먹는다
export function onLongPress(root, sel, fn) {
  let timer = 0;
  let sx = 0;
  let sy = 0;
  let fired = false;
  root.addEventListener('pointerdown', (e) => {
    const target = e.target.closest(sel);
    if (!target) return;
    fired = false;
    sx = e.clientX;
    sy = e.clientY;
    clearTimeout(timer);
    timer = setTimeout(() => { fired = true; fn(target); }, 500);
  });
  const cancel = () => clearTimeout(timer);
  root.addEventListener('pointermove', (e) => { if (Math.hypot(e.clientX - sx, e.clientY - sy) > 10) cancel(); });
  root.addEventListener('pointerup', cancel);
  root.addEventListener('pointercancel', cancel);
  root.addEventListener('click', (e) => {
    if (fired) { e.stopPropagation(); e.preventDefault(); fired = false; }
  }, true);
  root.addEventListener('contextmenu', (e) => { if (e.target.closest(sel)) e.preventDefault(); });
}
