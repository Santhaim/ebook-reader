// 화면 이동(서재 → 묶음 → 뷰어) · 책 넣기 · 뒤로 가기
import { setSetting, applyAppTheme } from './settings.js';
import { bridge } from './native.js';
import { inboxConf, fetchBookUpdates, fetchReplies, explain } from './reports.js';
import { renderNewsBadge } from './news.js';
import { $, toast, closeTopLayer, layerCount } from './ui.js';
import { importFiles } from './importer.js';
import { initLibrary, renderLibrary, renderSeries, dropCover, sendNow } from './library.js';
import * as reader from './reader.js';

const stack = [{ name: 'lib' }];
const top = () => stack[stack.length - 1];

function show(name) {
  for (const n of ['lib', 'series', 'reader']) $('#scr-' + n).hidden = n !== name;
}

async function openSeries(key) {
  if (!(await renderSeries(key))) return;
  if (top().name === 'series') stack.pop();
  stack.push({ name: 'series', key });
  show('series');
  $('#scr-series .scr-body').scrollTop = 0;
}

async function openBook(id, opts = {}) {
  if (!(await reader.openBook(id, opts))) return;
  if (top().name !== 'reader') stack.push({ name: 'reader', id });
  show('reader');
}

async function back() {
  if (stack.length <= 1) return false;
  const cur = stack.pop();
  if (cur.name === 'reader') await reader.closeBook();
  if (top().name === 'series' && !(await renderSeries(top().key, true))) stack.pop();
  await renderLibrary();
  show(top().name);
  if (updateReady && cur.name === 'reader') bridge.applyUpdate();  // 읽는 동안 받은 새 판은 서재로 돌아오면 바꾼다
  return true;
}

window.onAndroidBack = () => {
  if (closeTopLayer()) return true;
  if (reader.handleBack()) return true;
  if (stack.length > 1) { back(); return true; }
  return false;
};

// ---------- 책 넣기 ----------
async function doImport(files) {
  toast(`책 넣는 중… 0/${files.length}`, 60000);
  const r = await importFiles(files, (i, n) => toast(`책 넣는 중… ${i}/${n}`, 60000));
  r.replaced.forEach((b) => dropCover(b.id));
  const parts = [];
  if (r.added.length) parts.push(`${r.added.length}권 추가`);
  if (r.replaced.length) parts.push(`${r.replaced.length}권 새 판으로 바꿈`);
  if (r.same.length) parts.push(`${r.same.length}권은 이미 있어요`);
  if (r.failed.length) parts.push(`${r.failed.length}권 못 읽음`);
  toast(parts.join(' · ') || '넣은 책이 없어요', 3500);
  await renderLibrary();
  if (top().name === 'series') await renderSeries(top().key, true);
}

const fileIn = $('#file-in');
fileIn.addEventListener('change', () => {
  const files = [...fileIn.files];
  fileIn.value = '';
  if (files.length) doImport(files);
});

// 껍데기: 다른 앱의 «공유»·파일 열기로 들어온 책 → https://app.local/incoming/… 에서 받아 온다
window.onIncomingFiles = async (json) => {
  try {
    const list = JSON.parse(json);
    const files = await Promise.all(list.map(async (it) => new File([await (await fetch(it.url)).blob()], it.name)));
    await doImport(files);
  } catch (e) {
    toast('받은 파일을 읽지 못했어요');
  }
  window.AndroidApp?.clearIncoming?.();
};

// 고친 권 받기 — 앱을 열거나 다시 볼 때(5분에 한 번까지) · 서재 ⋯ «고친 권 받기»는 바로
let bookCheckAt = 0;
let bookChecking = false;
async function checkBooks(manual = false) {
  if (!inboxConf()) {
    if (manual) toast('먼저 서재 ⋯ → «제보 보낼 곳»을 연결해 주세요', 3500);
    return;
  }
  if (bookChecking || (!manual && Date.now() - bookCheckAt < 5 * 60e3)) return;
  bookChecking = true;
  bookCheckAt = Date.now();
  if (manual) toast('고친 권을 확인하는 중…', 20000);
  try {
    // 결과 쪽지(고침·그대로 둠·질문) 먼저 — 새 질문이 오면 알림, 서재 종 숫자 갱신
    const news = await fetchReplies().catch(() => null);
    if (news?.changed) {
      renderNewsBadge();
      if (news.questions) toast(`클로드가 물어볼 게 ${news.questions}개 있어요 · 서재 위 종을 눌러 보세요`, 5000);
    }
    const r = await fetchBookUpdates();
    const got = (r?.added?.length || 0) + (r?.replaced?.length || 0);
    if (got) {
      r.replaced.forEach((b) => dropCover(b.id));
      toast(`고친 권을 받았어요 · ${[r.replaced.length && `새 판 ${r.replaced.length}권`, r.added.length && `새 권 ${r.added.length}권`].filter(Boolean).join(' · ')}`, 4000);
      await renderLibrary();
      if (top().name === 'series') await renderSeries(top().key, true);
    } else if (manual) toast(r?.none ? '아직 PC 에서 보낸 권이 없어요' : '바뀐 권이 없어요');
  } catch (e) {
    if (manual) toast(explain(e), 3500);
  } finally {
    bookChecking = false;
  }
}

const dev = ['127.0.0.1', 'localhost'].includes(location.hostname);
async function devImport() {
  const names = await (await fetch('/dev-books/list.json')).json();
  const files = [];
  for (const n of names) files.push(new File([await (await fetch('/dev-books/' + encodeURIComponent(n))).blob()], n));
  doImport(files);
}

// ---------- 테마·앱 상태 ----------
function themeChanged() {
  applyAppTheme();
  reader.onThemeChange();
}
window.onNightMode = themeChanged;
matchMedia('(prefers-color-scheme: dark)').addEventListener('change', themeChanged);
// 화면 새 판: 껍데기가 받아 두고 서재 화면(열린 창 없음)일 때 바로 바꾼다(껍데기 1.2부터)
//   1.0·1.1 껍데기는 «완전히 닫았다 열기»를 해야 바뀐다 — 홈 단추로 나갔다 오는 건 닫은 게 아니다
let updateReady = false;
window.onUpdateReady = () => {
  updateReady = true;
  toast(bridge.canApplyUpdate() ? '앱 새 판을 받았어요 · 서재에서 바로 바뀌어요'
    : '앱 새 판을 받았어요 · 최근 앱 목록에서 밀어서 닫았다가 다시 열면 바뀌어요', 5000);
};
window.onUpdated = () => toast('앱이 새 판으로 바뀌었어요', 3000);
window.canReload = () => !reader.isOpen() && layerCount() === 0;
window.onAppPause = () => reader.onAppPause();
// 인터넷이 없어 못 보낸 제보는 앱을 다시 볼 때 조용히 보낸다
window.onAppResume = () => { reader.onAppResume(); if (!reader.isOpen()) applyAppTheme(); sendNow(true); checkBooks(); };

initLibrary({
  openSeries,
  openBook,
  back,
  importClick: () => fileIn.click(),
  devImport: dev ? devImport : null,
  checkBooks: () => checkBooks(true),
  refreshNews: async () => { if (inboxConf()) { await fetchReplies().catch(() => null); renderNewsBadge(); } },
  appTheme: (v) => { setSetting('appTheme', v); themeChanged(); },
});
reader.initReader({ close: back, openBook });
applyAppTheme();
renderLibrary();
navigator.storage?.persist?.().catch(() => {});
setTimeout(() => { sendNow(true); checkBooks(); }, 3000);
