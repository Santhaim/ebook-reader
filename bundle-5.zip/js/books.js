// 책·권 이름, 묶음 순서, 제보 글 — 서재와 뷰어가 같이 쓴다
import { db } from './db.js';

export const byIndex = (a, b) =>
  (a.seriesIndex ?? 1e9) - (b.seriesIndex ?? 1e9) || a.title.localeCompare(b.title, 'ko');
export const byPos = (x, y) => x.a.s - y.a.s || x.a.b - y.a.b || x.a.o - y.a.o;

const WEEK = 7 * 864e5;
// 새 권 = 있던 묶음에 더해진 지 일주일 안 + 아직 안 열어 봄 · 새 판 = 읽던 책이 고친 판으로 바뀐 뒤 아직 안 열어 봄
export const isNewBook = (b) => !!b.newMark && !b.openedAt && Date.now() - (b.addedAt || 0) < WEEK;
export const isNewEdition = (b) => !!b.editionAt && b.openedAt > 0 && b.editionAt > b.openedAt;

export const volNum = (b) => (b.seriesIndex == null ? '' : String(b.seriesIndex));
export const volPad = (b) => (Number.isInteger(b.seriesIndex) && b.seriesIndex < 10 ? '0' : '') + volNum(b);
export const volName = (b) => (b.series && b.seriesIndex != null ? `${b.series} ${volNum(b)}권` : b.title);

export async function seriesBooks(series) {
  return (await db.all('books')).filter((b) => b.series === series).sort(byIndex);
}

export async function siblingVolume(book, step) {
  if (!book.series) return null;
  const list = await seriesBooks(book.series);
  const i = list.findIndex((b) => b.id === book.id);
  return i < 0 ? null : list[i + step] || null;
}

const pad2 = (n) => String(n).padStart(2, '0');

export function reportText(reports, books) {
  const d = new Date();
  const order = [...new Set(reports.map((n) => n.bookId))].sort((x, y) => {
    const a = books.get(x);
    const b = books.get(y);
    return a && b ? byIndex(a, b) : 0;
  });
  const out = [`[제보 ${reports.length}건 · ${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}]`];
  for (const id of order) {
    const b = books.get(id);
    for (const n of reports.filter((r) => r.bookId === id).sort(byPos)) {
      out.push('', `■ ${b ? volName(b) : n.vol || ''}${n.chap ? ' · ' + n.chap : ''}`, `“${n.text}”`);
      if (n.note) out.push(`→ ${n.note}`);
    }
  }
  return out.join('\n');
}
