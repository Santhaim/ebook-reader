// 보기 설정 · 앱 테마 — localStorage 한 덩어리
import { bridge } from './native.js';

const KEY = 'ebook.settings.v1';
const DEFAULTS = {
  font: 'serif',       // serif 명조 · sans 고딕
  fs: 17,              // 글자 크기(px)
  lh: 1.8,             // 줄 간격
  pm: 0.5,             // 문단 간격(em)
  indent: true,        // 들여쓰기
  justify: true,       // 양쪽 정렬
  margin: 'm',         // 여백 s·m·l
  theme: 'auto',       // 읽기 배경: auto·white·paper·green·gray·black
  mode: 'page',        // page 좌우 넘기기 · scroll 위아래 스크롤
  anim: 'slide',       // 넘김 효과 slide·none
  spread: 'auto',      // 두 쪽 보기: auto(넓으면 두 쪽) · one(늘 한 쪽)
  keepOn: true,        // 화면 꺼짐 방지
  nextVol: true,       // 다음 권 이어서
  volKeys: false,      // 볼륨키로 넘기기
  appTheme: 'auto',    // 앱 테마 auto·light·dark
  brightness: null,    // null = 폰 밝기 따라 · 0.02~1
  libSort: 'recent',   // recent·added·title
  libFilter: 'all',    // all·reading·done
  ttsRate: 1,
};

export const settings = (() => {
  try { return { ...DEFAULTS, ...JSON.parse(localStorage.getItem(KEY) || '{}') }; } catch { return { ...DEFAULTS }; }
})();

const listeners = new Set();
export function onSettings(fn) { listeners.add(fn); }

export function setSetting(key, value) {
  settings[key] = value;
  try { localStorage.setItem(KEY, JSON.stringify(settings)); } catch {}
  for (const fn of listeners) fn(key, value);
}

export function isDark() {
  if (settings.appTheme === 'dark') return true;
  if (settings.appTheme === 'light') return false;
  return bridge.isNight();
}

export const READER_THEMES = {
  white: { name: '흰색', bg: '#ffffff', ink: '#1f2023', sub: '#9a9ca1', dark: false },
  paper: { name: '종이', bg: '#f4ecd8', ink: '#3b3226', sub: '#a3957c', dark: false },
  green: { name: '연두', bg: '#dfeee0', ink: '#24332a', sub: '#7d9583', dark: false },
  gray: { name: '짙은 회색', bg: '#2b2d31', ink: '#c8cacf', sub: '#7c8088', dark: true },
  black: { name: '검정', bg: '#000000', ink: '#b4b6ba', sub: '#5f636a', dark: true },
};

export function readerTheme() {
  const k = settings.theme === 'auto' ? (isDark() ? 'black' : 'white') : settings.theme;
  return { key: k, ...(READER_THEMES[k] || READER_THEMES.white) };
}

export function applyAppTheme() {
  const dark = isDark();
  document.documentElement.dataset.theme = dark ? 'dark' : 'light';
  if (!document.body.classList.contains('reading')) bridge.setBars(dark ? '#141518' : '#ffffff', !dark);
}
