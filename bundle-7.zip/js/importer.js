// 책 넣기 — 같은 책(같은 식별자)을 다시 넣으면 «새 판»으로 바꿔 끼우고 읽던 자리·메모는 그대로 둔다
import { readEpub } from './epub.js';
import { db } from './db.js';

// 시리즈 정보가 없는 책: 「제목 3권」 꼴이면 묶는다
const TITLE_VOL = /^(.*?\S)\s*[-_]?\s*(\d{1,4})\s*권/;

export async function importFiles(files, onStep) {
  const result = { added: [], replaced: [], same: [], failed: [] };
  const books = await db.all('books');
  // «새 권» 표시는 이미 있던 묶음에 더해진 권만(처음 한꺼번에 넣은 책들은 표시 안 함)
  const before = new Set(books.map((b) => b.series || ''));
  const hadAny = books.length > 0;
  for (let i = 0; i < files.length; i++) {
    const f = files[i];
    onStep?.(i + 1, files.length);
    try {
      const buf = await f.arrayBuffer();
      const ep = await readEpub(buf);
      const m = ep.meta;
      const base = f.name.replace(/\.epub$/i, '');
      const title = m.title || base;
      let series = m.series;
      let index = m.seriesIndex;
      if (!series) {
        const mm = title.match(TITLE_VOL) || base.match(TITLE_VOL);
        if (mm) { series = mm[1].trim(); index = +mm[2]; }
      }
      // 같은 책 판단: 묶음+권 번호가 먼저(번역기가 다시 만든 EPUB 은 식별자가 바뀔 때가 있다) → 식별자 → 제목
      const id = series && index != null ? `s:${series}|${index}` : m.identifier ? 'id:' + m.identifier : 't:' + title;
      const old = books.find((b) => b.id === id);
      const same = !!old && old.size === f.size && old.modified === m.modified;
      const now = Date.now();
      const rec = {
        id,
        title,
        series: series || null,
        seriesIndex: index ?? null,
        subtitle: (base.match(/\(([^)]+)\)\s*$/) || [])[1] || '',
        creator: m.creator,
        fileName: f.name,
        size: f.size,
        modified: m.modified,
        addedAt: old?.addedAt || now,
        editionAt: old && !same ? now : old?.editionAt || null,
        openedAt: old?.openedAt || 0,
        newMark: old ? !!old.newMark : series ? before.has(series) : hadAny,
      };
      if (!same) {
        await db.put('files', new Blob([buf], { type: 'application/epub+zip' }), id);
        const cover = await ep.coverBlob().catch(() => null);
        const thumb = cover ? await thumbnail(cover) : null;
        if (thumb) await db.put('covers', thumb, id);
      }
      await db.put('books', rec);
      if (!old) books.push(rec);
      (old ? (same ? result.same : result.replaced) : result.added).push(rec);
    } catch (e) {
      console.warn('책 넣기 실패', f.name, e);
      result.failed.push(f.name);
    }
  }
  return result;
}

async function thumbnail(blob) {
  try {
    const bmp = await createImageBitmap(blob);
    const w = Math.min(360, bmp.width);
    const h = Math.round((bmp.height * w) / bmp.width);
    const c = document.createElement('canvas');
    c.width = w;
    c.height = h;
    c.getContext('2d').drawImage(bmp, 0, 0, w, h);
    return await new Promise((r) => c.toBlob((b) => r(b || blob), 'image/jpeg', 0.86));
  } catch {
    return blob;
  }
}
