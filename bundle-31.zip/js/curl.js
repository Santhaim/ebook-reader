// 종이책 넘김(보기 설정 → 넘김 효과 «종이책») — 접히는 선 계산과 겹쳐 그리기
//   장 하나 = 넓이 w·높이 h 네모. 책등이 x=0, 넘기는 끝이 x=w. 끝의 한 점 C=(w,cy)를 잡아 P 로 옮기면
//   접히는 선 = C·P 의 수직 이등분선 → C 쪽 조각 A 가 그 선을 거울삼아 뒤집혀 F(장의 뒷면)가 되고, A 자리엔 밑 쪽이 드러난다.
//   P 는 책등 두 끝에서 C 까지 거리보다 멀리 못 간다(종이는 늘어나지 않으니) → 접히는 선이 책등을 넘지 않는다.
//   쪽 사본(밑에 드러나는 쪽 · 장의 뒷면)은 reader.js 가 채운다 — 여기선 자르고 뒤집고 그림자만.

// 볼록 다각형을 반평면으로 자른다 — keep 1: (X-M)·n ≥ 0 쪽 · -1: 반대쪽
function clip(poly, M, n, keep) {
  const side = (p) => keep * ((p[0] - M[0]) * n[0] + (p[1] - M[1]) * n[1]);
  const out = [];
  for (let i = 0; i < poly.length; i++) {
    const a = poly[i];
    const b = poly[(i + 1) % poly.length];
    const sa = side(a);
    const sb = side(b);
    if (sa >= 0) out.push(a);
    if ((sa >= 0) !== (sb >= 0)) {
      const k = sa / (sa - sb);
      out.push([a[0] + (b[0] - a[0]) * k, a[1] + (b[1] - a[1]) * k]);
    }
  }
  return out;
}

// 선분 a-b 중 (X-M)·n ≥ 0 쪽 토막
function clipSeg(a, b, M, n) {
  const s = (p) => (p[0] - M[0]) * n[0] + (p[1] - M[1]) * n[1];
  const sa = s(a);
  const sb = s(b);
  if (sa < 0 && sb < 0) return null;
  if (sa >= 0 && sb >= 0) return [a, b];
  const k = sa / (sa - sb);
  const x = [a[0] + (b[0] - a[0]) * k, a[1] + (b[1] - a[1]) * k];
  return sa >= 0 ? [a, x] : [x, b];
}

function pin(w, h, C, P) {
  let [x, y] = P;
  for (let k = 0; k < 2; k++) {
    for (const sy of [0, h]) {
      const r = Math.hypot(C[0], C[1] - sy);
      const d = Math.hypot(x, y - sy);
      if (d > r) { x *= r / d; y = sy + (y - sy) * (r / d); }
    }
  }
  return [x, y];
}

export function fold(w, h, C, P0) {
  const page = [[0, 0], [w, 0], [w, h], [0, h]];
  const P = pin(w, h, C, P0);
  const L = Math.hypot(C[0] - P[0], C[1] - P[1]);
  if (L < 0.5) return { L: 0, A: [], F: [] };
  const n = [(C[0] - P[0]) / L, (C[1] - P[1]) / L];
  const M = [(C[0] + P[0]) / 2, (C[1] + P[1]) / 2];
  const refl = (p) => {
    const d = 2 * ((p[0] - M[0]) * n[0] + (p[1] - M[1]) * n[1]);
    return [p[0] - d * n[0], p[1] - d * n[1]];
  };
  const A = clip(page, M, n, 1);
  const seg = clipSeg([w, 0], [w, h], M, n);   // 넘기는 끝 중 들린 토막 → 뒤집혀 장의 바깥 끝이 된다
  return {
    L, n, M, A,
    F: A.map(refl),
    edge: seg && seg.map(refl),
    u: [1 - 2 * n[0] * n[0], -2 * n[0] * n[1]],   // 바깥 끝에서 장 밖으로 향하는 쪽(그림자가 지는 쪽)
  };
}

const poly = (pts) => (pts.length > 2 ? `polygon(${pts.map((p) => `${p[0].toFixed(1)}px ${p[1].toFixed(1)}px`).join(',')})` : 'polygon(0 0,0 0,0 0)');
const pts = (el, list) => el.setAttribute('points', list.map((p) => `${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(' '));
const line = (g, a, b) => {
  g.setAttribute('x1', a[0].toFixed(1));
  g.setAttribute('y1', a[1].toFixed(1));
  g.setAttribute('x2', b[0].toFixed(1));
  g.setAttribute('y2', b[1].toFixed(1));
};

// 장의 뒷면 음영 — 접힌 선(0)에서 바깥 끝(1)까지: 접힌 자리 그늘 → 둥글게 휜 듯한 밝은 띠 → 끝으로 살짝 어둡게
const FLAP = [[0, '#000', 0.2], [0.07, '#000', 0.05], [0.3, '#fff', 0.24], [0.72, '#fff', 0.05], [1, '#000', 0.1]];

export function makeCurl(host) {
  const el = document.createElement('div');
  el.id = 'rd-curl';
  el.setAttribute('aria-hidden', 'true');
  el.innerHTML = `<div class="cpg under"></div>
    <svg class="csh"><defs>
      <linearGradient id="cg-sh" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#000"/><stop offset="1" stop-color="#000" stop-opacity="0"/></linearGradient>
      <linearGradient id="cg-ed" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#000"/><stop offset="1" stop-color="#000" stop-opacity="0"/></linearGradient>
    </defs><polygon class="psh" fill="url(#cg-sh)"/><polygon class="ped" fill="url(#cg-ed)"/></svg>
    <div class="cpg back"></div>
    <svg class="cfl"><defs><linearGradient id="cg-fl" gradientUnits="userSpaceOnUse">${FLAP.map(([o, c, a]) => `<stop offset="${o}" stop-color="${c}" stop-opacity="${a}"/>`).join('')}</linearGradient></defs><polygon class="pfl" fill="url(#cg-fl)"/></svg>`;
  host.appendChild(el);
  const q = (s) => el.querySelector(s);
  const under = q('.under');
  const back = q('.back');
  const psh = q('.psh');
  const ped = q('.ped');
  const pfl = q('.pfl');
  const gsh = q('#cg-sh');
  const ged = q('#cg-ed');
  const gfl = q('#cg-fl');
  let cfg = null;

  return {
    under, back,
    // kind: single-fwd·single-back(한 쪽) · spread-fwd·spread-back(두 쪽, 책등 sx) · cy 잡은 높이 · lift 들어 올리는 정도
    //   한 쪽: 지금 쪽이 들리고 밑에서 넘겨 갈 쪽(under) · 뒷면은 지금 쪽이 비친다(back)
    //     앞으로는 오른쪽 끝을 잡아 왼쪽으로, 뒤로는 그 좌우 거울(왼쪽 끝이 말려 오른쪽으로 — 사용자 «왼쪽 누르면 왼쪽이 말리게» 10-25)
    //   두 쪽: 넘기는 장의 뒷면 = 다음 펼침의 반대쪽 쪽(back 을 책등 거울 + 접힌 선 거울로 옮겨 붙인다)
    setup(c) {
      cfg = c;
      const single = c.kind.startsWith('single');
      back.classList.toggle('see', single);
      back.style.background = single ? c.paper : '';
      pfl.setAttribute('opacity', '0');
    },
    // u = 장이 넘어간 정도(0 그대로 ~ 1 다 넘어감) · fy = 손가락이 위아래로 움직인 만큼
    pose(u, fy = 0) {
      const { W, H, kind, cy, sx } = cfg;
      const spread = kind.startsWith('spread');
      const mir = kind.endsWith('back') ? -1 : 1;   // 뒤로 = 좌우 거울
      const x0 = spread ? sx : mir > 0 ? 0 : W;      // 책등(묶인 쪽) x
      const w = mir > 0 ? W - x0 : x0;
      const lift = (cy > H / 2 ? -1 : 1) * H * cfg.lift * Math.sin(Math.PI * u);
      const g = fold(w, H, [w, cy], [w - 2 * w * u, cy + fy + lift]);
      const S = (p) => [x0 + mir * p[0], p[1]];
      const A = g.A.map(S);
      under.style.clipPath = poly(A);
      if (!g.L) {
        back.style.clipPath = poly([]);
        for (const p of [psh, ped, pfl]) pts(p, []);
        return;
      }
      const n = [mir * g.n[0], g.n[1]];
      const M = S(g.M);
      const a = 1 - 2 * n[0] * n[0];
      const b = -2 * n[0] * n[1];
      const d = 1 - 2 * n[1] * n[1];
      const k = 2 * (M[0] * n[0] + M[1] * n[1]);
      if (spread) {
        back.style.transform = `matrix(${-a},${-b},${b},${d},${2 * sx * a + k * n[0]},${2 * sx * b + k * n[1]})`;
        back.style.clipPath = poly(A.map((p) => [2 * sx - p[0], p[1]]));
      } else {
        back.style.transform = `matrix(${a},${b},${b},${d},${k * n[0]},${k * n[1]})`;
        back.style.clipPath = poly(A);
      }
      // 그림자는 막 들릴 때와 다 넘어가 눕는 끝에서 옅게
      const fade = Math.min(1, u * 8) * Math.min(1, (1 - u) * 4);
      const ds = 10 + Math.min(70, g.L * 0.3);
      pts(psh, A);
      line(gsh, M, [M[0] + n[0] * ds, M[1] + n[1] * ds]);
      gsh.firstElementChild.setAttribute('stop-opacity', (0.32 * fade).toFixed(3));
      if (g.edge) {
        const [e1, e2] = g.edge.map(S);
        const v = [mir * g.u[0], g.u[1]];
        const es = 6 + 22 * Math.sin(Math.PI * u);
        const out = (p) => [p[0] + v[0] * es, p[1] + v[1] * es];
        pts(ped, [e1, e2, out(e2), out(e1)]);
        line(ged, e1, out(e1));
        ged.firstElementChild.setAttribute('stop-opacity', (0.24 * fade).toFixed(3));
      } else pts(ped, []);
      pts(pfl, g.F.map(S));
      line(gfl, M, [M[0] - n[0] * g.L / 2, M[1] - n[1] * g.L / 2]);
      // 두 쪽 보기에선 다 넘어가면 뒷면이 그대로 왼쪽 쪽이 되니 음영을 거둔다
      pfl.setAttribute('opacity', ((cfg.dark ? 0.6 : 1) * (spread ? Math.min(1, (1 - u) * 4) : 1)).toFixed(3));
    },
    show(on) { el.classList.toggle('on', on); },
    clear() {
      for (const s of [under, back]) { s.innerHTML = ''; s._st = null; }
    },
  };
}
