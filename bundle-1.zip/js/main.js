// 화면 이동(서재 → 묶음 → 뷰어) · 책 넣기 · 뒤로 가기
import { setSetting, applyAppTheme } from './settings.js';
import { $, toast, closeTopLayer } from './ui.js';
import { importFiles } from './importer.js';
import { initLibrary, renderLibrary, renderSeries, dropCover } from './library.js';
import * as reader from './reader.js';

const stack = [{ name: 'lib' }];
const top = () => stack[stack.length - 1];

function show(name) {
  for (const n of ['lib', 'series', 'reader']) $('#scr-' + n).hidden = n !== name;
}

async function openSeries(key) {
  if (!(await renderSeries(key))) return;
  if (top().name === 'series') stack.pop();
  stack.push({ name: 'series', key });
  show('series');
  $('#scr-series .scr-body').scrollTop = 0;
}

async function openBook(id, opts = {}) {
  if (!(await reader.openBook(id, opts))) return;
  if (top().name !== 'reader') stack.push({ name: 'reader', id });
  show('reader');
}

async function back() {
  if (stack.length <= 1) return false;
  const cur = stack.pop();
  if (cur.name === 'reader') await reader.closeBook();
  if (top().name === 'series' && !(await renderSeries(top().key, true))) stack.pop();
  await renderLibrary();
  show(top().name);
  return true;
}

window.onAndroidBack = () => {
  if (closeTopLayer()) return true;
  if (reader.handleBack()) return true;
  if (stack.length > 1) { back(); return true; }
  return false;
};

// ---------- 책 넣기 ----------
async function doImport(files) {
  toast(`책 넣는 중… 0/${files.length}`, 60000);
  const r = await importFiles(files, (i, n) => toast(`책 넣는 중… ${i}/${n}`, 60000));
  r.replaced.forEach((b) => dropCover(b.id));
  const parts = [];
  if (r.added.length) parts.push(`${r.added.length}권 추가`);
  if (r.replaced.length) parts.push(`${r.replaced.length}권 새 판으로 바꿈`);
  if (r.same.length) parts.push(`${r.same.length}권은 이미 있어요`);
  if (r.failed.length) parts.push(`${r.failed.length}권 못 읽음`);
  toast(parts.join(' · ') || '넣은 책이 없어요', 3500);
  await renderLibrary();
  if (top().name === 'series') await renderSeries(top().key, true);
}

const fileIn = $('#file-in');
fileIn.addEventListener('change', () => {
  const files = [...fileIn.files];
  fileIn.value = '';
  if (files.length) doImport(files);
});

// 껍데기: 다른 앱의 «공유»·파일 열기로 들어온 책 → https://app.local/incoming/… 에서 받아 온다
window.onIncomingFiles = async (json) => {
  try {
    const list = JSON.parse(json);
    const files = await Promise.all(list.map(async (it) => new File([await (await fetch(it.url)).blob()], it.name)));
    await doImport(files);
  } catch (e) {
    toast('받은 파일을 읽지 못했어요');
  }
  window.AndroidApp?.clearIncoming?.();
};

const dev = ['127.0.0.1', 'localhost'].includes(location.hostname);
async function devImport() {
  const names = await (await fetch('/dev-books/list.json')).json();
  const files = [];
  for (const n of names) files.push(new File([await (await fetch('/dev-books/' + encodeURIComponent(n))).blob()], n));
  doImport(files);
}

// ---------- 테마·앱 상태 ----------
function themeChanged() {
  applyAppTheme();
  reader.onThemeChange();
}
window.onNightMode = themeChanged;
matchMedia('(prefers-color-scheme: dark)').addEventListener('change', themeChanged);
window.onUpdateReady = () => toast('앱 새 판을 받았어요 · 앱을 다시 열면 바뀌어요', 4000);
window.onAppPause = () => reader.onAppPause();
window.onAppResume = () => { reader.onAppResume(); if (!reader.isOpen()) applyAppTheme(); };

initLibrary({
  openSeries,
  openBook,
  back,
  importClick: () => fileIn.click(),
  devImport: dev ? devImport : null,
  appTheme: (v) => { setSetting('appTheme', v); themeChanged(); },
});
reader.initReader({ close: back, openBook });
applyAppTheme();
renderLibrary();
navigator.storage?.persist?.().catch(() => {});
