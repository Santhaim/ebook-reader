// 클로드 답장 — 결과 쪽지(고침·그대로 둠·질문)를 내 제보와 주고받은 대화처럼 보여 주고, 질문엔 대화 안에서 바로 답한다
//   클로드 답 밑 «답글 달기» = 덧붙이는 말(다시 제보하지 않아도 됨) · 서재 종의 빨간 숫자 = 아직 안 본 답 + 답 안 한 질문
import { db } from './db.js';
import { $, esc, toast, sheet, icon } from './ui.js';
import { volName, volNum } from './books.js';
import { sendAnswer, sendComment, explain, answerOf, pushSeen } from './reports.js';

const FIX_DAYS = 30;   // 새 판의 고친 문장 표시(초록 점선)는 30일 동안
const recent = (it) => Date.now() - Date.parse(it.at || 0) < FIX_DAYS * 864e5;
const pending = (it, list) => (it.status === 'question' ? !answerOf(it, list) : !it.read);
// «여기부터 새 답장» — 안 본 것(답한 질문은 본 것으로)
const unseen = (it, list) => !it.read && !(it.status === 'question' && answerOf(it, list));

export async function allNews() {
  return (await db.all('news')).sort((a, b) => String(b.at).localeCompare(String(a.at)));
}

export async function renderNewsBadge() {
  const list = await allNews();
  const n = list.filter((it) => pending(it, list)).length;
  const em = $('#lib-news em');
  em.textContent = n > 99 ? '99+' : String(n);
  em.hidden = !n;
}

// 쪽지가 가리키는 권 — 쪽지의 장 이름(chap)이 든 권(같은 묶음) · 권을 다시 묶어 번호가 바뀌어도 맞게(10-26)
//   쪽지의 권 이름(vol)이 그 장을 가진 권이면 그대로 · 장 이름을 모르는 옛 책 정보면 예전처럼 권 이름으로 · 못 찾으면 null(엉뚱한 권에 안 붙임)
const flatName = (s) => String(s || '').replace(/\s+/g, '');
export function replyBook(it, books) {
  const named = books.find((b) => volName(b) === it.vol) || null;
  const c = flatName(it.chap);
  if (!c) return named;
  const has = (b) => b.labels?.some((l) => flatName(l) === c);
  if (named && (!named.labels || has(named))) return named;
  const series = String(it.vol || '').replace(/\s*[\d.]+권$/, '');
  return books.find((b) => b.series === series && has(b)) || null;
}

// 읽기 화면에 표시할 고친 문장(이 권 · 30일 안)
export async function fixesFor(book) {
  const books = await db.all('books');
  return (await allNews()).filter((it) => it.status === 'fixed' && it.after && recent(it) && replyBook(it, books)?.id === book.id);
}

// 권 목록의 «고친 곳 N» — 권 id → 그 권에서 고친 문장 수(읽기 화면 초록 점선과 같은 수)
//   쪽지 also(«책 전체 N곳 함께»)는 책 전체 수라 더하지 않는다 — 더하면 책 전체 통일이 제보한 권에 몰려 붙음(10-29 10권 «1200»)
export async function fixCounts() {
  const books = await db.all('books');
  const m = new Map();
  for (const it of await allNews()) {
    if (it.status !== 'fixed' || !it.after || !recent(it)) continue;
    const b = replyBook(it, books);
    if (b) m.set(b.id, (m.get(b.id) || 0) + 1);
  }
  return m;
}

// 쪽지 ↔ 내 제보: id 가 없는 쪽지(화면 판 10 전에 보낸 제보)는 문장으로 맞춘다 — 쪽지 before ⊇ 제보 문장
//   질문에 답해 고친 쪽지(reply)의 before 는 문장이 아니라 요약이라 맞추지 않는다
const flat = (s) => String(s || '').replace(/\s+/g, '');
export function matchesReport(it, n) {
  if (it.report) return it.report === n.id;
  if (it.reply || n.type !== 'report' || (n.vol && it.vol && n.vol !== it.vol)) return false;
  const a = flat(it.before || it.after);
  const b = flat(n.ctx?.sent || n.text);
  return a.length >= 4 && b.length >= 4 && (a.includes(b) || b.includes(a));
}

// 제보 목록의 결과 칩 — 제보 id → 쪽지(질문에 답해 고친 결과가 왔으면 그 결과)
export async function resultsByReport(notes = []) {
  const items = await allNews();
  const m = new Map();
  for (const it of items) if (it.report && !m.has(it.report)) m.set(it.report, it);
  const loose = items.filter((it) => !it.report);
  for (const n of notes) {
    if (n.type !== 'report' || m.has(n.id)) continue;
    const hit = loose.find((it) => matchesReport(it, n));
    if (hit) m.set(n.id, hit);
  }
  for (const [k, it] of m) {
    if (it.status !== 'question') continue;
    const done = items.find((x) => x.reply === it.id);
    if (done) m.set(k, done);
    else if (answerOf(it, items)) m.set(k, { ...it, answered: answerOf(it, items) });
  }
  return m;
}

export function resultChip(n, res) {
  if (res?.status === 'fixed') return '<span class="rchip c-ok">고침 ✓</span>';
  if (res?.status === 'kept') return '<span class="rchip c-keep">그대로 둠</span>';
  if (res?.status === 'question') return res.answered ? '<span class="rchip c-keep">답함</span>' : '<span class="rchip c-q">질문 있음</span>';
  if (n.sentAt) return '<span class="rchip c-wait">보냄 · 처리 기다림</span>';
  return '';
}

// ---------- 대화 ----------
const shortVol = (v) => String(v || '').match(/\d+권$/)?.[0] || String(v || '');
const shortChap = (c) => String(c || '').match(/^제\s*\d+\s*장/)?.[0] || String(c || '');
// 어디 — 지금 서재의 권 번호로(다시 묶여 번호가 바뀌었으면 새 번호) · 못 찾으면 쪽지에 적힌 권
const where = (it, ctx) => {
  const b = replyBook(it, ctx.books);
  return [b ? `${volNum(b)}권` : shortVol(it.vol), shortChap(it.chap)].filter(Boolean).join(' ');
};

// 날짜 줄 — «10월 25일 새벽 2:48»
function when(iso) {
  const d = new Date(iso);
  const h = d.getHours();
  const part = h < 6 ? '새벽' : h < 9 ? '아침' : h < 12 ? '오전' : h < 18 ? '오후' : h < 22 ? '저녁' : '밤';
  return `${d.getMonth() + 1}월 ${d.getDate()}일 ${part} ${h % 12 || 12}:${String(d.getMinutes()).padStart(2, '0')}`;
}

function quoteHtml(q, picked) {
  const i = picked && picked !== q ? q.indexOf(picked) : -1;
  return i < 0 ? esc(q) : `${esc(q.slice(0, i))}<b>${esc(picked)}</b>${esc(q.slice(i + picked.length))}`;
}

// 내 제보 — 쪽지에 실려 온 메모·문장(어느 폰에서 보냈든) → 없으면 이 폰의 제보 기록
function mineOf(it, ctx) {
  if (it.reply || (it.status === 'question' && !it.report)) return null;
  if (it.quote || it.memo) return { quote: it.quote || '', picked: it.picked || '', memo: it.memo || '' };
  const n = ctx.reps.find((r) => matchesReport(it, r));
  return n ? { quote: n.ctx?.sent || n.text || '', picked: n.text || '', memo: n.note || '' } : null;
}

function meBubble(it, mine, ctx) {
  return `<div class="me"><div class="loc">내 제보 · ${esc(where(it, ctx))}</div>${mine.quote ? `<div class="q">${quoteHtml(mine.quote, mine.picked)}</div>` : ''}${mine.memo ? `<div class="m">${esc(mine.memo)}</div>` : ''}</div>`;
}

function answerBubble(it, ans) {
  if (!ans.choice && !ans.text) return '';
  return `<div class="me ans" data-of="${esc(it.id)}">${esc(ans.choice || ans.text)}${ans.choice && ans.text ? `<div class="m">${esc(ans.text)}</div>` : ''}</div>`;
}

// 내 답글 — 이 폰에서 클로드 답에 단 말 · 그 뒤로 클로드가 이 쪽지에 다시 답했으면 «답 기다림»을 뗀다
function commentBubbles(it, ctx) {
  return (it.comments || []).map((c) => {
    const done = ctx.list.some((x) => x.comment === c.id || (x.reply === it.id && Date.parse(x.at) >= c.at));
    return `<div class="me cm" data-of="${esc(it.id)}">${esc(c.text)}${done ? '' : '<div class="wait">보냄 · 답 기다림</div>'}</div>`;
  }).join('');
}

function clBubble(it, ctx, mine) {
  let b = '';
  if (it.reply) {
    // 답글에 다시 답한 것이면 내 답글을, 질문에 답해 고친 것이면 그 질문을 인용
    const q = ctx.list.find((x) => x.id === it.reply);
    const said = it.comment && (it.answer?.text || q?.comments?.find((c) => c.id === it.comment)?.text);
    if (said) b += `<div class="re">내 답글 · ${esc(said)}</div>`;
    else if (q) b += `<div class="re">${esc(q.question || q.before || '')}</div>`;
  } else if (!mine && it.chap) b += `<div class="bl">${esc(where(it, ctx))}</div>`;
  if (it.status === 'question') {
    b += `<div class="ask">${esc(it.question)}</div>`;
    if (!answerOf(it, ctx.list)) {
      b += `<div class="btns">${(it.choices || []).map((c, i) => `<button class="nb${i === 0 ? ' p' : ''}" data-a="choice" data-i="${i}">${esc(c)}</button>`).join('')}<button class="nb" data-a="write">직접 쓰기</button></div>`;
    }
  } else {
    if (it.why) b += `<div class="say">${esc(it.why)}</div>`;
    if (it.status === 'fixed') {
      if (!mine && !it.reply && it.before) b += `<div class="was">${esc(it.before)}</div>`;
      b += `<div class="now">${esc(it.after)}</div>`;
      const chip = it.also ? `책 전체 ${it.also}곳 함께${it.glossary ? ' · 용어집' : ''}` : it.glossary ? '용어집에도 넣음' : '';
      if (chip) b += `<span class="gchip">${chip}</span>`;
      if (replyBook(it, ctx.books)) b += '<button class="go" data-a="go">읽기 화면에서 보기 ›</button>';
    } else if (!mine && (it.after || it.before)) {
      b += `<div class="was keep">${esc(it.after || it.before)}</div>`;
    }
  }
  const rp = it.status === 'question' ? '' : '<button class="rp" data-a="comment">답글 달기</button>';
  return `<div class="cl" data-id="${esc(it.id)}"><div class="av">클</div><div class="col"><div class="bub">${b}</div>${rp}</div></div>`;
}

// 답글 쓰는 칸 — 그 답의 마지막 말풍선(내 답·답글) 밑에 하나만
const COMPOSER = '<textarea rows="2" placeholder="클로드에게 덧붙일 말 — 예: 조금 더 부드럽게"></textarea><div class="btns"><button class="nb" data-a="cancel">취소</button><button class="nb p" data-a="csend">보내기</button></div>';

// 찾기 — 대화 한 덩이(내 제보 → 클로드 답 → 내 답·답글)에 보이는 글 + 권·장 이름(묶음 이름이 붙은 권 이름·장 제목까지)
//   답글에 다시 답한 것·질문에 답해 고친 것은 인용한 말도 넣는다(그 질문을 찾으면 뒤따른 답도 같이 나오게)
function foundText(it, mine, ans, ctx) {
  const re = it.reply && ctx.list.find((x) => x.id === it.reply);
  return [it.vol, it.chap, where(it, ctx), mine?.quote, mine?.memo, re?.question, re?.before, it.answer?.text, it.question, ...(it.choices || []),
    it.why, it.before, it.after, ans?.choice, ans?.text, ...(it.comments || []).map((c) => c.text)].filter(Boolean).join(' ');
}

// 찾은 말에 노란 칠 — 빈칸을 빼고 맞춘 자리를 글자 자리로 되돌린다 · 날짜·«답글 달기» 같은 화면 글은 빼고
function markFound(root, want) {
  if (!window.CSS?.highlights) return;
  const ranges = [];
  if (want) {
    const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode: (n) => (n.parentElement.closest('.day,.rp,.go,.wait,.nfind-n') ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT),
    });
    for (let n = w.nextNode(); n; n = w.nextNode()) {
      const at = [];
      let t = '';
      for (let i = 0; i < n.data.length; i++) if (!/\s/.test(n.data[i])) { at.push(i); t += n.data[i].toLowerCase(); }
      for (let i = t.indexOf(want); i >= 0; i = t.indexOf(want, i + want.length)) {
        const rg = document.createRange();
        rg.setStart(n, at[i]);
        rg.setEnd(n, at[i + want.length - 1] + 1);
        ranges.push(rg);
      }
    }
  }
  CSS.highlights.set('nfind', new Highlight(...ranges));
}

// 열려 있는 답장 창을 새 쪽지·다른 폰 읽음으로 고친다(main.js checkNews) — 창이 열려 있으면 true
let liveNews = null;
export function newsChanged() {
  if (!liveNews) return false;
  liveNews().catch(() => {});
  return true;
}

export function openNews(hooks) {
  const s = sheet({ title: '클로드 답장', cls: 'tall', onClose: () => { liveNews = null; window.CSS?.highlights?.delete('nfind'); } });
  let ctx = { list: [], books: [], reps: [] };
  // 찾기 — 제목 줄 돋보기 → 찾기 칸 · 적은 말이 든 대화만 보인다(빈칸은 안 가림) · 지우거나 돋보기를 다시 누르면 대화 전체를 찾기 전 보던 곳에서
  //   사용자 «물어본 게 많아서 예전에 질문했던 거 찾으려면 스크롤을 많이 올려야 해»(10-31)
  const fb = document.createElement('button');
  fb.className = 'ib';
  fb.setAttribute('aria-label', '답장에서 찾기');
  fb.innerHTML = icon('search');
  s.el.querySelector('.sheet-x').before(fb);
  const box = document.createElement('div');
  box.className = 'sbox nfind';
  box.hidden = true;
  box.innerHTML = '<input type="search" placeholder="예전 제보·질문·답에서 찾기" enterkeyhint="search">';
  s.body.before(box);
  const input = box.firstElementChild;
  let q = '';
  let back = 0;   // 찾기 전 스크롤 자리
  // how: 'first' = 처음 열 때 · 'find' = 찾는 말이 바뀜 · 없으면 보던 자리 그대로
  const draw = async (how) => {
    // 대화 순서 = 쪽지가 온 차례 → 쪽지 안 차례
    const list = (await allNews()).sort((a, b) => String(a.at).localeCompare(String(b.at)) || (a.seq ?? 0) - (b.seq ?? 0));
    const [bs, notes] = await Promise.all([db.all('books'), db.all('notes')]);
    ctx = { list, books: bs, reps: notes.filter((n) => n.type === 'report') };
    fb.hidden = !list.length;
    if (!list.length) {
      s.body.innerHTML = '<div class="empty-note">아직 클로드 답장이 없어요.<br>제보를 보내면 클로드가 읽고 여기에 답해요.</div>';
      return;
    }
    const waiting = list.filter((it) => it.status === 'question' && !answerOf(it, list)).length;
    s.acts.innerHTML = waiting ? `<button class="qpill">답할 질문 ${waiting} ›</button>` : '';
    const want = flat(q).toLowerCase();
    let html = '<div class="chat">';
    let at = '';
    let fresh = false;
    let hits = 0;
    for (const it of list) {
      const mine = mineOf(it, ctx);
      const ans = it.status === 'question' && answerOf(it, list);
      if (want && !flat(foundText(it, mine, ans, ctx)).toLowerCase().includes(want)) continue;
      hits++;
      if (it.at !== at) { at = it.at; html += `<div class="day">${when(at)}</div>`; }
      if (!want && !fresh && unseen(it, list)) { fresh = true; html += '<div class="newline">여기부터 새 답장</div>'; }
      if (mine) html += meBubble(it, mine, ctx);
      html += clBubble(it, ctx, mine);
      if (ans) html += answerBubble(it, ans);
      html += commentBubbles(it, ctx);
    }
    if (want) html = (hits ? `<div class="nfind-n">찾은 대화 ${hits}개</div>` : '<div class="empty-note">그 말이 든 대화가 없어요.</div>') + html;
    const top = s.body.scrollTop;
    s.body.innerHTML = html + '</div>';
    markFound(s.body, want);
    if (how === 'find') { s.body.scrollTop = want ? 0 : back; return; }
    if (how !== 'first') { s.body.scrollTop = top; return; }
    // 처음 열 때 = 새 답장이 시작되는 곳(바로 위 날짜 줄부터) · 없으면 맨 아래(가장 최근)
    let nl = s.body.querySelector('.newline');
    if (nl?.previousElementSibling?.classList.contains('day')) nl = nl.previousElementSibling;
    s.body.scrollTop = nl ? nl.getBoundingClientRect().top - s.body.getBoundingClientRect().top - 8 : s.body.scrollHeight;
  };
  const markRead = async () => {
    let n = 0;
    for (const it of ctx.list) if (!it.read) { it.read = true; await db.put('news', it); n++; }
    renderNewsBadge();
    if (n) pushSeen();   // 다른 폰의 종 숫자도 줄게(reports.js «읽음·답함 맞추기»)
  };
  draw('first').then(markRead);
  // 열어 둔 사이 온 쪽지 — 답을 쓰는 중이면 안 건드리고(쓰던 글이 날아간다) 다 쓴 뒤에 · 막 열었거나 맨 아래를 보고 있으면 새 답장으로 · 위쪽을 보고 있으면 자리 그대로(안 읽음으로 남겨 종에 남는다)
  const openedAt = Date.now();
  let dirty = false;
  liveNews = async () => {
    if (s.body.querySelector('textarea')) { dirty = true; return; }
    dirty = false;
    const follow = !q && (Date.now() - openedAt < 5000 || s.body.scrollTop + s.body.clientHeight >= s.body.scrollHeight - 40);
    await draw(follow ? 'first' : undefined);
    if (follow) await markRead();
  };
  fb.onclick = () => {
    if (box.hidden) {
      back = s.body.scrollTop;
      box.hidden = false;
      fb.classList.add('on');
      input.focus();
      return;
    }
    box.hidden = true;
    fb.classList.remove('on');
    input.value = '';
    if (q) { q = ''; draw('find'); }
  };
  let t = 0;
  const find = () => {
    clearTimeout(t);
    if (input.value === q) return;
    q = input.value;
    draw('find');
  };
  input.oninput = () => { clearTimeout(t); t = setTimeout(find, 200); };
  input.onkeydown = (e) => { if (e.key === 'Enter') { find(); input.blur(); } };
  // 제목 줄 «답할 질문 N ›» — 아직 답 안 한 질문으로(지금 보이는 곳 아래부터 차례로)
  s.acts.onclick = () => {
    const qs = [...s.body.querySelectorAll('.cl .btns')].map((x) => x.closest('.cl'));
    const base = s.body.getBoundingClientRect().top + 12;
    const next = qs.find((q) => q.getBoundingClientRect().top > base + 4) || qs[0];
    if (next) s.body.scrollTop += next.getBoundingClientRect().top - base;
  };
  s.body.onclick = async (e) => {
    const btn = e.target.closest('[data-a]');
    if (!btn) return;
    const a = btn.dataset.a;
    const el = btn.closest('[data-id]');   // 클로드 말풍선(.cl) 또는 답글 쓰는 칸(.cmt)
    const it = el && ctx.list.find((x) => x.id === el.dataset.id);
    if (!it) return;
    if (a === 'go') {
      const b = replyBook(it, ctx.books);
      s.close();
      if (b) hooks.openBook(b.id, { findText: it.after, findChap: it.chap || '' });
    } else if (a === 'choice' || a === 'send') {
      const choice = a === 'choice' ? it.choices[+btn.dataset.i] : null;
      const text = a === 'send' ? el.querySelector('textarea')?.value.trim() : '';
      if (a === 'send' && !text) { toast('답을 적어 주세요'); return; }
      btn.disabled = true;
      try {
        await sendAnswer(it, choice, text);
        toast('클로드에게 답을 보냈어요', 3000);
        dirty = false;
        await draw();
        renderNewsBadge();
      } catch (err) {
        btn.disabled = false;
        toast(explain(err), 3500);
      }
    } else if (a === 'write') {
      const box = el.querySelector('.btns');
      box.outerHTML = '<textarea rows="3" placeholder="클로드에게 보낼 답"></textarea><div class="btns"><button class="nb p" data-a="send">보내기</button></div>';
      el.querySelector('textarea').focus();
    } else if (a === 'comment') {
      let box = s.body.querySelector('.cmt');
      if (box?.dataset.id !== it.id) {
        box?.remove();
        const last = [...s.body.querySelectorAll(`[data-of="${CSS.escape(it.id)}"]`)].pop() || el;
        last.insertAdjacentHTML('afterend', `<div class="cmt" data-id="${esc(it.id)}">${COMPOSER}</div>`);
        box = last.nextElementSibling;
      }
      const ta = box.querySelector('textarea');
      ta.focus();
      setTimeout(() => ta.scrollIntoView({ block: 'nearest' }), 350);   // 자판이 올라온 뒤에도 보이게
    } else if (a === 'cancel') {
      el.remove();
      if (dirty) liveNews?.();
    } else if (a === 'csend') {
      const text = el.querySelector('textarea').value.trim();
      if (!text) { toast('덧붙일 말을 적어 주세요'); return; }
      btn.disabled = true;
      try {
        await sendComment(it, text);
        toast('클로드에게 답글을 보냈어요', 3000);
        dirty = false;
        await draw();
      } catch (err) {
        btn.disabled = false;
        toast(explain(err), 3500);
      }
    }
  };
}
