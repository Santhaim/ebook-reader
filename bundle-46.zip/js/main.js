// 화면 이동(서재 → 묶음 → 뷰어) · 책 넣기 · 뒤로 가기
import { setSetting, applyAppTheme } from './settings.js';
import { bridge } from './native.js';
import { inboxConf, fetchBookUpdates, booksApplying, fetchReplies, mailHeads, retrySeen, explain } from './reports.js';
import { renderNewsBadge, newsChanged } from './news.js';
import { $, toast, closeTopLayer, layerCount } from './ui.js';
import { importFiles } from './importer.js';
import { initLibrary, renderLibrary, renderSeries, dropCover, sendNow } from './library.js';
import { repairCrossSeries } from './regroup.js';
import * as reader from './reader.js';

const stack = [{ name: 'lib' }];
const top = () => stack[stack.length - 1];

function show(name) {
  for (const n of ['lib', 'series', 'reader']) $('#scr-' + n).hidden = n !== name;
}

async function openSeries(key) {
  if (!(await renderSeries(key))) return;
  if (top().name === 'series') stack.pop();
  stack.push({ name: 'series', key });
  show('series');
  $('#scr-series .scr-body').scrollTop = 0;
}

// 여는 중인 권(읽기 화면이 다 뜨기 전) — 고친 권 받기가 그 사이 바꿔 끼우지 않게 «읽는 중인 권»으로 친다
let opening = null;
async function openBook(id, opts = {}) {
  // 고친 권을 바꿔 끼우는 동안은 안 연다 — 지금 바뀌는 권일 수 있다(많을 때 몇십 초 · 진행은 알림 줄에)
  if (booksApplying()) { toast('고친 권을 바꿔 넣는 중이에요 · 끝나면 열 수 있어요', 3000); return; }
  opening = id;
  try {
    if (!(await reader.openBook(id, opts))) return;
  } finally {
    opening = null;
  }
  if (top().name !== 'reader') stack.push({ name: 'reader', id });
  show('reader');
}

async function back() {
  if (stack.length <= 1) return false;
  const cur = stack.pop();
  if (cur.name === 'reader') await reader.closeBook();
  if (top().name === 'series' && !(await renderSeries(top().key, true))) stack.pop();
  await renderLibrary();
  show(top().name);
  if (updateReady && cur.name === 'reader') bridge.applyUpdate();  // 읽는 동안 받은 새 판은 서재로 돌아오면 바꾼다
  if (booksLater && cur.name === 'reader') { booksLater = false; checkBooks(); }   // 읽는 동안 미룬 고친 권
  if (cur.name === 'reader') pollMail();   // 읽는 동안 온 쪽지 — 서재 종에 바로
  return true;
}

window.onAndroidBack = () => {
  if (closeTopLayer()) return true;
  if (reader.handleBack()) return true;
  if (stack.length > 1) { back(); return true; }
  return false;
};

// ---------- 책 넣기 ----------
async function doImport(files) {
  toast(`책 넣는 중… 0/${files.length}`, 60000);
  const r = await importFiles(files, (i, n) => toast(`책 넣는 중… ${i}/${n}`, 60000));
  r.replaced.forEach((b) => dropCover(b.id));
  const parts = [];
  if (r.added.length) parts.push(`${r.added.length}권 추가`);
  if (r.replaced.length) parts.push(`${r.replaced.length}권 새 판으로 바꿈`);
  if (r.same.length) parts.push(`${r.same.length}권은 이미 있어요`);
  if (r.failed.length) parts.push(`${r.failed.length}권 못 읽음`);
  toast(parts.join(' · ') || '넣은 책이 없어요', 3500);
  await renderLibrary();
  if (top().name === 'series') await renderSeries(top().key, true);
}

const fileIn = $('#file-in');
fileIn.addEventListener('change', () => {
  const files = [...fileIn.files];
  fileIn.value = '';
  if (files.length) doImport(files);
});

// 껍데기: 다른 앱의 «공유»·파일 열기로 들어온 책 → https://app.local/incoming/… 에서 받아 온다
window.onIncomingFiles = async (json) => {
  try {
    const list = JSON.parse(json);
    const files = await Promise.all(list.map(async (it) => new File([await (await fetch(it.url)).blob()], it.name)));
    await doImport(files);
  } catch (e) {
    toast('받은 파일을 읽지 못했어요');
  }
  window.AndroidApp?.clearIncoming?.();
};

// 쪽지 받기 — 서재 종 숫자·열려 있는 답장 창을 고친다(일부만 받았어도 숫자는 맞게) · 다 받았으면 true
async function checkNews() {
  try {
    const news = await fetchReplies();
    if (news.changed || news.synced) {
      const open = newsChanged();
      if (news.questions && !open) toast(`클로드가 물어볼 게 ${news.questions}개 있어요 · 서재 위 종을 눌러 보세요`, 5000);
    }
    return !news.retry;
  } finally {
    renderNewsBadge();
  }
}

// 고친 권 받기 — 우편함 books 가지가 바뀌었을 때(pollMail) · 서재 ⋯ «고친 권 받기»는 쪽지까지 바로 · 다 끝났으면 true
//   읽는 동안에도 받아 두고 바꿔 끼우되, 읽는 중인 권만은 안 바꾼다(열린 권이 옛 판 기준 자리를 새 판에 다시 써 버린다) → 서재로 돌아오면 그 권도
//   (10-31 전엔 읽는 중이면 받기부터 미뤘다 — 앱을 열자마자 책을 펴면 서재로 돌아올 때까지 아무것도 안 받았다)
let bookChecking = false;
let booksLater = false;
let booksAgain = false;
let booksBig = 0;
// 많이 받을 땐(4권 넘게) 서재에 진행을 띄운다 — 읽는 중엔 조용히
function booksStep(kind, i, n) {
  if (n < 4) return;
  booksBig = n;
  if (reader.isOpen()) return;
  toast(kind === 'get' ? `고친 권 받는 중 ${i}/${n} · 앱을 꺼도 받은 권은 남아요` : `고친 권 바꿔 넣는 중 ${i}/${n}`, 8000);
}
async function checkBooks(manual = false) {
  if (!inboxConf()) {
    if (manual) toast('먼저 서재 ⋯ → «제보 보낼 곳»을 연결해 주세요', 3500);
    return false;
  }
  if (bookChecking) { booksAgain = true; return false; }   // 도는 중에 책을 덮었으면 끝난 뒤 한 번 더(그 권)
  bookChecking = true;
  booksBig = 0;
  let ok = false;
  if (manual) toast('고친 권을 확인하는 중…', 20000);
  try {
    if (manual) await checkNews().catch(() => {});
    const r = await fetchBookUpdates({ busy: () => [reader.openId(), opening], onStep: booksStep });
    if (r?.skipped) booksLater = true;   // 읽는 중인 권은 받아만 뒀다 — 덮으면 바꾼다
    const got = (r?.added?.length || 0) + (r?.replaced?.length || 0) + (r?.removed?.length || 0);
    if (got) {
      [...r.replaced.map((b) => b.id), ...r.removed].forEach(dropCover);
      toast(r.removed.length
        ? `권을 다시 묶었어요(${r.removed.length}권 줄어듦) · 읽던 자리·메모는 같은 장으로 옮겼어요`
        : `고친 권을 받았어요 · ${[r.replaced.length && `새 판 ${r.replaced.length}권`, r.added.length && `새 권 ${r.added.length}권`].filter(Boolean).join(' · ')}`, 5000);
      await renderLibrary();
      if (top().name === 'series') await renderSeries(top().key, true);
    } else if (r?.renamed) {   // 꼬리표(부)·작가 이름만 바뀐 권 — 알림 없이 서재·부 탭만 다시
      await renderLibrary();
      if (top().name === 'series') await renderSeries(top().key, true);
    } else if (manual) toast(r?.none ? '아직 PC 에서 보낸 권이 없어요' : '바뀐 권이 없어요');
    ok = true;
  } catch (e) {
    if (manual) toast(explain(e), 3500);
    else if (booksBig && !reader.isOpen()) toast('고친 권을 다 못 받았어요 · 받은 권은 남겨 뒀다가 다음에 이어서 받아요', 4000);
  } finally {
    bookChecking = false;
    if (booksAgain) { booksAgain = false; checkBooks(); }
  }
  return ok;
}

// 우편함 살피기 — 앱을 보는 동안 30초마다(읽는 중엔 쉬고 서재로 돌아오면 바로) · 앱으로 돌아올 때 바로
//   머리(1KB)만 보고 바뀐 쪽만 받는다. 사용자 «종 알림이 가끔 안 떠 · 두 폰 연동이 느려»(11-06):
//   전엔 앱을 켤 때·5분 넘게 나갔다 올 때만 봐서 — 켜 둔 채로는 쪽지가 와도, 다른 폰에서 읽어도 숫자가 안 바뀌었다
const POLL_MS = 30e3;
const seenHeads = {};
let polling = false;
let appPaused = false;
let wholeAt = 0;
async function pollMail() {
  if (polling || !inboxConf()) return;
  polling = true;
  try {
    const h = await mailHeads();
    retrySeen();
    if (h.mail !== seenHeads.mail && await checkNews()) seenHeads.mail = h.mail;
    if (h.books !== seenHeads.books && !bookChecking) checkBooks().then((ok) => { if (ok) seenHeads.books = h.books; });
  } catch (e) {
    // 머리를 못 보는 열쇠면 예전처럼 5분에 한 번 통째로(인터넷이 없는 건 다음 차례에)
    if (e.status && Date.now() - wholeAt > 5 * 60e3) {
      wholeAt = Date.now();
      checkNews().catch(() => {});
      checkBooks();
    }
  } finally {
    polling = false;
  }
}
setInterval(() => { if (!appPaused && !document.hidden && !reader.isOpen()) pollMail(); }, POLL_MS);

const dev = ['127.0.0.1', 'localhost'].includes(location.hostname);
async function devImport() {
  const names = await (await fetch('/dev-books/list.json')).json();
  const files = [];
  for (const n of names) files.push(new File([await (await fetch('/dev-books/' + encodeURIComponent(n))).blob()], n));
  doImport(files);
}

// ---------- 테마·앱 상태 ----------
function themeChanged() {
  applyAppTheme();
  reader.onThemeChange();
}
window.onNightMode = themeChanged;
matchMedia('(prefers-color-scheme: dark)').addEventListener('change', themeChanged);
// 화면 새 판: 껍데기가 받아 두고 서재 화면(열린 창 없음)일 때 바로 바꾼다(껍데기 1.2부터)
//   1.0·1.1 껍데기는 «완전히 닫았다 열기»를 해야 바뀐다 — 홈 단추로 나갔다 오는 건 닫은 게 아니다
let updateReady = false;
window.onUpdateReady = () => {
  updateReady = true;
  toast(bridge.canApplyUpdate() ? '앱 새 판을 받았어요 · 서재에서 바로 바뀌어요'
    : '앱 새 판을 받았어요 · 최근 앱 목록에서 밀어서 닫았다가 다시 열면 바뀌어요', 5000);
};
window.onUpdated = () => toast('앱이 새 판으로 바뀌었어요', 3000);
window.canReload = () => !reader.isOpen() && layerCount() === 0 && !booksApplying();   // 고친 권을 바꿔 넣는 중엔 다시 뜨지 않게
window.onAppPause = () => { appPaused = true; reader.onAppPause(); };
// 인터넷이 없어 못 보낸 제보는 앱을 다시 볼 때 조용히 보낸다
window.onAppResume = () => { appPaused = false; reader.onAppResume(); if (!reader.isOpen()) applyAppTheme(); sendNow(true); pollMail(); };

initLibrary({
  openSeries,
  openBook,
  back,
  importClick: () => fileIn.click(),
  devImport: dev ? devImport : null,
  checkBooks: () => checkBooks(true),
  refreshNews: () => { if (inboxConf()) checkNews().catch(() => {}); },
  appTheme: (v) => { setSetting('appTheme', v); themeChanged(); },
});
reader.initReader({ close: back, openBook });
applyAppTheme();
renderLibrary();
navigator.storage?.persist?.().catch(() => {});
// 판 40 이하가 두 책을 한 번에 바꿔 끼우며 다른 책으로 넘긴 메모·형광펜을 제 책으로(한 번 · 화면 판 41 · regroup.js)
repairCrossSeries().then((n) => { if (n) { toast(`다른 책으로 잘못 넘어갔던 메모·형광펜 ${n}개를 제 책으로 돌려놨어요`, 6000); renderLibrary(); } }).catch(() => {});
setTimeout(() => { sendNow(true); pollMail(); }, 3000);
