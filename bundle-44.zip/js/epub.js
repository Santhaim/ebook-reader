// EPUB 읽기 — 책 정보(제목·시리즈·몇 번째 권·표지)와 목차, 장(spine) 본문을 꺼낸다.
import { openZip } from './zip.js';

const MIME = {
  jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', gif: 'image/gif', webp: 'image/webp',
  svg: 'image/svg+xml', css: 'text/css', xhtml: 'application/xhtml+xml', html: 'text/html',
};
export const mimeOf = (path) => MIME[(path.split('.').pop() || '').toLowerCase()] || '';

const byTag = (root, local) => (root ? [...root.getElementsByTagNameNS('*', local)] : []);
const kids = (el, ...names) => [...el.children].filter((e) => names.includes(e.localName));

export function resolvePath(baseFile, href) {
  const clean = (href || '').split('#')[0].split('?')[0];
  if (!clean || /^[a-z][a-z0-9+.-]*:/i.test(clean)) return null;
  const dir = baseFile.includes('/') ? baseFile.slice(0, baseFile.lastIndexOf('/') + 1) : '';
  const out = [];
  for (const seg of (clean.startsWith('/') ? clean.slice(1) : dir + clean).split('/')) {
    if (seg === '..') out.pop();
    else if (seg && seg !== '.') out.push(seg);
  }
  try { return decodeURIComponent(out.join('/')); } catch { return out.join('/'); }
}

function parseXml(text) {
  if (!text) return null;
  const d = new DOMParser().parseFromString(text, 'application/xml');
  return d.getElementsByTagName('parsererror').length ? null : d;
}

export async function readEpub(buf) {
  const zip = await openZip(buf);
  let opfPath = null;
  const container = parseXml(await zip.text('META-INF/container.xml'));
  if (container) opfPath = byTag(container, 'rootfile')[0]?.getAttribute('full-path') || null;
  if (!opfPath || !zip.has(opfPath)) opfPath = zip.names.find((n) => n.toLowerCase().endsWith('.opf')) || null;
  if (!opfPath) throw new Error('책 정보(OPF)를 못 찾았어요');
  const opf = parseXml(await zip.text(opfPath));
  if (!opf) throw new Error('책 정보(OPF)가 깨졌어요');

  const pkg = opf.documentElement;
  const md = byTag(pkg, 'metadata')[0];
  const dc = (name) => byTag(md, name).map((e) => e.textContent.trim()).filter(Boolean);
  const metas = byTag(md, 'meta');
  const metaName = (name) => metas.find((m) => m.getAttribute('name') === name)?.getAttribute('content') || null;
  const metaProp = (prop) => metas.filter((m) => m.getAttribute('property') === prop);

  const uid = pkg.getAttribute('unique-identifier');
  const ids = byTag(md, 'identifier');
  const identifier = (ids.find((e) => e.getAttribute('id') === uid) || ids[0])?.textContent.trim() || null;

  // 시리즈: EPUB3 belongs-to-collection(+group-position) → 없으면 calibre:series
  let series = null;
  let seriesIndex = null;
  const coll = metaProp('belongs-to-collection')[0];
  if (coll) {
    series = coll.textContent.trim() || null;
    const cid = coll.getAttribute('id');
    const gp = cid && metas.find((m) => m.getAttribute('refines') === '#' + cid && m.getAttribute('property') === 'group-position');
    if (gp) seriesIndex = parseFloat(gp.textContent);
  }
  if (!series && metaName('calibre:series')) {
    series = metaName('calibre:series');
    seriesIndex = parseFloat(metaName('calibre:series_index'));
  }
  if (!Number.isFinite(seriesIndex)) seriesIndex = null;

  const manifest = new Map();
  for (const it of byTag(pkg, 'item')) {
    manifest.set(it.getAttribute('id'), {
      id: it.getAttribute('id') || '',
      path: resolvePath(opfPath, it.getAttribute('href')),
      type: it.getAttribute('media-type') || '',
      props: (it.getAttribute('properties') || '').split(/\s+/),
    });
  }
  const spineEl = byTag(pkg, 'spine')[0];
  const spine = [];
  for (const ir of byTag(spineEl, 'itemref')) {
    const item = manifest.get(ir.getAttribute('idref'));
    if (item?.path && zip.has(item.path)) spine.push({ path: item.path, linear: ir.getAttribute('linear') !== 'no' });
  }
  if (!spine.length) throw new Error('본문이 없어요');

  let coverPath = null;
  for (const it of manifest.values()) if (it.props.includes('cover-image')) coverPath = it.path;
  if (!coverPath && manifest.get(metaName('cover'))) coverPath = manifest.get(metaName('cover')).path;
  if (!coverPath) {
    for (const it of manifest.values()) if (it.type.startsWith('image/') && /cover/i.test(it.id + it.path)) { coverPath = it.path; break; }
  }

  return {
    zip,
    spine,
    toc: await readToc(zip, manifest, spineEl, spine),
    meta: {
      title: dc('title')[0] || '',
      creator: dc('creator')[0] || '',
      identifier,
      series,
      seriesIndex,
      modified: metaProp('dcterms:modified')[0]?.textContent.trim() || null,
    },
    coverPath,
    coverSig: coverPath ? zip.sig(coverPath) : null,
    coverBlob: () => (coverPath ? zip.blob(coverPath, mimeOf(coverPath)) : Promise.resolve(null)),
    chapter: (i) => loadChapter(zip, spine[i].path),
  };
}

async function readToc(zip, manifest, spineEl, spine) {
  const out = [];
  const nav = [...manifest.values()].find((it) => it.props.includes('nav'));
  if (nav) {
    const text = await zip.text(nav.path);
    const doc = parseXml(text) || (text ? new DOMParser().parseFromString(text, 'text/html') : null);
    const navs = byTag(doc, 'nav');
    const tocNav = navs.find((n) => /\btoc\b/.test(n.getAttribute('epub:type') || n.getAttributeNS('http://www.idpf.org/2007/ops', 'type') || '')) || navs[0];
    const walk = (list, depth) => {
      for (const li of kids(list, 'li')) {
        const a = kids(li, 'a', 'span')[0];
        const href = a?.getAttribute('href');
        const label = a?.textContent.replace(/\s+/g, ' ').trim();
        // data-n = 원문의 장 번호(번역기가 부마다 장 번호를 1부터 다시 매긴 권 · 10-31) — 장 열쇠(regroup.js)에만 쓴다
        const n = +(a?.getAttribute('data-n') || 0) || null;
        if (href && label) out.push({ label, path: resolvePath(nav.path, href), frag: href.split('#')[1] || '', depth, n });
        const sub = kids(li, 'ol', 'ul')[0];
        if (sub) walk(sub, depth + 1);
      }
    };
    const top = tocNav && (kids(tocNav, 'ol', 'ul')[0] || byTag(tocNav, 'ol')[0]);
    if (top) walk(top, 0);
  }
  if (!out.length) {
    const ncxId = spineEl?.getAttribute('toc');
    const ncx = manifest.get(ncxId) || [...manifest.values()].find((it) => it.type === 'application/x-dtbncx+xml');
    const doc = ncx && parseXml(await zip.text(ncx.path));
    const walk = (el, depth) => {
      for (const np of kids(el, 'navPoint')) {
        const label = byTag(np, 'text')[0]?.textContent.replace(/\s+/g, ' ').trim();
        const src = byTag(np, 'content')[0]?.getAttribute('src');
        if (label && src) out.push({ label, path: resolvePath(ncx.path, src), frag: src.split('#')[1] || '', depth });
        walk(np, depth + 1);
      }
    };
    const navMap = byTag(doc, 'navMap')[0];
    if (navMap) walk(navMap, 0);
  }
  for (const t of out) t.s = spine.findIndex((sp) => sp.path === t.path);
  return out.filter((t) => t.s >= 0);
}

// 장 하나 → 화면에 넣을 HTML(스크립트·이벤트 속성 뺌 · 그림은 data-zip · 링크는 data-path)
async function loadChapter(zip, path) {
  const text = await zip.text(path);
  const doc = parseXml(text) || new DOMParser().parseFromString(text || '', 'text/html');
  const body = byTag(doc, 'body')[0];
  const css = [];
  const styles = [];
  for (const l of byTag(doc, 'link')) {
    if (/stylesheet/i.test(l.getAttribute('rel') || '') && l.getAttribute('href')) css.push(resolvePath(path, l.getAttribute('href')));
  }
  for (const s of byTag(doc, 'style')) styles.push(s.textContent);

  const wrap = document.createElement('div');
  for (const n of body ? [...body.childNodes] : []) wrap.appendChild(document.importNode(n, true));
  wrap.querySelectorAll('script,iframe,object,embed,form,input,button,textarea,select,link,meta,base,style,audio,video').forEach((e) => e.remove());
  for (const el of wrap.querySelectorAll('*')) {
    for (const a of [...el.attributes]) if (/^on/i.test(a.name)) el.removeAttribute(a.name);
  }
  for (const img of wrap.querySelectorAll('img')) {
    const p = resolvePath(path, img.getAttribute('src'));
    img.removeAttribute('src');
    img.removeAttribute('srcset');
    if (p) img.dataset.zip = p;
  }
  const XL = 'http://www.w3.org/1999/xlink';
  for (const im of wrap.querySelectorAll('image')) {
    const p = resolvePath(path, im.getAttribute('href') || im.getAttributeNS(XL, 'href'));
    im.removeAttribute('href');
    im.removeAttributeNS(XL, 'href');
    if (p) im.dataset.zip = p;
  }
  for (const a of wrap.querySelectorAll('a[href]')) {
    const href = a.getAttribute('href');
    a.removeAttribute('href');
    a.classList.add('lnk');
    if (/^(https?:|mailto:)/i.test(href)) a.dataset.ext = href;
    else {
      a.dataset.path = href.startsWith('#') ? path : resolvePath(path, href) || '';
      a.dataset.frag = href.split('#')[1] || '';
    }
  }
  return { html: wrap.innerHTML, cls: body?.getAttribute('class') || '', css, styles, path };
}
