// 아주 작은 ZIP 읽기 — EPUB 은 stored(0)·deflate(8) 둘뿐이라 이걸로 충분하다(풀기는 브라우저 DecompressionStream).
export async function openZip(buf) {
  const u8 = new Uint8Array(buf);
  const dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
  let eocd = -1;
  for (let i = u8.length - 22; i >= Math.max(0, u8.length - 65557); i--) {
    if (dv.getUint32(i, true) === 0x06054b50) { eocd = i; break; }
  }
  if (eocd < 0) throw new Error('ZIP(EPUB) 파일이 아니에요');
  const count = dv.getUint16(eocd + 10, true);
  let p = dv.getUint32(eocd + 16, true);
  const dec = new TextDecoder();
  const entries = new Map();
  for (let n = 0; n < count; n++) {
    if (dv.getUint32(p, true) !== 0x02014b50) throw new Error('ZIP 목록이 깨졌어요');
    const method = dv.getUint16(p + 10, true);
    const crc = dv.getUint32(p + 16, true);
    const csize = dv.getUint32(p + 20, true);
    const size = dv.getUint32(p + 24, true);
    const nlen = dv.getUint16(p + 28, true), xlen = dv.getUint16(p + 30, true), clen = dv.getUint16(p + 32, true);
    const off = dv.getUint32(p + 42, true);
    entries.set(dec.decode(u8.subarray(p + 46, p + 46 + nlen)), { method, crc, csize, size, off });
    p += 46 + nlen + xlen + clen;
  }

  async function bytes(name) {
    const e = entries.get(name);
    if (!e) return null;
    const start = e.off + 30 + dv.getUint16(e.off + 26, true) + dv.getUint16(e.off + 28, true);
    const raw = u8.subarray(start, start + e.csize);
    if (e.method === 0) return raw.slice();
    if (e.method !== 8) throw new Error('모르는 압축 방식: ' + e.method);
    const out = new Blob([raw]).stream().pipeThrough(new DecompressionStream('deflate-raw'));
    return new Uint8Array(await new Response(out).arrayBuffer());
  }

  return {
    names: [...entries.keys()],
    has: (name) => entries.has(name),
    // 파일 꼬리표 = 목록에 적힌 CRC·크기(풀지 않고 같은 파일인지 견줄 때 · 표지가 그대로인가)
    sig: (name) => { const e = entries.get(name); return e ? `${e.crc.toString(16)}:${e.size}` : null; },
    bytes,
    async text(name) {
      const b = await bytes(name);
      return b == null ? null : dec.decode(b);
    },
    async blob(name, type) {
      const b = await bytes(name);
      return b == null ? null : new Blob([b], { type: type || '' });
    },
  };
}
