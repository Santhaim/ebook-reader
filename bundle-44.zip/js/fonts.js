// 받아 쓰는 본문 글꼴 — 화면 묶음엔 안 넣는다(판이 바뀔 때마다 2MB 를 다시 받지 않게)
//   공개 폴더 fonts/(make_web.py 가 font/web/ 를 올림)에서 처음 고를 때 한 번 받아 Cache Storage 에 둔다 · 사용자 «글꼴에 리디바탕체 넣어줘»(11-01)
//   라이선스: 리디바탕·고운바탕·프리텐다드 = SIL OFL 1.1 · 마루 부리 = 네이버 나눔글꼴 라이선스(재배포 허용 · 글꼴만 파는 건 금지) — 전문은 fonts/LICENSE-*.txt
const dev = ['127.0.0.1', 'localhost'].includes(location.hostname);
export const FONT_BASE = dev ? '/fonts/' : 'https://santhaim.github.io/ebook-reader/fonts/';
const CACHE = 'ebook-fonts-1';

export const WEB_FONTS = {
  ridi: { name: '리디바탕', family: 'RIDIBatang', file: 'RIDIBatang.woff2', kb: 446, by: '리디주식회사 · SIL OFL 1.1', license: 'LICENSE-RIDIBatang.txt' },
  maru: { name: '마루 부리', family: 'MaruBuri', file: 'MaruBuri-Regular.woff2', kb: 423, by: '네이버 · 나눔글꼴 라이선스', license: 'LICENSE-MaruBuri.txt' },
  gowun: { name: '고운바탕', family: 'Gowun Batang', file: 'GowunBatang-Regular.woff2', kb: 523, by: '류양희 · SIL OFL 1.1', license: 'LICENSE-GowunBatang.txt' },
  pretendard: { name: '프리텐다드', family: 'Pretendard', file: 'Pretendard-Regular.woff2', kb: 747, by: '길형진 · SIL OFL 1.1', license: 'LICENSE-Pretendard.txt' },
};

// 받아 두고(없으면 받기) 문서에 붙인다 — 같은 글꼴은 한 번만 · 못 받으면 거절(다음에 다시 시도)
const loading = new Map();
export function loadFont(id) {
  const f = WEB_FONTS[id];
  if (!f) return Promise.resolve(true);
  if (!loading.has(id)) {
    const p = (async () => {
      const url = FONT_BASE + f.file;
      let cache = null;
      let res = null;
      try { cache = await caches.open(CACHE); res = await cache.match(url); } catch { /* Cache Storage 를 못 쓰면 그냥 받기만 */ }
      if (!res) {
        res = await fetch(url);
        if (!res.ok) throw new Error(`글꼴 ${res.status}`);
        try { await cache?.put(url, res.clone()); } catch { /* 저장 공간이 모자라도 이번엔 쓴다 */ }
      }
      const face = new FontFace(f.family, await res.arrayBuffer());
      await face.load();
      document.fonts.add(face);
      return true;
    })();
    p.catch(() => loading.delete(id));
    loading.set(id, p);
  }
  return loading.get(id);
}

// 이미 받아 둔 글꼴인가(받는 중 알림을 띄울지)
export async function fontCached(id) {
  const f = WEB_FONTS[id];
  if (!f) return true;
  try { return !!(await (await caches.open(CACHE)).match(FONT_BASE + f.file)); } catch { return false; }
}
