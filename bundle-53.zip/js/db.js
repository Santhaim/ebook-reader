// IndexedDB — 책 정보(books)·책 파일(files)·표지(covers)·읽은 자리(progress)·형광펜/메모/제보/책갈피(notes)
//   ·클로드 답장(news: 결과 쪽지 한 건씩 — 고침·그대로 둠·질문)
const NAME = 'ebook';
const VERSION = 2;
let opening = null;

function open() {
  opening ||= new Promise((resolve, reject) => {
    const r = indexedDB.open(NAME, VERSION);
    r.onupgradeneeded = (e) => {
      const d = r.result;
      if (e.oldVersion < 1) {
        d.createObjectStore('books', { keyPath: 'id' });
        d.createObjectStore('files');
        d.createObjectStore('covers');
        d.createObjectStore('progress', { keyPath: 'id' });
        d.createObjectStore('notes', { keyPath: 'id' }).createIndex('book', 'bookId');
      }
      if (e.oldVersion < 2) d.createObjectStore('news', { keyPath: 'id' });
    };
    r.onsuccess = () => resolve(r.result);
    r.onerror = () => reject(r.error);
  });
  return opening;
}

const done = (req) => new Promise((resolve, reject) => {
  req.onsuccess = () => resolve(req.result);
  req.onerror = () => reject(req.error);
});

async function store(name, mode = 'readonly') {
  return (await open()).transaction(name, mode).objectStore(name);
}

export const db = {
  async get(name, key) { return done((await store(name)).get(key)); },
  async all(name) { return done((await store(name)).getAll()); },
  async put(name, value, key) { return done((await store(name, 'readwrite')).put(value, key)); },
  async del(name, key) { return done((await store(name, 'readwrite')).delete(key)); },
  async notesOf(bookId) { return done((await store('notes')).index('book').getAll(bookId)); },
  // 책 하나를 흔적까지 지운다(파일·표지·읽은 자리·메모)
  async removeBook(id) {
    const d = await open();
    const t = d.transaction(['books', 'files', 'covers', 'progress', 'notes'], 'readwrite');
    for (const s of ['books', 'files', 'covers', 'progress']) t.objectStore(s).delete(id);
    const idx = t.objectStore('notes').index('book');
    idx.openKeyCursor(IDBKeyRange.only(id)).onsuccess = (e) => {
      const c = e.target.result;
      if (c) { t.objectStore('notes').delete(c.primaryKey); c.continue(); }
    };
    return new Promise((resolve, reject) => { t.oncomplete = resolve; t.onerror = () => reject(t.error); });
  },
};
