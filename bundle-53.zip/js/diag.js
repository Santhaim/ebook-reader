// 쪽 나눔 기록 — «글자 재배열» 원인 찾기(사용자 «폴드5 펼쳐보니 여전히 재배열 뜸 · 폰이 다른 곳에 있어서 오늘은 디버깅 모드 못해» 11-14)
//   책을 열 때·읽다가 창 크기가 바뀔 때(폴드 펴고 접기·돌리기) 1초 조용해질 때까지 창 크기·껍데기 값(막대·카메라 자리)·가림·다시 나눈
//   시각을 한 덩이로 모은다 → 글이 보이는 채로 다시 나눴거나 보이자마자 다시 가렸으면(= 글이 움직여 보였으면) 우편함 diag/ 에 올린다
//   · 견본: 폰마다 처음 책 열기 3번·큰 크기 바뀜(폴드 등) 6번도 올린다 · 책 글·책 이름은 안 담는다(크기·시각·쪽 번호·보기 설정만)
//   · 폰엔 8개까지 모아 두고 올리면 지운다
import { settings } from './settings.js';
import { bridge } from './native.js';
import { inboxConf, deviceName, putFile } from './reports.js';

const KEY = 'ebook.diag.v1';
const VARS = ['--sat', '--sat-max', '--sab-max', '--sal-max', '--sar-max', '--cut', '--cutb', '--cutl', '--cutr'];
let ep = null;          // 지금 모으는 한 덩이 { kind: open|size, t0, at, win0, vars0, big, ev }
let endT = 0;
let reading = () => false;
let lastVars = '';
let lastWin = [0, 0];

const vars = () => {
  const s = document.documentElement.style;
  return VARS.map((k) => Math.round((parseFloat(s.getPropertyValue(k)) || 0) * 10) / 10).join(',');
};
const load = () => { try { return JSON.parse(localStorage.getItem(KEY) || '{}') || {}; } catch { return {}; } };
const save = (d) => { try { localStorage.setItem(KEY, JSON.stringify(d)); } catch { /* 못 적으면 그만 */ } };

function begin(kind) {
  ep = { kind, t0: performance.now(), at: new Date().toISOString(), win0: [...lastWin], vars0: lastVars || vars(), big: false, ev: [] };
}

export function diagNote(kind, ...a) {
  try {
    if (!ep) {
      if (!reading()) { lastWin = [innerWidth, innerHeight]; return; }
      begin('size');
    }
    if (Math.abs(innerWidth - lastWin[0]) >= 100 || Math.abs(innerHeight - lastWin[1]) >= 100) ep.big = true;
    lastWin = [innerWidth, innerHeight];
    if (ep.ev.length < 200) ep.ev.push([Math.round(performance.now() - ep.t0), kind, ...a]);
    clearTimeout(endT);
    endT = setTimeout(finish, 1000);
  } catch { /* 기록은 읽기를 막지 않는다 */ }
}

// 책 열기 — 앞 덩이는 닫고 새로
export function diagOpen(...a) {
  try { finish(); lastWin = [innerWidth, innerHeight]; begin('open'); diagNote('open', innerWidth, innerHeight, ...a); } catch {}
}

// 읽는 중인지(창 크기 알림을 모을지) · 껍데기 값이 바뀌면 적는다
export function diagInit(isReading) {
  reading = isReading;
  lastVars = vars();
  lastWin = [innerWidth, innerHeight];
  new MutationObserver(() => {
    const v = vars();
    if (v === lastVars) return;
    lastVars = v;
    diagNote('vars', v);
  }).observe(document.documentElement, { attributes: true, attributeFilter: ['style'] });
}

// 글이 움직여 보였나 — 창 크기 탓에 보이는 채로 다시 나눔 · 보인 지 1초 안에 다시 가림 · 늦게 온 글꼴
//   (손으로 넘겼으면 판단 안 함 · 보기 설정을 바꿔 다시 나눈 것(force)은 사용자가 한 일)
function moved(ev) {
  let hidden = false;
  let shownAt = -1e9;
  let bad = false;
  for (const [t, k, a0] of ev) {
    if (k === 'turn') return false;
    if (k === 'shown' || k === 'show') { hidden = false; shownAt = t; }
    else if (k === 'hide') { if (t - shownAt < 1000) bad = true; hidden = true; }
    else if ((k === 'relayout' && a0 === 'size' && !hidden) || k === 'font-late') bad = true;
  }
  return bad;
}

function finish() {
  clearTimeout(endT);
  const e = ep;
  ep = null;
  if (!e) return;
  const bad = moved(e.ev);
  const d = load();
  const slot = e.kind === 'open' ? 'openLeft' : 'bigLeft';
  const left = d[slot] ?? (e.kind === 'open' ? 3 : 6);
  const sample = !bad && left > 0 && (e.kind === 'open' || e.big);
  if (!bad && !sample) return;
  if (sample) d[slot] = left - 1;
  d.list = [...(d.list || []), { why: bad ? 'moved' : 'sample', kind: e.kind, at: e.at, win0: e.win0, win1: [innerWidth, innerHeight],
    vars0: e.vars0, vars1: vars(), ev: e.ev }].slice(-8);
  save(d);
}

// 모아 둔 기록을 우편함 diag/ 로 — 우편함 살필 때마다(main.js pollMail)
let sending = false;
export async function sendDiag() {
  if (sending || !inboxConf()) return;
  const list = load().list || [];
  if (!list.length) return;
  sending = true;
  try {
    const base = {
      device: deviceName(), app: bridge.version(), dpr: devicePixelRatio, screen: [screen.width, screen.height], vars: VARS,
      set: { mode: settings.mode, spread: settings.spread, margin: settings.margin, fs: settings.fs, lh: settings.lh, font: settings.font, rotate: settings.rotate, anim: settings.anim },
    };
    for (const r of list) {
      const stamp = r.at.replace(/[-:]/g, '').replace(/\..+/, '').replace('T', '-');
      await putFile(`diag/${stamp}-${base.device}-${Math.random().toString(36).slice(2, 6)}.json`, JSON.stringify({ ...base, ...r }, null, 1), `쪽 나눔 기록 ${base.device}`);
      const d = load();
      d.list = (d.list || []).filter((x) => x.at !== r.at);
      save(d);
    }
  } finally {
    sending = false;
  }
}
