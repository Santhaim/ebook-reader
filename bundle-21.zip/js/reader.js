// 뷰어 — 권 하나를 통째로 한 흐름에 넣고, 좌우 넘기기는 CSS 단(column)으로 쪽을 나눈다.
//   자리 = { s: 장(spine) 번호, b: 장 안 문단 번호, o: 문단 안 글자 위치 } → 글자 크기·폴드를 바꿔도 같은 문장으로 돌아온다
import { db } from './db.js';
import { readEpub, mimeOf } from './epub.js';
import { settings, setSetting, readerTheme, READER_THEMES, applyAppTheme } from './settings.js';
import { bridge, native } from './native.js';
import { $, $$, esc, icon, toast, sheet, ask, pushLayer, clamp, fmtDate, actionSheet } from './ui.js';
import { byPos, volName, siblingVolume, reportText, markQuote } from './books.js';
import { reportTools, sendNow } from './library.js';
import { inboxConf, sendComment, explain } from './reports.js';
import { fixesFor, resultsByReport, resultChip, matchesReport } from './news.js';
import { makeCurl } from './curl.js';
import { spineLabels } from './regroup.js';

const BLOCK = 'p,h1,h2,h3,h4,h5,h6,li,pre,blockquote,dt,dd,figcaption,td,th,caption';
const MARGIN = { s: 16, m: 24, l: 36 };
const FONTS = {
  serif: { name: '명조', css: '"Noto Serif CJK KR","Noto Serif KR","Source Han Serif K","Batang",serif' },
  sans: { name: '고딕', css: 'sans-serif' },
};
const HL_COLORS = ['y', 'g', 'b', 'p'];
const NOTE_KINDS = { hl: '형광펜', memo: '메모', report: '제보', bm: '책갈피' };

let R = null;      // 지금 연 책
let H = {};        // main: onClosed(), openBook(id, opts)
let relayT = 0;

// ---------------- 열기·닫기 ----------------
export async function openBook(id, { at = null, findText = '', findChap = '' } = {}) {
  if (R) await closeBook(true);
  const book = await db.get('books', id);
  const file = await db.get('files', id);
  if (!book || !file) { toast('책 파일이 없어요'); return false; }
  let ep;
  try {
    ep = await readEpub(await file.arrayBuffer());
  } catch (e) {
    toast('책을 열 수 없어요: ' + e.message);
    return false;
  }
  const prog = await db.get('progress', id);
  R = { id, book, ep, prog, urls: [], notes: [], ranges: new Map(), screen: 0, screens: 1, spread: 1, menu: false, pos: { s: 0, b: 0, o: 0 }, ready: false };
  try {
    await build();
  } catch (e) {
    console.error('책 펼치기 실패', e);
    toast('책을 펼치지 못했어요: ' + e.message);
    R = null;
    return false;
  }
  R.ready = true;
  R.notes = await db.notesOf(id);
  book.openedAt = Date.now();
  if (!Array.isArray(book.labels)) book.labels = await spineLabels(ep);   // 화면 판 20 전에 넣은 권 — 장 이름을 채워 둔다(regroup.js)
  db.put('books', book);

  $('#scr-reader').hidden = false;  // 쪽 나누기는 화면에 보여야 잴 수 있다
  applyTheme();
  applyTypo();
  enterReaderMode();
  showMenu(false);
  const found = findText ? findTextPos(findText, findChap) : null;   // «클로드 답장 → 읽기 화면에서 보기»
  repaginate(found || at || prog?.pos || { s: 0, b: 0, o: 0 });
  paintNotes();
  paintFixes();
  return true;
}

// 새 판에서 고친 문장 — 번역기 결과 쪽지의 after 글을 이 권에서 찾아 초록 점선(30일 동안)
//   쪽지에 장(chap)이 있으면 그 장 안에서 먼저 찾는다(«“알겠습니다.”» 같은 짧은 대사는 권 전체엔 여러 번 나온다 · 10-25 번역기 세션 질문)
function chapSections(chap) {
  if (!chap) return null;
  const num = (s) => (String(s).match(/제\s*(\d+)\s*장/) || [])[1];
  const flat = (s) => String(s).replace(/\s+/g, '');
  const n = num(chap);
  const out = new Set();
  R.sections.forEach((sec, s) => {
    const lab = R.label[s] || '';
    if (!lab) return;
    if (n ? num(lab) === n : flat(lab).startsWith(flat(chap)) || flat(chap).startsWith(flat(lab))) out.add(s);
  });
  return out.size ? out : null;
}

function findText(text, chap = '') {
  const t = (text || '').replace(/\s+/g, ' ').trim();
  if (!t) return null;
  const secs = chapSections(chap);
  const pools = secs ? [R.tb.filter((el) => secs.has(R.info.get(el).s)), R.tb] : [R.tb];
  for (const pool of pools) {
    for (const probe of [t, t.slice(0, 24)]) {
      if (probe.length < 4 && probe !== t) continue;
      for (const el of pool) {
        const i = el.textContent.indexOf(probe);
        if (i >= 0) return { el, i, len: probe === t ? t.length : Math.min(t.length, el.textContent.length - i) };
      }
    }
  }
  return null;
}

function findTextPos(text, chap = '') {
  const hit = findText(text, chap);
  if (!hit) return null;
  const info = R.info.get(hit.el);
  return { s: info.s, b: info.b, o: hit.i };
}

async function paintFixes() {
  if (!R || !window.CSS?.highlights) return;
  const book = R.book;
  const items = await fixesFor(book);
  if (!R || R.book !== book) return;
  R.fixes = [];
  for (const it of items) {
    const hit = findText(it.after, it.chap);
    if (!hit) continue;   // 아직 옛 판이면 못 찾는다 — 새 판을 받으면 보인다
    const [n1, o1] = locate(hit.el, hit.i);
    const [n2, o2] = locate(hit.el, hit.i + hit.len);
    const rg = document.createRange();
    rg.setStart(n1, o1);
    rg.setEnd(n2, o2);
    R.fixes.push({ rg, it });
  }
  CSS.highlights.set('fixed', new Highlight(...R.fixes.map((f) => f.rg)));
}

function fixAt(x, y) {
  const c = document.caretRangeFromPoint?.(x, y);
  if (!c || !R.fixes) return null;
  for (const f of R.fixes) {
    try { if (f.rg.comparePoint(c.startContainer, c.startOffset) === 0) return f; } catch {}
  }
  return null;
}

function fixPop(f, x, y) {
  const it = f.it;
  const mine = !!(it.quote || it.memo) || R.notes.some((n) => matchesReport(it, n));
  const pop = $('#note-pop');
  pop.innerHTML = `<div class="pn"><span class="fx">고친 문장 · ${fmtDate(Date.parse(it.at))} 새 판</span></div>
    ${it.before && !it.reply ? `<div class="fo">전: <s>${esc(it.before)}</s></div>` : ''}
    ${it.why || mine ? `<div class="fo">${esc(it.why || '')}${mine ? `${it.why ? ' · ' : ''}내 제보` : ''}</div>` : ''}
    ${inboxConf() ? '<div class="pb-row"><button data-a="comment">답글 달기</button></div>' : ''}`;
  R.popNote = null;
  R.popFix = it;
  placePop(pop, f.rg.getClientRects().length ? f.rg.getClientRects() : [{ left: x, top: y, bottom: y }]);
}

// 고친 문장에 답글 — 다시 제보하지 않고 클로드 답에 덧붙이는 말(우편함으로 바로)
function commentSheet(it) {
  const s = sheet({
    title: '클로드에게 답글',
    body: `<div class="quote">${esc(it.after)}${it.why ? `<div class="qhint">클로드: ${esc(it.why)}</div>` : ''}</div>
      <textarea id="nt-text" rows="4" placeholder="덧붙일 말 — 예: 조금 더 부드럽게"></textarea>
      <div class="sheet-btns"><span class="sp"></span><button class="btn" data-a="send">보내기</button></div>`,
  });
  const ta = s.body.querySelector('#nt-text');
  setTimeout(() => ta.focus(), 250);
  s.body.onclick = async (e) => {
    const btn = e.target.closest('[data-a="send"]');
    if (!btn) return;
    const text = ta.value.trim();
    if (!text) { toast('덧붙일 말을 적어 주세요'); return; }
    btn.disabled = true;
    try {
      await sendComment(it, text);
      s.close();
      toast('클로드에게 답글을 보냈어요 · 답은 서재 위 종에서', 3000);
    } catch (err) {
      btn.disabled = false;
      toast(explain(err), 3500);
    }
  };
}

export async function closeBook(switching = false) {
  if (!R) return;
  ttsStop();
  hideSelPop();
  hideNotePop();
  if (R.menu) showMenu(false);
  clearTimeout(R.saveT);
  curlDone(false);
  curl?.clear();
  await saveProgress();
  for (const u of R.urls) URL.revokeObjectURL(u);
  if (window.CSS?.highlights) CSS.highlights.clear();
  $('#rd-flow').innerHTML = '';
  $('#bk-css').textContent = '';
  R = null;
  if (!switching) exitReaderMode();
}

export const isOpen = () => !!R;

function enterReaderMode() {
  document.body.classList.add('reading');
  bridge.setReading(true);
  applyBrightness();
  bridge.keepScreenOn(settings.keepOn);
  bridge.setOrientation(settings.rotate);
  bridge.setVolumeKeys(settings.volKeys);
  bridge.setNativeSelection(false);
  bridge.setImmersive(true);
}

function exitReaderMode() {
  document.body.classList.remove('reading');
  bridge.setReading(false);
  bridge.setAutoBrightness(false);
  bridge.setBrightness(-1);
  bridge.keepScreenOn(false);
  bridge.setOrientation('auto');
  bridge.setVolumeKeys(false);
  bridge.setNativeSelection(true);
  bridge.setImmersive(false);
  applyAppTheme();
}

// ---------------- 본문 만들기 ----------------
async function build() {
  const flow = $('#rd-flow');
  flow.innerHTML = '';
  const cssPaths = new Set();
  const styles = [];
  const frag = document.createDocumentFragment();
  R.sections = [];
  for (let i = 0; i < R.ep.spine.length; i++) {
    const ch = await R.ep.chapter(i);
    ch.css.forEach((p) => p && cssPaths.add(p));
    styles.push(...ch.styles);
    const sec = document.createElement('section');
    sec.className = ('ch ' + ch.cls).trim();
    sec.dataset.s = i;
    sec.innerHTML = ch.html;
    if (!sec.textContent.trim() && sec.querySelector('img,svg')) sec.classList.add('imgonly');
    frag.appendChild(sec);
    R.sections.push(sec);
  }
  const end = document.createElement('div');
  end.id = 'rd-end';
  frag.appendChild(end);
  flow.appendChild(frag);

  let css = '';
  for (const p of cssPaths) css += ((await R.ep.zip.text(p)) || '') + '\n';
  $('#bk-css').textContent = scopeCss(css + styles.join('\n'));

  await Promise.all($$('[data-zip]', flow).map(async (el) => {
    const blob = await R.ep.zip.blob(el.dataset.zip, mimeOf(el.dataset.zip));
    if (!blob) return;
    const u = URL.createObjectURL(blob);
    R.urls.push(u);
    if (el.localName === 'img') {
      el.src = u;
      // 크기를 알아야 쪽을 나눌 수 있다(가려진 창에선 decode 가 늦게 끝날 수 있어 1.5초만 기다림)
      await Promise.race([el.decode().catch(() => {}), new Promise((r) => setTimeout(r, 1500))]);
    } else el.setAttribute('href', u);
  }));

  // 문단 목록(안에 다른 문단이 없는 것만) · 누적 글자 수
  R.blocks = [];
  R.secBlocks = [];
  R.info = new Map();
  R.cum = [];
  let total = 0;
  for (const sec of R.sections) {
    const s = +sec.dataset.s;
    const list = $$(BLOCK, sec).filter((el) => !el.querySelector(BLOCK));
    if (!list.length && sec.textContent.trim()) list.push(sec);
    R.secBlocks[s] = list;
    list.forEach((el, b) => {
      R.info.set(el, { g: R.blocks.length, s, b });
      R.cum.push(total);
      total += el.textContent.length;
      R.blocks.push(el);
    });
  }
  R.total = Math.max(1, total);
  // 자리 찾기(이분 탐색)는 글자가 있는 문단만 — 빈 줄(p.blank)은 상자가 없어 순서를 흐린다
  R.tb = R.blocks.filter((el) => /\S/.test(el.textContent));

  // 장 이름: 목차 → 없으면 장 첫 제목
  R.label = [];
  let last = '';
  for (let i = 0; i < R.sections.length; i++) {
    const t = R.ep.toc.filter((x) => x.s === i)[0];
    if (t) last = t.label;
    else if (!R.ep.toc.length) last = R.sections[i].querySelector('h1,h2,h3')?.textContent.trim() || last;
    R.label[i] = last;
  }
  addTocPage();
}

// 책의 CSS 는 .bk 안에서만 먹게 선택자 앞에 붙인다(body → 장 section)
function scopeCss(text) {
  try {
    const sh = new CSSStyleSheet();
    sh.replaceSync(text);
    return [...sh.cssRules].map(scopeRule).join('\n');
  } catch {
    return '';
  }
}
function scopeRule(rule) {
  if (rule instanceof CSSStyleRule) {
    const sel = rule.selectorText.split(',').map((s) => {
      s = s.trim().replace(/^(html|:root)\b\s*/, '');
      if (!s) return '.bk';
      return /^body\b/.test(s) ? '.bk section.ch' + s.slice(4) : '.bk ' + s;
    }).join(', ');
    return `${sel} { ${rule.style.cssText} }`;
  }
  if (rule instanceof CSSMediaRule) return `@media ${rule.conditionText} { ${[...rule.cssRules].map(scopeRule).join('\n')} }`;
  return '';
}

// ---------------- 모양 ----------------
function applyTypo() {
  const st = $('#scr-reader').style;
  st.setProperty('--fs', settings.fs + 'px');
  st.setProperty('--lh', settings.lh);
  st.setProperty('--pm', settings.pm + 'em');
  st.setProperty('--ti', settings.indent ? '1em' : '0');
  st.setProperty('--ta', settings.justify ? 'justify' : 'start');
  st.setProperty('--font', (FONTS[settings.font] || FONTS.serif).css);
}

function applyTheme() {
  const t = readerTheme();
  const el = $('#scr-reader');
  el.dataset.rt = t.key;
  el.classList.toggle('rdark', t.dark);
  el.style.setProperty('--rbg', t.bg);
  el.style.setProperty('--rink', t.ink);
  el.style.setProperty('--rsub', t.sub);
  bridge.setBars(t.bg, !t.dark);
}

function layout() {
  if (!R) return;
  const view = $('#rd-view');
  const flow = $('#rd-flow');
  const W = view.clientWidth;
  const Hh = view.clientHeight;
  if (!W || !Hh) return;
  curlDone(false);
  curl?.clear();   // 종이책 넘김의 쪽 사본은 쪽을 새로 나누면 다시 만든다(R.gen)
  R.gen = (R.gen || 0) + 1;
  const m = MARGIN[settings.margin] || 24;
  R.W = W;
  R.H = Hh;
  flow.style.setProperty('--ph', Hh + 'px');
  const reader = $('#scr-reader');
  if (settings.mode === 'scroll') {
    R.scroll = true;
    R.tocCol = null;
    R.spread = 1;
    view.classList.add('scroll');
    reader.classList.remove('two');
    Object.assign(flow.style, { left: '', width: '', height: '', columnCount: '', columnGap: '', transform: '', transition: '', padding: `0 ${m}px 40px` });
    reader.style.setProperty('--mx', m + 'px');
    return;
  }
  R.scroll = false;
  view.classList.remove('scroll');
  view.scrollTop = 0;
  // 넓은 화면(폴드를 폈을 때·가로 폰)은 두 쪽 — 가운데 접는 선 둘레는 비운다
  const two = settings.spread === 'auto' && W >= 600 && W / Hh >= 0.75;
  const spread = two ? 2 : 1;
  const gap = two ? Math.max(2 * m, 56) : 2 * m;
  const cw = Math.floor((W - 2 * m - (spread - 1) * gap) / spread);
  const used = spread * cw + (spread - 1) * gap;
  const left = (W - used) / 2;
  Object.assign(flow.style, {
    left: left + 'px', width: used + 'px', height: Hh + 'px', padding: '0',
    columnCount: String(spread), columnGap: gap + 'px', transition: 'none', transform: 'translateX(0)',
  });
  Object.assign(R, { spread, gap, cw, pitch: cw + gap, left });
  reader.style.setProperty('--mx', left + 'px');
  reader.classList.toggle('two', two);
  const fl = flow.getBoundingClientRect().left;
  R.columns = Math.max(1, Math.floor(($('#rd-end').getBoundingClientRect().left - fl + 1) / R.pitch) + 1);
  R.screens = Math.ceil(R.columns / spread);
  const colOfEl = (el) => {
    const r = el?.getClientRects()[0];
    return r ? Math.floor((r.left - fl + 1) / R.pitch) : -1;
  };
  R.secCol = R.sections.map((sec) => Math.max(0, colOfEl(sec)));
  // 흐름의 덩어리(장·목차 쪽)마다 시작 단 — 덩어리는 늘 새 단에서 시작한다(종이책 넘김이 그 쪽이 든 덩어리만 복사)
  R.kids = [...flow.children].filter((el) => el.id !== 'rd-end');
  let last = 0;
  R.kidCol = R.kids.map((el) => (last = Math.max(last, colOfEl(el))));
  const ti = R.kids.findIndex((el) => el.classList.contains('rd-toc'));
  R.tocCol = ti < 0 ? null : [R.kidCol[ti], (R.kidCol[ti + 1] ?? R.columns) - 1];
  if (ti >= 0) {
    // 목차 쪽 번호 = 아래 쪽 표시와 같은 셈(두 쪽 보기면 단 번호) — 다 잰 뒤에 한꺼번에 쓴다(쓰고 재고를 섞으면 매번 다시 나눈다)
    const items = $$('.rd-toc-it', R.kids[ti]);
    const nums = items.map((it) => {
      const sec = R.sections[+it.dataset.s];
      const c = colOfEl((it.dataset.frag && sec?.querySelector('#' + CSS.escape(it.dataset.frag))) || sec);
      return c < 0 ? '' : String(c + 1);
    });
    items.forEach((it, i) => { const n = it.lastElementChild; if (n.textContent !== nums[i]) n.textContent = nums[i]; });
  }
}

// 글자 크기·폴드·회전이 바뀌면 같은 문장으로 돌아간다(R.pos 는 그대로 — 여러 번 바꿔도 밀리지 않게)
function relayout() {
  clearTimeout(relayT);
  relayT = setTimeout(() => {
    if (!R) return;
    repaginate(R.pos);
    if (R.menu) updateInfo();
  }, 90);
}

// 쪽을 새로 나누면 쪽 경계가 처음부터 다시 정해져서, 읽던 문장이 새 쪽 한가운데(두 쪽이면 오른쪽 쪽 아래)에
// 놓일 수 있다 — 폴드를 펴면 이미 읽은 글이 1~2쪽 다시 보였다(10-25 제보). 그래서 읽던 문장 바로 앞에서
// 단을 끊어 그 문장이 쪽(두 쪽이면 왼쪽 쪽) 맨 위에 오게 한다. 끊는 곳은 하나만 두고, 다음에 다시 나눌 때 옮긴다.
function repaginate(pos) {
  placeAnchor(pos);
  layout();
  if (fixParity()) layout();
  goPos(pos, { keep: true });
}

function clearAnchor() {
  const flow = $('#rd-flow');
  for (const el of $$('.rd-anchor', flow)) el.classList.remove('rd-anchor');
  for (const el of $$('.rd-brk,.rd-pad', flow)) {
    const parent = el.parentNode;
    el.remove();
    parent.normalize();
  }
  R.anchorEl = null;
}

function placeAnchor(pos) {
  clearAnchor();
  if (settings.mode === 'scroll' || !pos) return;
  const el = blockAt(pos);
  if (!el || (pos.o <= 0 && pos.b <= 0)) return;  // 장 첫머리는 원래 새 쪽
  if (pos.o <= 0) {
    el.classList.add('rd-anchor');
    R.anchorEl = el;
    return;
  }
  const [node, off] = locate(el, pos.o);
  if (node.nodeType !== 3) {
    el.classList.add('rd-anchor');
    R.anchorEl = el;
    return;
  }
  const br = document.createElement('span');
  br.className = 'rd-brk';
  const rg = document.createRange();
  rg.setStart(node, off);
  rg.collapse(true);
  rg.insertNode(br);
  R.anchorEl = br;
}

// 두 쪽 보기에서 읽던 문장이 오른쪽 쪽에 섰으면 빈 쪽 하나를 넣어 왼쪽 쪽으로 보낸다
function fixParity() {
  if (R.scroll || R.spread !== 2 || !R.anchorEl) return false;
  const r = R.anchorEl.getClientRects()[0];
  if (!r || colOf(r.left) % 2 === 0) return false;
  const pad = document.createElement(R.anchorEl.classList.contains('rd-brk') ? 'span' : 'div');
  pad.className = 'rd-pad';
  R.anchorEl.before(pad);
  return true;
}

// ---------------- 자리 계산 ----------------
function blockAt(pos) {
  const list = R.secBlocks[pos?.s];
  if (!list || !list.length) return null;
  return list[clamp(pos.b, 0, list.length - 1)];
}

function textNodes(el) {
  const out = [];
  const w = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
  let n;
  let acc = 0;
  while ((n = w.nextNode())) { out.push([n, acc]); acc += n.data.length; }
  return out;
}

function locate(el, offset) {
  let last = null;
  for (const [n, base] of textNodes(el)) {
    if (offset < base + n.data.length) return [n, Math.max(0, offset - base)];
    last = n;
  }
  return last ? [last, last.data.length] : [el, 0];
}

function posFromDom(node, off) {
  let el = node.nodeType === 3 ? node.parentElement : node;
  let blk = el;
  while (blk && !R.info.has(blk)) blk = blk.parentElement;
  if (!blk) {
    const sec = el?.closest?.('section.ch') || R.sections[0];
    const s = +sec.dataset.s;
    const list = R.secBlocks[s] || [];
    const next = list.find((b) => node.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING);
    if (next) { const i = R.info.get(next); return { s: i.s, b: i.b, o: 0 }; }
    return { s, b: Math.max(0, list.length - 1), o: 0 };
  }
  const i = R.info.get(blk);
  const rg = document.createRange();
  rg.setStart(blk, 0);
  try { rg.setEnd(node, off); } catch { return { s: i.s, b: i.b, o: 0 }; }
  return { s: i.s, b: i.b, o: rg.toString().length };
}

function rectOfPos(pos) {
  if (pos?.toc) {
    const r = $('.rd-toc', $('#rd-flow'))?.getClientRects()[0];
    if (r) return r;
  }
  const el = blockAt(pos);
  if (!el) return R.sections[clamp(pos?.s ?? 0, 0, R.sections.length - 1)]?.getClientRects()[0] || null;
  const [node, off] = locate(el, pos.o);
  if (node.nodeType === 3 && node.data.length) {
    const rg = document.createRange();
    const o = Math.min(off, node.data.length - 1);
    rg.setStart(node, o);
    rg.setEnd(node, o + 1);
    const rs = rg.getClientRects();
    if (rs.length) return rs[0];
  }
  return el.getClientRects()[0] || null;
}

function colOf(x) {
  return Math.floor((x - $('#rd-flow').getBoundingClientRect().left + 1) / R.pitch);
}

function screenOf(pos) {
  if (pos?.toc && R.tocCol) return clamp(Math.floor(R.tocCol[0] / R.spread), 0, R.screens - 1);
  const r = rectOfPos(pos);
  return r ? clamp(Math.floor(colOf(r.left) / R.spread), 0, R.screens - 1) : 0;
}

function gIndex(pos) {
  const el = blockAt(pos);
  if (el) return R.info.get(el).g;
  const later = R.blocks.find((b) => R.info.get(b).s >= (pos?.s ?? 0));
  return later ? R.info.get(later).g : R.blocks.length;
}

function pctOf(pos) {
  const g = gIndex(pos);
  const base = g < R.cum.length ? R.cum[g] : R.total;
  return clamp(((base + (blockAt(pos) ? pos.o : 0)) / R.total) * 100, 0, 100);
}

// 이 쪽(화면)의 첫 글자 자리 — 목차 쪽이면 { toc: 1 }(s 는 목차 다음 장: 읽은 % 셈용)
function posAtScreen(n) {
  const B = R.tb;
  const c0 = n * R.spread;
  if (R.tocCol && c0 >= R.tocCol[0] && c0 <= R.tocCol[1]) return { s: R.tocS, b: 0, o: 0, toc: 1 };
  if (!B.length) return { s: 0, b: 0, o: 0 };
  const fl = $('#rd-flow').getBoundingClientRect().left;
  const col = (x) => Math.floor((x - fl + 1) / R.pitch);
  const rg = document.createRange();
  const lastCol = (el) => {
    rg.selectNodeContents(el);
    const rs = rg.getClientRects();
    return rs.length ? col(rs[rs.length - 1].left) : -1;
  };
  let lo = 0;
  let hi = B.length - 1;
  let ans = B.length - 1;
  while (lo <= hi) {
    const mid = (lo + hi) >> 1;
    if (lastCol(B[mid]) >= c0) { ans = mid; hi = mid - 1; } else lo = mid + 1;
  }
  const el = B[ans];
  const info = R.info.get(el);
  rg.selectNodeContents(el);
  const first = rg.getClientRects()[0];
  if (!first || col(first.left) >= c0) {
    // 문단이 이 쪽에서 시작 — 앞에 그림만 있는 장(표지)이면 그 장을 가리킨다
    const sc = R.secCol?.findLastIndex?.((c) => c <= c0) ?? -1;
    if (sc >= 0 && sc < info.s && R.sections[sc].classList.contains('imgonly')) return { s: sc, b: 0, o: 0 };
    return { s: info.s, b: info.b, o: 0 };
  }
  return { s: info.s, b: info.b, o: charWhere(el, (r) => col(r.left) >= c0) };
}

// 조건을 처음 만족하는 글자(이분 탐색 — 글자 순서대로 단·줄이 늘어난다)
function charWhere(el, ok) {
  const nodes = textNodes(el);
  const total = nodes.length ? nodes[nodes.length - 1][1] + nodes[nodes.length - 1][0].data.length : 0;
  const rg = document.createRange();
  const test = (k) => {
    let i = nodes.length - 1;
    while (i > 0 && nodes[i][1] > k) i--;
    const [n, base] = nodes[i];
    const o = Math.min(k - base, n.data.length - 1);
    rg.setStart(n, o);
    rg.setEnd(n, o + 1);
    const r = rg.getClientRects()[0];
    return r ? ok(r) : false;
  };
  let lo = 0;
  let hi = total - 1;
  let ans = 0;
  while (lo <= hi) {
    const mid = (lo + hi) >> 1;
    if (test(mid)) { ans = mid; hi = mid - 1; } else lo = mid + 1;
  }
  return ans;
}

// 스크롤 보기: 화면 맨 위 글자
function posAtScroll() {
  const B = R.tb;
  if (!B.length) return { s: 0, b: 0, o: 0 };
  const top = $('#rd-view').getBoundingClientRect().top + 2;
  const rg = document.createRange();
  let lo = 0;
  let hi = B.length - 1;
  let ans = B.length - 1;
  while (lo <= hi) {
    const mid = (lo + hi) >> 1;
    rg.selectNodeContents(B[mid]);
    const rs = rg.getClientRects();
    if (rs.length && rs[rs.length - 1].bottom > top) { ans = mid; hi = mid - 1; } else lo = mid + 1;
  }
  const el = B[ans];
  const info = R.info.get(el);
  rg.selectNodeContents(el);
  const first = rg.getClientRects()[0];
  if (!first || first.top >= top) return { s: info.s, b: info.b, o: 0 };
  return { s: info.s, b: info.b, o: charWhere(el, (r) => r.top >= top - 1) };
}

// ---------------- 움직이기 ----------------
function setScreen(n, anim) {
  curlDone(false);   // 넘기던 장은 접고(쪽 이동·듣기·밀대가 먼저)
  R.screen = clamp(n, 0, R.screens - 1);
  const flow = $('#rd-flow');
  flow.style.transition = anim && settings.anim === 'slide' ? 'transform .26s cubic-bezier(.2,.7,.3,1)' : 'none';
  flow.style.transform = `translateX(${-R.screen * R.spread * R.pitch}px)`;
}

// keep = 쪽을 다시 나눈 뒤(기준 문장 그대로) · 아니면(목차·검색·메모로 이동) 그 쪽의 첫 글자를 새 기준으로
function goPos(pos, { flash = null, keep = false } = {}) {
  if (!R) return;
  const p = pos && R.sections[pos.s] ? pos : { s: 0, b: 0, o: 0 };
  if (R.scroll) {
    const view = $('#rd-view');
    const r = rectOfPos(p);
    if (r) view.scrollTop += r.top - view.getBoundingClientRect().top - (p.o ? 6 : 0);
    R.pos = p;
  } else {
    setScreen(screenOf(p), false);
    R.pos = keep ? p : posAtScreen(R.screen);
  }
  if (flash) flashRange(flash);
  afterMove();
}

function atEnd() {
  if (R.scroll) {
    const v = $('#rd-view');
    return v.scrollTop + v.clientHeight >= v.scrollHeight - 4;
  }
  return R.screen >= R.screens - 1;
}

function turn(dir) {
  if (!R) return;
  hideNotePop();
  if (R.scroll) {
    const v = $('#rd-view');
    if (dir > 0 && atEnd()) { endOfBook(); return; }
    v.scrollBy({ top: dir * (v.clientHeight - 48), behavior: settings.anim === 'slide' ? 'smooth' : 'auto' });
    return;
  }
  curlFinish();   // 넘어가던 장은 다 넘기고 다음으로
  const n = R.screen + dir;
  if (n < 0) { setScreen(0, true); startOfBook(); return; }
  if (n >= R.screens) { setScreen(R.screen, true); endOfBook(); return; }
  if (settings.anim === 'curl' && curlBegin(dir)) {
    curlRun(1, R.spread === 2 ? 620 : 500, easeInOut);
    return;
  }
  setScreen(n, true);
  R.pos = posAtScreen(n);
  afterMove();
}

async function endOfBook() {
  R.prog = { ...(R.prog || {}), done: true };
  await saveProgress();
  if (settings.nextVol) {
    const nx = await siblingVolume(R.book, 1);
    if (nx) {
      toast(`${volName(nx)}으로 넘어가요`);
      const p = await db.get('progress', nx.id);
      await H.openBook(nx.id, { at: p && !p.done ? p.pos : { s: 0, b: 0, o: 0 } });
      return;
    }
  }
  toast(R.book.series ? '마지막 권의 마지막 쪽이에요' : '마지막 쪽이에요');
}

async function startOfBook() {
  const pv = settings.nextVol && (await siblingVolume(R.book, -1));
  toast(pv ? `첫 쪽이에요 · 앞 권은 ${volName(pv)}` : '첫 쪽이에요');
}

function afterMove() {
  updateInfo();
  clearTimeout(R.saveT);
  R.saveT = setTimeout(saveProgress, 500);
  if (R.searchHit && R.searchHitAt !== R.screen) { CSS.highlights?.delete('search'); R.searchHit = null; }
}

async function saveProgress() {
  if (!R?.ready) return;
  const end = atEnd();
  const done = !!R.prog?.done || end;
  R.prog = { id: R.id, pos: R.pos, pct: end ? 100 : Math.round(pctOf(R.pos) * 10) / 10, done, at: Date.now(), chap: chapOf(R.pos) };
  await db.put('progress', R.prog);
}

function bookTitle() { return volName(R.book); }
const chapOf = (pos) => (pos?.toc ? '목차' : R.label[pos?.s] || '');

// 쪽 위·아래 글(장 이름 · 쪽 번호) — 지금 쪽에도, 종이책 넘김의 쪽 사본에도
function pageInfo(screen, pos, end) {
  const pct = Math.floor(end ? 100 : pctOf(pos));
  let fl = '';
  let fr = `${pct}%`;
  if (!R.scroll) {
    const c0 = screen * R.spread;
    if (R.spread === 2) {
      fl = String(c0 + 1);
      fr = `${Math.min(c0 + 2, R.columns)} / ${R.columns}쪽 · ${pct}%`;
    } else fl = `${screen + 1} / ${R.screens}쪽`;
  }
  return { chap: chapOf(pos), pct, fl, fr };
}

function updateInfo() {
  if (!R) return;
  const { chap, pct, fl, fr } = pageInfo(R.screen, R.pos, atEnd());
  $('#rd-hb').textContent = bookTitle();
  $('#rd-hc').textContent = chap;
  $('#rd-title').textContent = bookTitle();
  let page = `${pct}%`;
  let left = '';
  if (!R.scroll) {
    const c0 = R.screen * R.spread;
    page = `<b>${R.spread === 2 ? `${c0 + 1}-${Math.min(c0 + 2, R.columns)}` : R.screen + 1}</b> / ${R.spread === 2 ? R.columns : R.screens}쪽`;
    const secCol = R.secCol || [];
    const si = secCol.findLastIndex((c) => c <= c0);
    const nextCol = secCol.find((c, i) => i > si && c > c0) ?? R.columns;
    left = ` · 이 장 남은 쪽 ${Math.max(0, Math.ceil((nextCol - c0) / R.spread) - 1)}`;
    const sl = $('#rd-slider');
    sl.max = String(R.screens - 1);
    sl.value = String(R.screen);
  } else {
    const sl = $('#rd-slider');
    sl.max = '1000';
    sl.value = String(Math.round(pct * 10));
  }
  $('#rd-fl').textContent = fl;
  $('#rd-fr').textContent = fr;
  $('#rd-pchap').innerHTML = `<b>${esc(chap)}</b>${left}`;
  $('#rd-ppage').innerHTML = page;
  updateRibbon();
}

// ---------------- 손가락 ----------------
let lastTouch = 0;
function bindGestures() {
  const view = $('#rd-view');
  let g = null;
  view.addEventListener('touchstart', (e) => {
    lastTouch = Date.now();
    if (!R || e.touches.length !== 1) { g = null; return; }
    curlFinish();   // 넘어가던 장은 다 넘기고 새로 잡는다
    const t = e.touches[0];
    const sel = !document.getSelection().isCollapsed;
    g = { x: t.clientX, y: t.clientY, t: Date.now(), mode: sel ? 'none' : null, dx: 0, dy: 0, sel, vx: 0, mt: performance.now() };
  }, { passive: true });
  view.addEventListener('touchmove', (e) => {
    if (!g || g.mode === 'none') return;
    const t = e.touches[0];
    const now = performance.now();
    g.vx = g.vx * 0.5 + ((t.clientX - g.x - g.dx) / Math.max(1, now - g.mt)) * 0.5;   // 최근 빠르기(px/ms)
    g.mt = now;
    g.dx = t.clientX - g.x;
    g.dy = t.clientY - g.y;
    if (!g.mode) {
      if (Math.abs(g.dx) < 12 && Math.abs(g.dy) < 12) return;
      const horiz = Math.abs(g.dx) > Math.abs(g.dy);
      if (R.scroll) {
        const edge = g.x - view.getBoundingClientRect().left < view.clientWidth * 0.14;
        g.mode = !horiz && edge ? 'bright' : 'none';
      } else g.mode = horiz ? 'drag' : 'bright';
      if (g.mode === 'bright') briStart();
      if (g.mode !== 'none') { hideSelPop(); hideNotePop(); }
    }
    if (g.mode === 'drag') { e.preventDefault(); dragTo(g); }
    else if (g.mode === 'bright') { e.preventDefault(); briMove(g.dy); }
  }, { passive: false });
  view.addEventListener('touchend', (e) => {
    lastTouch = Date.now();
    if (!g) return;
    const gg = g;
    g = null;
    if (gg.mode === 'drag') dragEnd(gg);
    else if (gg.mode === 'bright') briEnd();
    else if (gg.mode === null && !gg.sel && Date.now() - gg.t < 450) {
      e.preventDefault();
      tapAt(gg.x, gg.y);
    }
  });
  view.addEventListener('touchcancel', () => {
    if (g?.mode === 'drag') { if (R.curl) curlRun(0, 200, easeOut); else setScreen(R.screen, true); }
    if (g?.mode === 'bright') briEnd();
    g = null;
  });
  // PC 시험: 클릭·휠·화살표
  view.addEventListener('click', (e) => {
    if (Date.now() - lastTouch < 700 || !R) return;
    if (!document.getSelection().isCollapsed) return;
    tapAt(e.clientX, e.clientY);
  });
  let wheelT = 0;
  view.addEventListener('wheel', (e) => {
    if (!R || R.scroll) return;
    e.preventDefault();
    if (Date.now() - wheelT < 250) return;
    wheelT = Date.now();
    turn(e.deltaY > 0 || e.deltaX > 0 ? 1 : -1);
  }, { passive: false });
  document.addEventListener('keydown', (e) => {
    if (!R || e.target.closest?.('input,textarea')) return;
    if (['ArrowRight', 'PageDown', ' '].includes(e.key)) { e.preventDefault(); turn(1); }
    if (['ArrowLeft', 'PageUp'].includes(e.key)) { e.preventDefault(); turn(-1); }
  });
}

// 끄는 동안 글이 손가락을 따라오는 건 «밀기»·«종이책»일 때만 — «바로»면 글은 가만히 있다가 손을 떼면 다음 쪽이 바로 나온다
//   «종이책»: 처음 민 쪽으로 지금 쪽을 잡고(앞으로 = 오른쪽 끝 · 뒤로 = 왼쪽 끝), 손가락이 간 만큼 접혀 넘어간다
function dragTo(g) {
  const dx = g.dx;
  if (settings.anim === 'curl') {
    if (g.curl === undefined) g.curl = curlBegin(dx < 0 ? 1 : -1, g.y - $('#scr-reader').getBoundingClientRect().top);
    if (!g.curl) return;
    const W = $('#scr-reader').clientWidth;
    g.curl.t = clamp((g.curl.dir > 0 ? -dx : dx) / W, 0, 1);
    g.curl.fy = g.dy * 0.5;
    curl.pose(g.curl.t, g.curl.fy);
    return;
  }
  if (settings.anim !== 'slide') return;
  const base = -R.screen * R.spread * R.pitch;
  const edge = (R.screen === 0 && dx > 0) || (R.screen === R.screens - 1 && dx < 0);
  const flow = $('#rd-flow');
  flow.style.transition = 'none';
  flow.style.transform = `translateX(${base + (edge ? dx / 3 : dx)}px)`;
}

function dragEnd(g) {
  const c = g.curl;
  if (c && R.curl === c) {
    // 3할 넘게 넘겼거나 넘기는 쪽으로 휙 밀었으면 마저 넘기고, 아니면 제자리로 눕힌다
    const v = c.dir > 0 ? -g.vx : g.vx;
    const go = (c.t > 0.3 && v > -0.15) || (v > 0.3 && c.t > 0.03);
    curlRun(go ? 1 : 0, go ? 140 + 360 * (1 - c.t) : 120 + 260 * c.t, easeOut);
    return;
  }
  const dx = g.dx;
  const fast = Math.abs(dx) / Math.max(1, Date.now() - g.t) > 0.35;
  if (dx < -60 || (dx < -20 && fast)) turn(1);
  else if (dx > 60 || (dx > 20 && fast)) turn(-1);
  else setScreen(R.screen, true);
}

function tapAt(x, y) {
  curlFinish();
  if (R.menu) { showMenu(false); return; }
  if (!$('#note-pop').hidden) { hideNotePop(); return; }
  const hit = noteAt(x, y);
  if (hit) { notePop(hit, x, y); return; }
  const fixHit = fixAt(x, y);
  if (fixHit) { fixPop(fixHit, x, y); return; }
  const at = document.elementFromPoint(x, y);
  const lnk = at?.closest?.('.lnk');
  if (lnk) { followLink(lnk); return; }
  const r = $('#rd-view').getBoundingClientRect();
  const fx = (x - r.left) / r.width;
  // 목차 쪽의 장 → 그 장으로. 양옆 넘김 자리(점선·쪽 번호 쪽)는 장 이름 글자를 누를 때만 — 목차 쪽에서도 오른쪽을 누르면 다음 쪽
  const ti = at?.closest?.('.rd-toc-it');
  if (ti && (R.scroll || at.closest('.t') || (fx >= 0.3 && fx <= 0.7))) { goTarget(+ti.dataset.s, ti.dataset.frag); return; }
  if (R.scroll) {
    const fy = (y - r.top) / r.height;
    if (fy < 0.22) turn(-1);
    else if (fy > 0.78) turn(1);
    else showMenu(true);
    return;
  }
  if (fx < 0.3) turn(-1);
  else if (fx > 0.7) turn(1);
  else showMenu(true);
}

function followLink(a) {
  if (a.dataset.ext) {
    ask(`바깥 링크를 열까요?\n${a.dataset.ext}`, '열기').then((ok) => ok && window.open(a.dataset.ext, '_blank'));
    return;
  }
  const s = R.ep.spine.findIndex((sp) => sp.path === a.dataset.path);
  if (s >= 0) goTarget(s, a.dataset.frag);
}

function goTarget(s, frag) {
  const sec = R.sections[s];
  if (!sec) return;
  const el = frag ? sec.querySelector('#' + CSS.escape(frag)) : null;
  goPos(el ? posFromDom(el, 0) : { s, b: 0, o: 0 });
}

// ---------------- 종이책 넘김 ----------------
// 사용자 «진짜 종이책 넘기는 효과»(10-25) — 넘어가는 동안만 쪽 사본 둘을 본문 위에 겹친다(curl.js 가 자르고 뒤집는다).
//   흐름의 덩어리(장·목차 쪽)는 늘 새 단에서 시작하니, 그 쪽이 든 덩어리만 복사해도 쪽 나눔이 본문과 같다
//   사본은 다음 넘김에 다시 쓴다(같은 장 안이면 옮기기만) · 쪽을 새로 나누면(R.gen) 다시 만든다
let curl = null;
const easeOut = (k) => 1 - (1 - k) ** 3;
const easeInOut = (k) => (1 - Math.cos(Math.PI * k)) / 2;

function kidAt(c) {
  let i = 0;
  while (i + 1 < R.kids.length && R.kidCol[i + 1] <= c) i++;
  return i;
}

// 쪽 사본 하나(위 글 · 본문 · 아래 글 · 책갈피 리본) — screen 쪽을 보여 준다
function fillPage(slot, screen) {
  const c0 = screen * R.spread;
  const i = kidAt(c0);
  const j = kidAt(Math.min(c0 + R.spread - 1, R.columns - 1));
  let st = slot._st;
  if (!st || st.gen !== R.gen || st.i !== i || st.j !== j) {
    slot.innerHTML = '<div class="chd"><span></span><span></span></div><div class="cvw"></div><div class="cft"><span></span><span></span></div><div class="crib" hidden></div>';
    const fl = document.createElement('div');
    fl.className = 'bk rd-cflow';
    for (let k = i; k <= j; k++) fl.appendChild(R.kids[k].cloneNode(true));
    fl.firstElementChild.style.breakBefore = 'auto';   // 맨 앞 덩어리는 단 첫머리(목차 쪽의 «새 단에서» 가 빈 단을 만들지 않게)
    const m = $('#rd-flow').style;
    Object.assign(fl.style, { left: m.left, width: m.width, height: m.height, columnCount: m.columnCount, columnGap: m.columnGap });
    fl.style.setProperty('--ph', m.getPropertyValue('--ph'));
    slot.querySelector('.cvw').appendChild(fl);
    st = slot._st = { gen: R.gen, i, j, fl, pairs: R.kids.slice(i, j + 1).map((o, k) => [o, fl.children[k]]) };
  }
  st.fl.style.transform = `translateX(${-(c0 - R.kidCol[i]) * R.pitch}px)`;
  const inf = pageInfo(screen, posAtScreen(screen), screen >= R.screens - 1);
  const [hb, hc] = slot.firstElementChild.children;
  hb.textContent = bookTitle();
  hc.textContent = inf.chap;
  const [f1, f2] = slot.querySelector('.cft').children;
  f1.textContent = inf.fl;
  f2.textContent = inf.fr;
  slot.querySelector('.crib').hidden = !R.notes.some((n) => n.type === 'bm' && screenOf(n.a) === screen);
  return st.pairs;
}

// 형광펜·메모·고친 문장 같은 칠(CSS Highlight)을 사본에도 — 같은 자리의 글자 범위를 만들어 같은 묶음에 더하고, 다 넘기면 뺀다
function mirrorMarks(pairs) {
  const added = [];
  if (!window.CSS?.highlights) return added;
  const path = (root, node) => {
    const p = [];
    for (let n = node; n !== root; n = n.parentNode) p.push(Array.prototype.indexOf.call(n.parentNode.childNodes, n));
    return p.reverse();
  };
  const at = (root, p) => p.reduce((n, i) => n?.childNodes[i], root);
  const map = (node) => {
    for (const [o, c] of pairs) if (o.contains(node)) return at(c, path(o, node));
    return null;
  };
  CSS.highlights.forEach((hl) => {
    for (const rg of [...hl]) {
      const a = map(rg.startContainer);
      const b = a && map(rg.endContainer);
      if (!b) continue;
      try {
        const r2 = document.createRange();
        r2.setStart(a, rg.startOffset);
        r2.setEnd(b, rg.endOffset);
        hl.add(r2);
        added.push([hl, r2]);
      } catch {}
    }
  });
  return added;
}

// dir 쪽으로 넘기기 시작 — 넘길 쪽이 없으면 null · y = 손가락 높이(없으면 아래 귀퉁이를 잡는다)
function curlBegin(dir, y = null) {
  curlDone(false);
  if (R.scroll || !R.kids?.length) return null;
  const to = R.screen + dir;
  if (to < 0 || to >= R.screens) return null;
  curl ||= makeCurl($('#scr-reader'));
  const host = $('#scr-reader').getBoundingClientRect();
  const spread = R.spread === 2;
  // 한 쪽: 밑 = 넘겨 갈 쪽 · 뒷면 = 지금 쪽이 비친다(앞뒤 모두 지금 쪽이 들린다) · 두 쪽: 둘 다 넘겨 갈 펼침
  //   한 쪽 뒷면에 넘겨 갈 쪽을 읽히게 붙이면 반쯤 넘어간 뒤로 밑 쪽과 같은 글이 옆으로 겹쳐 보인다(10-26 비교) → 비침을 진하게
  const pairs = [...fillPage(curl.under, to), ...fillPage(curl.back, spread ? to : R.screen)];
  const t = readerTheme();
  const vr = $('#rd-view').getBoundingClientRect();
  curl.setup({
    W: host.width, H: host.height,
    kind: (spread ? 'spread-' : 'single-') + (dir > 0 ? 'fwd' : 'back'),
    sx: vr.left - host.left + R.left + R.cw + R.gap / 2,   // 두 쪽 사이 접는 선
    cy: y == null ? host.height : clamp(y, 0, host.height),
    lift: y == null ? 0.1 : 0.05,
    paper: paperBack(t), dark: t.dark,
  });
  R.curl = { dir, to, t: 0, fy: 0, goal: null, raf: 0, marks: mirrorMarks(pairs) };
  curl.pose(0, 0);
  curl.show(true);
  return R.curl;
}

// 장의 뒷면 색 — 밝은 배경은 살짝 어둡게, 어두운 배경은 살짝 밝게
function paperBack(t) {
  const c = parseInt(t.bg.slice(1), 16);
  const ch = [c >> 16, (c >> 8) & 255, c & 255].map((v) => Math.round(t.dark ? v + (255 - v) * 0.07 : v * 0.965));
  return `rgb(${ch.join(',')})`;
}

// goal 1 = 다 넘기기 · 0 = 제자리로
function curlRun(goal, ms, ease) {
  const c = R?.curl;
  if (!c) return;
  cancelAnimationFrame(c.raf);
  c.goal = goal;
  const t0 = c.t;
  const fy0 = c.fy;
  const s0 = performance.now();
  const tick = (now) => {
    if (R?.curl !== c) return;
    const k = Math.min(1, (now - s0) / ms);
    c.t = t0 + (goal - t0) * ease(k);
    c.fy = fy0 * (1 - k);
    curl.pose(c.t, c.fy);
    if (k < 1) c.raf = requestAnimationFrame(tick);
    else curlDone(goal === 1);
  };
  c.raf = requestAnimationFrame(tick);
}

function curlDone(ok) {
  const c = R?.curl;
  if (!c) return;
  cancelAnimationFrame(c.raf);
  R.curl = null;
  for (const [hl, rg] of c.marks) hl.delete(rg);
  if (ok) {
    setScreen(c.to, false);
    R.pos = posAtScreen(c.to);
    afterMove();
  }
  curl.show(false);
}

// 넘어가던 장(손을 뗀 뒤 움직이는 중)은 곧장 끝낸다 — 빨리 연달아 누를 때
function curlFinish() {
  if (R?.curl && R.curl.goal != null) curlDone(R.curl.goal === 1);
}

// ---------------- 밝기(화면을 누른 채 위아래로) ----------------
//   자동 밝기(보기 설정 · 껍데기 1.6부터)를 켜면 주변 빛을 따라가고, 끌기는 그 자동 밝기의 배수(2^brightAdj)를 바꾼다
//   — 밤엔 더 어둡게 맞춰 두면 낮에도 같은 비율로 따라간다 · 끄면 끌어서 정한 값(없으면 폰 밝기)
const autoBri = () => settings.brightAuto && bridge.canAutoBrightness();
function applyBrightness() {
  if (autoBri()) bridge.setAutoBrightness(true, 2 ** settings.brightAdj);
  else {
    bridge.setAutoBrightness(false);
    bridge.setBrightness(settings.brightness ?? -1);
  }
}

let briHideT = 0;
function briStart() {
  R.briAuto = autoBri();
  R.bri0 = R.briAuto ? settings.brightAdj : settings.brightness ?? bridge.getBrightness();
  R.briV = null;
  showBri(R.bri0);
}
function briMove(dy) {
  if (R.briAuto) {
    const a = clamp(R.bri0 - (dy / (R.H * 0.7)) * 5, -3, 2);
    R.briV = a;
    bridge.setAutoBrightness(true, 2 ** a);
    showBri(a);
    return;
  }
  const v = clamp(R.bri0 - dy / (R.H * 0.7), 0.02, 1);
  R.briV = v;
  bridge.setBrightness(v);
  showBri(v);
}
function briEnd() {
  if (R?.briV != null) setSetting(R.briAuto ? 'brightAdj' : 'brightness', Math.round(R.briV * 100) / 100);
  clearTimeout(briHideT);
  briHideT = setTimeout(() => { $('#rd-bri').hidden = true; }, 700);
}
// 자동이면 «자동 70%»(기본 자동 밝기의 70%) · 막대는 -3 ~ 2 가운데 자리
function showBri(v) {
  clearTimeout(briHideT);
  const el = $('#rd-bri');
  el.hidden = false;
  el.querySelector('i').style.width = Math.round(R.briAuto ? ((v + 3) / 5) * 100 : v * 100) + '%';
  el.querySelector('b').textContent = R.briAuto ? `자동 ${Math.round(2 ** v * 100)}%` : Math.round(v * 100) + '%';
}

// ---------------- 메뉴 ----------------
function showMenu(on) {
  if (!R) return;
  if (on === R.menu) return;
  R.menu = on;
  $('#rd-top').hidden = !on;
  $('#rd-bot').hidden = !on;
  if (on) {
    hideSelPop();
    hideNotePop();
    updateInfo();
    R.menuLayer = pushLayer(() => showMenu(false));
  } else {
    R.menuLayer?.();
    R.menuLayer = null;
    $('#rd-set').hidden = true;
    $$('#rd-nav button').forEach((b) => b.classList.remove('on'));
  }
  bridge.setImmersive(!on);
}

function toggleSettings() {
  const panel = $('#rd-set');
  panel.hidden = !panel.hidden;
  $('#rd-nav [data-a="set"]').classList.toggle('on', !panel.hidden);
  if (!panel.hidden) renderSettings();
}

function opt(key, value, label, cls = '') {
  return `<button class="opt${settings[key] === value ? ' on' : ''} ${cls}" data-k="${key}" data-v="${esc(JSON.stringify(value))}">${label}</button>`;
}
function stepper(key, label, fmt) {
  return `<div class="stp"><button class="b" data-step="${key}" data-d="-1" aria-label="${label} 줄이기">−</button><span class="v">${fmt(settings[key])}</span><button class="b" data-step="${key}" data-d="1" aria-label="${label} 늘리기">＋</button></div>`;
}
const STEPS = {
  fs: { min: 12, max: 32, step: 1, fmt: (v) => v },
  lh: { min: 1.3, max: 2.8, step: 0.1, fmt: (v) => v.toFixed(1) },
  pm: { min: 0, max: 2, step: 0.25, fmt: (v) => v.toFixed(2).replace(/0$/, '') },
};

function renderSettings() {
  const sw = Object.entries(READER_THEMES).map(([k, t]) => `<button class="sw${settings.theme === k ? ' on' : ''}" data-k="theme" data-v='"${k}"' style="background:${t.bg}" aria-label="${t.name}"></button>`).join('');
  $('#rd-set').innerHTML = `
    <div class="srow"><div class="k">글꼴</div>${Object.entries(FONTS).map(([k, f]) => opt('font', k, f.name, k)).join('')}</div>
    <div class="srow"><div class="k">글자 크기</div>${stepper('fs', '글자 크기', STEPS.fs.fmt)}</div>
    <div class="srow"><div class="k">줄 간격</div>${stepper('lh', '줄 간격', STEPS.lh.fmt)}</div>
    <div class="srow"><div class="k">여백</div>${opt('margin', 's', '좁게')}${opt('margin', 'm', '보통')}${opt('margin', 'l', '넓게')}</div>
    <div class="srow"><div class="k">배경</div><button class="sw auto${settings.theme === 'auto' ? ' on' : ''}" data-k="theme" data-v='"auto"' aria-label="자동">자동</button>${sw}</div>
    <div class="srow"><div class="k">넘기기</div>${opt('mode', 'page', '좌우로 넘기기')}${opt('mode', 'scroll', '위아래 스크롤')}</div>
    <div class="srow"><div class="k">그 밖</div><label class="chk"><input type="checkbox" data-k="keepOn"${settings.keepOn ? ' checked' : ''}><i></i>화면 꺼짐 방지</label><label class="chk"><input type="checkbox" data-k="nextVol"${settings.nextVol ? ' checked' : ''}><i></i>다음 권 이어서</label></div>
    <div class="srow"><div class="k">화면 회전</div>${opt('rotate', 'auto', '폰 따라')}${opt('rotate', 'portrait', '세로 고정')}${opt('rotate', 'landscape', '가로 고정')}${native && !bridge.canSetOrientation() ? '<span class="hint wrap">앱을 1.4 로 새로 깔면 돼요</span>' : ''}</div>
    <div class="srow more"><div class="k">두 쪽 보기</div>${opt('spread', 'auto', '펴면 자동')}${opt('spread', 'one', '늘 한 쪽')}</div>
    <div class="srow"><div class="k">넘김 효과</div>${opt('anim', 'none', '바로')}${opt('anim', 'curl', '종이책')}${opt('anim', 'slide', '밀기')}</div>
    <div class="srow"><div class="k">문단 간격</div>${stepper('pm', '문단 간격', STEPS.pm.fmt)}</div>
    <div class="srow"><div class="k">문단 모양</div><label class="chk"><input type="checkbox" data-k="indent"${settings.indent ? ' checked' : ''}><i></i>들여쓰기</label><label class="chk"><input type="checkbox" data-k="justify"${settings.justify ? ' checked' : ''}><i></i>양쪽 정렬</label></div>
    <div class="srow"><div class="k">볼륨키</div><label class="chk"><input type="checkbox" data-k="volKeys"${settings.volKeys ? ' checked' : ''}><i></i>볼륨키로 넘기기(아래 = 다음 쪽)</label></div>
    <div class="srow"><div class="k">밝기</div><label class="chk"><input type="checkbox" data-k="brightAuto"${settings.brightAuto ? ' checked' : ''}><i></i>자동 밝기</label>${settings.brightAuto ? (settings.brightAdj ? '<button class="opt" data-a="bri-reset">기본으로</button>' : '') : settings.brightness != null ? '<button class="opt" data-a="bri-reset">폰 밝기로</button>' : ''}<span class="hint wrap">${!settings.brightAuto ? '화면을 누른 채 위아래로 끌기' : native && !bridge.canAutoBrightness() ? '앱을 1.6 으로 새로 깔면 돼요' : '주변 빛을 따라가요 · 화면을 누른 채 끌면 더 밝게·어둡게'}</span></div>
    <div class="srow"><div class="k">앱 테마</div>${opt('appTheme', 'auto', '폰 따라')}${opt('appTheme', 'light', '밝게')}${opt('appTheme', 'dark', '어둡게')}</div>`;
}

function onSettingsClick(e) {
  const t = e.target.closest('button,input');
  if (!t) return;
  if (t.dataset.a === 'bri-reset') {   // 자동이면 배수를 기본으로 · 아니면 폰 밝기로
    setSetting(settings.brightAuto ? 'brightAdj' : 'brightness', settings.brightAuto ? 0 : null);
    applyBrightness();
    renderSettings();
    return;
  }
  if (t.dataset.step) {
    const k = t.dataset.step;
    const s = STEPS[k];
    setSetting(k, Math.round(clamp(settings[k] + s.step * +t.dataset.d, s.min, s.max) * 100) / 100);
    applied(k);
    return;
  }
  if (t.dataset.k && t.localName === 'button') {
    setSetting(t.dataset.k, JSON.parse(t.dataset.v));
    applied(t.dataset.k);
  }
}
function onSettingsChange(e) {
  const t = e.target;
  if (t.type === 'checkbox' && t.dataset.k) {
    setSetting(t.dataset.k, t.checked);
    applied(t.dataset.k);
  }
}

function applied(k) {
  if (['fs', 'lh', 'pm', 'indent', 'justify', 'font'].includes(k)) { applyTypo(); relayout(); }
  if (['margin', 'mode', 'spread'].includes(k)) relayout();
  if (k === 'theme') applyTheme();
  if (k === 'appTheme') { applyAppTheme(); applyTheme(); }
  if (k === 'keepOn') bridge.keepScreenOn(settings.keepOn);
  if (k === 'rotate') bridge.setOrientation(settings.rotate);
  if (k === 'brightAuto') applyBrightness();
  if (k === 'volKeys') bridge.setVolumeKeys(settings.volKeys);
  renderSettings();
}

// ---------------- 목차 ----------------
function tocList() {
  return R.ep.toc.length ? R.ep.toc : R.sections.map((sec, s) => ({ label: R.label[s] || `${s + 1}`, s, frag: '', depth: 0 })).filter((t, i, a) => t.label && (i === 0 || a[i - 1].label !== t.label));
}

// 책 안의 목차 쪽 — 사용자 «표지 다음 장에 목차, 누르면 그 장으로»(10-25). 첫 장 바로 앞(표지 다음)에 쪽으로 넣는다.
//   장(R.sections)이 아니라서 장 번호·문단 목록·찾기·듣기엔 안 들어가고, 쪽 번호는 쪽을 나눌 때마다 layout() 이 채운다
function addTocPage() {
  const list = tocList().filter((t) => R.sections[t.s] && !R.sections[t.s].classList.contains('imgonly'));
  if (list.length < 2 || ownTocPage()) return;
  const at = Math.min(...list.map((t) => t.s));
  const sec = document.createElement('section');
  sec.className = 'rd-toc';
  sec.innerHTML = '<div class="rd-toc-h">목차</div>' + list.map((t) => `<div class="rd-toc-it" data-s="${t.s}" data-frag="${esc(t.frag || '')}"${t.depth ? ` style="padding-left:${(t.depth * 1.2).toFixed(1)}em"` : ''}><span class="t">${esc(t.label)}</span><span class="d"></span><span class="n"></span></div>`).join('');
  R.sections[at].before(sec);
  R.tocS = at;
}

// 책에 목차 쪽이 이미 들어 있으면(앞쪽 장 하나가 거의 다 다른 장으로 가는 링크) 하나 더 넣지 않는다
function ownTocPage() {
  const bare = (s) => s.replace(/\s+/g, '').length;
  return R.sections.slice(0, 6).some((sec) => {
    const links = $$('.lnk[data-path]', sec);
    return new Set(links.map((a) => a.dataset.path)).size >= 3 && links.reduce((n, a) => n + bare(a.textContent), 0) > bare(sec.textContent) * 0.5;
  });
}

function openToc() {
  const toc = tocList();
  const cur = R.pos.toc ? -1 : R.pos.s;
  let curIdx = -1;
  toc.forEach((t, i) => { if (t.s <= cur) curIdx = i; });
  const s = sheet({
    title: '목차', cls: 'tall',
    body: `<div class="toc">${toc.map((t, i) => `<button class="toc-it${i === curIdx ? ' cur' : ''}" data-i="${i}" style="padding-left:${16 + t.depth * 16}px">${esc(t.label)}</button>`).join('')}</div>`,
  });
  s.body.onclick = (e) => {
    const b = e.target.closest('.toc-it');
    if (!b) return;
    const t = toc[+b.dataset.i];
    s.close();
    showMenu(false);
    goTarget(t.s, t.frag);
  };
  s.body.querySelector('.cur')?.scrollIntoView({ block: 'center' });
}

// ---------------- 검색 ----------------
function openSearch(q0 = '') {
  const s = sheet({
    title: '책 안에서 찾기', cls: 'tall',
    body: '<div class="sbox"><input id="rd-q" type="search" placeholder="찾을 말" enterkeyhint="search"></div><div class="sres" id="rd-sres"></div>',
  });
  const input = s.body.querySelector('#rd-q');
  const res = s.body.querySelector('#rd-sres');
  let hits = [];
  const run = () => {
    const q = input.value.trim();
    hits = [];
    if (!q) { res.innerHTML = ''; return; }
    const ql = q.toLowerCase();
    for (const el of R.blocks) {
      const t = el.textContent;
      const tl = t.toLowerCase();
      let i = tl.indexOf(ql);
      while (i >= 0 && hits.length < 500) {
        hits.push({ el, o: i, len: q.length, t });
        i = tl.indexOf(ql, i + ql.length);
      }
      if (hits.length >= 500) break;
    }
    res.innerHTML = `<div class="sres-n">${hits.length >= 500 ? '500곳 넘게' : hits.length + '곳'}</div>` + hits.map((h, i) => {
      const info = R.info.get(h.el);
      const a = Math.max(0, h.o - 24);
      return `<button class="sres-it" data-i="${i}"><span class="c">${esc(R.label[info.s] || '')}</span>${a > 0 ? '…' : ''}${esc(h.t.slice(a, h.o))}<b>${esc(h.t.slice(h.o, h.o + h.len))}</b>${esc(h.t.slice(h.o + h.len, h.o + h.len + 40))}…</button>`;
    }).join('');
  };
  let t = 0;
  input.oninput = () => { clearTimeout(t); t = setTimeout(run, 200); };
  input.onkeydown = (e) => { if (e.key === 'Enter') { clearTimeout(t); run(); input.blur(); } };
  res.onclick = (e) => {
    const b = e.target.closest('.sres-it');
    if (!b) return;
    const h = hits[+b.dataset.i];
    const info = R.info.get(h.el);
    s.close();
    showMenu(false);
    const [n1, o1] = locate(h.el, h.o);
    const [n2, o2] = locate(h.el, h.o + h.len);
    const rg = document.createRange();
    rg.setStart(n1, o1);
    rg.setEnd(n2, o2);
    goPos({ s: info.s, b: info.b, o: h.o }, { flash: rg });
  };
  input.value = q0;
  if (q0) run();
  setTimeout(() => input.focus(), 250);
}

function flashRange(rg) {
  if (!window.CSS?.highlights) return;
  CSS.highlights.set('search', new Highlight(rg));
  R.searchHit = rg;
  R.searchHitAt = R.screen;
}

// ---------------- 형광펜·메모·제보·책갈피 ----------------
function rangeOfNote(n) {
  const ea = blockAt(n.a);
  const eb = blockAt(n.b);
  if (!ea || !eb) return null;
  const mk = (a, ao, b, bo) => {
    const [sn, so] = locate(a, ao);
    const [en, eo] = locate(b, bo);
    const rg = document.createRange();
    rg.setStart(sn, so);
    rg.setEnd(en, eo);
    return rg;
  };
  const rg = mk(ea, n.a.o, eb, n.b.o);
  const norm = (s) => s.replace(/\s+/g, '');
  if (!n.text || norm(rg.toString()) === norm(n.text)) return rg;
  // 새 판에서 문장이 조금 움직였으면 같은 문단에서 인용문을 다시 찾는다
  if (ea === eb) {
    const i = ea.textContent.indexOf(n.text);
    if (i >= 0) return mk(ea, i, ea, i + n.text.length);
  }
  return rg;
}

function paintNotes() {
  if (!R || !window.CSS?.highlights) return;
  const groups = { 'hl-y': [], 'hl-g': [], 'hl-b': [], 'hl-p': [], memo: [], report: [] };
  R.ranges = new Map();
  for (const n of R.notes) {
    if (n.type === 'bm') continue;
    const rg = rangeOfNote(n);
    if (!rg) continue;
    R.ranges.set(n.id, rg);
    groups[n.type === 'hl' ? 'hl-' + (n.color || 'y') : n.type]?.push(rg);
  }
  for (const [k, list] of Object.entries(groups)) CSS.highlights.set(k, new Highlight(...list));
  updateRibbon();
}

function noteAt(x, y) {
  const c = document.caretRangeFromPoint?.(x, y);
  if (!c) return null;
  for (const n of [...R.notes].reverse()) {
    const rg = R.ranges.get(n.id);
    try { if (rg && rg.comparePoint(c.startContainer, c.startOffset) === 0) return n; } catch {}
  }
  return null;
}

async function addNote(n) {
  n.id = Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  n.bookId = R.id;
  n.at = Date.now();
  n.chap = chapOf(n.a);
  n.vol = bookTitle();
  await db.put('notes', n);
  R.notes.push(n);
  paintNotes();
  return n;
}

async function updateNote(n) {
  await db.put('notes', n);
  paintNotes();
}

async function deleteNote(n) {
  await db.del('notes', n.id);
  R.notes = R.notes.filter((x) => x.id !== n.id);
  paintNotes();
}

// 제보에는 고른 말이 든 문장 전체와 앞뒤 문장을 붙인다 — 짧은 말(«네.»)만 골라도 번역기 쪽에서 문단을 바로 찾게(10-25 번역기 세션 부탁)
const SENT_END = /[.!?…]+[”’」』"')\]]*(?=\s|$)/g;
function sentenceRanges(t) {
  const out = [];
  let s = 0;
  for (const m of t.matchAll(SENT_END)) {
    const e = m.index + m[0].length;
    if (e > s) out.push([s, e]);
    s = e;
    while (s < t.length && /\s/.test(t[s])) s++;
  }
  if (s < t.length) out.push([s, t.length]);
  return out.length ? out : [[0, t.length]];
}

function reportContext(a, b) {
  const ea = blockAt(a);
  const eb = blockAt(b);
  if (!ea || !eb) return null;
  const ta = ea.textContent;
  const tb = eb.textContent;
  const ra = sentenceRanges(ta);
  const rb = sentenceRanges(tb);
  const ia = Math.max(0, ra.findIndex(([, e]) => a.o < e));
  let ib = rb.findIndex(([, e]) => Math.max(0, b.o - 1) < e);
  if (ib < 0) ib = rb.length - 1;
  let sent;
  if (ea === eb) sent = ta.slice(ra[ia][0], rb[Math.max(ib, ia)][1]);
  else {
    const g1 = R.info.get(ea).g;
    const g2 = R.info.get(eb).g;
    const parts = [ta.slice(ra[ia][0])];
    for (let g = g1 + 1; g < g2; g++) parts.push(R.blocks[g].textContent);
    parts.push(tb.slice(0, rb[ib][1]));
    sent = parts.join('\n');
  }
  // 앞뒤 문장: 같은 문단에서, 없으면 같은 장의 이웃 문단에서
  const near = (el, step) => {
    const list = R.tb;
    const i = list.indexOf(el) + step;
    const n = list[i];
    return n && R.info.get(n).s === R.info.get(el).s ? n : null;
  };
  const one = (el, last) => {
    if (!el) return '';
    const t = el.textContent;
    const r = sentenceRanges(t);
    const [s, e] = last ? r[r.length - 1] : r[0];
    return t.slice(s, e);
  };
  const prev = ia > 0 ? ta.slice(ra[ia - 1][0], ra[ia - 1][1]) : one(near(ea, -1), true);
  const next = ib < rb.length - 1 ? tb.slice(rb[ib + 1][0], rb[ib + 1][1]) : one(near(eb, 1), false);
  const clean = (s) => s.replace(/[ \t]+/g, ' ').trim();
  return { sent: clean(sent), prev: clean(prev), next: clean(next) };
}

// 안 보낸 제보를 우편함으로 → 지금 연 책의 메모 목록에도 «보냄» 표시
async function sendToInbox() {
  const r = await sendNow();
  if (r?.ids && R) for (const n of R.notes) if (r.ids.includes(n.id)) n.sentAt = r.at;
  if (!r && R && inboxConf()) toast('제보는 담아 뒀어요 · 인터넷이 되면 다시 보내요', 3500);
}

function editNote(n, isNew) {
  const kind = n.type === 'report' ? '제보' : '메모';
  const quote = n.type === 'report' && n.ctx?.sent
    ? `${markQuote(n.ctx.sent, n.text)}<div class="qhint">앞뒤 문장도 같이 담겨요</div>`
    : esc(n.text);
  const s = sheet({
    title: isNew ? `${kind} 남기기` : `${kind} 고치기`,
    body: `<div class="quote">${quote}</div>
      <textarea id="nt-text" rows="4" placeholder="${n.type === 'report' ? '어떻게 고치면 좋을지 적어 주세요(비워 둬도 돼요)' : '메모'}">${esc(n.note || '')}</textarea>
      <div class="sheet-btns">${isNew ? '' : '<button class="btn ghost danger-t" data-a="del">지우기</button>'}<span class="sp"></span><button class="btn" data-a="save">저장</button></div>`,
  });
  const ta = s.body.querySelector('#nt-text');
  setTimeout(() => ta.focus(), 250);
  s.body.onclick = async (e) => {
    const a = e.target.closest('[data-a]')?.dataset.a;
    if (a === 'save') {
      n.note = ta.value.trim();
      if (n.type === 'report' && !isNew) delete n.sentAt;  // 고친 제보는 다시 보낸다
      if (isNew) await addNote(n);
      else await updateNote(n);
      s.close();
      if (n.type === 'report' && inboxConf()) sendToInbox();  // 우편함이 이어져 있으면 바로 번역기로
      else toast(n.type === 'report' ? '제보에 담았어요' : '메모를 남겼어요');
    } else if (a === 'del') {
      await deleteNote(n);
      s.close();
    }
  };
}

// 고른 글 위에 뜨는 단추
let selT = 0;
function onSelectionChange() {
  clearTimeout(selT);
  selT = setTimeout(() => {
    if (!R || R.menu) return;
    const s = document.getSelection();
    if (!s.rangeCount || s.isCollapsed) { hideSelPop(); return; }
    const rg = s.getRangeAt(0);
    if (!$('#rd-flow').contains(rg.commonAncestorContainer)) { hideSelPop(); return; }
    R.sel = rg.cloneRange();
    placePop($('#sel-pop'), rg.getClientRects());
  }, 160);
}

function placePop(pop, rects) {
  if (!rects.length) return;
  const first = rects[0];
  const last = rects[rects.length - 1];
  pop.hidden = false;
  const pw = pop.offsetWidth;
  const ph = pop.offsetHeight;
  const top0 = $('#rd-view').getBoundingClientRect().top;
  let y = first.top - ph - 12;
  if (y < top0) y = last.bottom + 34;
  pop.style.left = clamp(first.left, 8, innerWidth - pw - 8) + 'px';
  pop.style.top = clamp(y, 8, innerHeight - ph - 8) + 'px';
}

function hideSelPop() { $('#sel-pop').hidden = true; if (R) R.sel = null; }

async function onSelAction(act) {
  const rg = R?.sel;
  if (!rg) return;
  const text = rg.toString().replace(/\s+/g, ' ').trim();
  const a = posFromDom(rg.startContainer, rg.startOffset);
  const b = posFromDom(rg.endContainer, rg.endOffset);
  document.getSelection().removeAllRanges();
  hideSelPop();
  if (!text) return;
  if (act.startsWith('hl-')) await addNote({ type: 'hl', color: act.slice(3), a, b, text });
  else if (act === 'memo') editNote({ type: act, a, b, text, note: '' }, true);
  else if (act === 'report') editNote({ type: act, a, b, text, note: '', ctx: reportContext(a, b) }, true);
  else if (act === 'copy') { bridge.copy(text); toast('복사했어요'); }
  else if (act === 'search') openSearch(text);
}

// 칠해 둔 곳을 누르면
function notePop(n, x, y) {
  const pop = $('#note-pop');
  const colors = n.type === 'hl' ? HL_COLORS.map((c) => `<button class="dot c-${c}${n.color === c ? ' on' : ''}" data-c="${c}" aria-label="색"></button>`).join('') : '';
  pop.innerHTML = `${n.note ? `<div class="pn">${esc(n.note)}</div>` : ''}<div class="pb-row">${colors}
    ${n.type === 'hl' ? '<button data-a="memo">메모</button>' : `<button data-a="edit">${n.type === 'report' ? '제보 고치기' : '메모 고치기'}</button>`}
    <button data-a="copy">복사</button><button data-a="del" class="danger-t">지우기</button></div>`;
  R.popNote = n;
  R.popFix = null;
  const rg = R.ranges.get(n.id);
  placePop(pop, rg ? rg.getClientRects() : [{ left: x, top: y, bottom: y }]);
}
function hideNotePop() { const p = $('#note-pop'); if (p) p.hidden = true; }

async function onNotePop(e) {
  const n = R?.popNote;
  if (!n) {   // 고친 문장 해설은 누르면 닫힘 — «답글 달기»만 받는다
    const fix = R?.popFix;
    hideNotePop();
    if (fix && e.target.closest('[data-a="comment"]')) commentSheet(fix);
    return;
  }
  const c = e.target.closest('[data-c]')?.dataset.c;
  const a = e.target.closest('[data-a]')?.dataset.a;
  if (c) { n.color = c; await updateNote(n); hideNotePop(); return; }
  hideNotePop();
  if (a === 'memo') { n.type = 'memo'; editNote(n, false); }
  else if (a === 'edit') editNote(n, false);
  else if (a === 'copy') { bridge.copy(n.text); toast('복사했어요'); }
  else if (a === 'del') deleteNote(n);
}

// 책갈피: 이 쪽에 있으면 빼고, 없으면 꽂는다
function bmHere() {
  return R.notes.filter((n) => n.type === 'bm').find((n) => (R.scroll ? onScrollScreen(n.a) : screenOf(n.a) === R.screen));
}
function onScrollScreen(pos) {
  const r = rectOfPos(pos);
  const v = $('#rd-view').getBoundingClientRect();
  return r && r.top >= v.top - 2 && r.top < v.bottom;
}
async function toggleBookmark() {
  const here = bmHere();
  if (here) { await deleteNote(here); toast('책갈피를 뺐어요'); return; }
  const el = R.pos.toc ? null : blockAt(R.pos);
  const text = el ? el.textContent.slice(R.pos.o, R.pos.o + 60).trim() : R.pos.toc ? '목차' : '';
  await addNote({ type: 'bm', a: { ...R.pos }, b: { ...R.pos }, text });
  toast('책갈피를 꽂았어요');
}
function updateRibbon() {
  if (!R) return;
  const on = !!bmHere();
  $('#rd-ribbon').hidden = !on;
  $('#rd-bm').classList.toggle('on', on);
}

async function openNotes(tab = 'hl') {
  const results = await resultsByReport(R.notes);
  const s = sheet({ title: '메모·제보', cls: 'tall' });
  const draw = () => {
    const by = (t) => R.notes.filter((n) => n.type === t).sort(byPos);
    const tabs = Object.entries(NOTE_KINDS).map(([k, name]) => `<button class="tab${tab === k ? ' on' : ''}" data-tab="${k}">${name} ${by(k).length}</button>`).join('');
    const list = by(tab);
    const tools = tab === 'report' && list.length ? reportTools(list) : '';
    s.body.innerHTML = `<div class="tabs">${tabs}</div>${tools}${list.length ? list.map((n) => `<div class="note-it" data-id="${n.id}">
        ${n.type === 'hl' ? `<span class="dot c-${n.color || 'y'}"></span>` : ''}<div class="q">${n.ctx?.sent ? markQuote(n.ctx.sent, n.text) : esc(n.text || '')}</div>
        ${n.note ? `<div class="nt">→ ${esc(n.note)}</div>` : ''}
        <div class="meta">${esc(chapOf(n.a))} · ${fmtDate(n.at)}${n.type === 'report' ? resultChip(n, results.get(n.id)) : ''}<button class="ib sm" data-a="del" aria-label="지우기">${icon('trash')}</button></div></div>`).join('')
      : `<div class="empty-note">${tab === 'bm' ? '위 막대의 책갈피 단추로 이 쪽을 꽂아 두세요.' : '문장을 꾹 눌러 고른 뒤 위에 뜨는 단추를 누르세요.'}</div>`}`;
  };
  draw();
  s.body.onclick = async (e) => {
    const tb = e.target.closest('[data-tab]');
    if (tb) { tab = tb.dataset.tab; draw(); return; }
    const a = e.target.closest('[data-a]')?.dataset.a;
    const it = e.target.closest('.note-it');
    const reps = R.notes.filter((n) => n.type === 'report');
    if (a === 'inbox') {
      await sendToInbox();
      draw();
    } else if (a === 'send' || a === 'copy' || a === 'save') {
      const text = reportText(reps, new Map([[R.id, R.book]]));
      if (a === 'send') bridge.share(text, '제보 보내기');
      else if (a === 'copy') { bridge.copy(text); toast('복사했어요'); }
      else bridge.saveText(`제보-${new Date().toISOString().slice(0, 10)}.txt`, text);
    } else if (a === 'clear') {
      if (await ask(`이 책의 제보 ${reps.length}건을 모두 지울까요?`, '모두 지우기', { danger: true })) {
        for (const n of reps) await db.del('notes', n.id);
        R.notes = R.notes.filter((n) => n.type !== 'report');
        paintNotes();
        toast('제보를 모두 지웠어요');
        draw();
      }
    } else if (a === 'del' && it) {
      const n = R.notes.find((x) => x.id === it.dataset.id);
      if (n) { await deleteNote(n); draw(); }
    } else if (it) {
      const n = R.notes.find((x) => x.id === it.dataset.id);
      s.close();
      showMenu(false);
      if (n) goPos(n.a);
    }
  };
}

// ---------------- 듣기(TTS) ----------------
function ttsStart() {
  if (!bridge.ttsAvailable()) { toast('이 기기에선 듣기를 쓸 수 없어요'); return; }
  showMenu(false);
  const el = blockAt(R.pos);
  R.tts = { g: el ? R.info.get(el).g : 0, on: true, id: 0 };
  $('#rd-tts').hidden = false;
  ttsSay();
}
function ttsSay() {
  const T = R?.tts;
  if (!T?.on) return;
  while (T.g < R.blocks.length && !R.blocks[T.g].textContent.trim()) T.g++;
  if (T.g >= R.blocks.length) { ttsStop(); toast('이 권을 끝까지 읽었어요'); return; }
  const el = R.blocks[T.g];
  const info = R.info.get(el);
  const rg = document.createRange();
  rg.selectNodeContents(el);
  CSS.highlights?.set('tts', new Highlight(rg));
  const pos = { s: info.s, b: info.b, o: 0 };
  if (R.scroll) { el.scrollIntoView({ block: 'center', behavior: 'smooth' }); R.pos = pos; afterMove(); }
  else {
    const r = el.getClientRects();
    const last = r[r.length - 1];
    const sc = last ? Math.floor(colOf(r[0].left) / R.spread) : R.screen;
    if (sc !== R.screen) { setScreen(sc, true); R.pos = posAtScreen(sc); afterMove(); }
  }
  T.id++;
  bridge.ttsSpeak(el.textContent.replace(/\s+/g, ' ').trim(), T.id, settings.ttsRate);
}
window.onTtsDone = (id) => {
  if (R?.tts?.on && String(R.tts.id) === String(id)) { R.tts.g++; ttsSay(); }
};
function ttsStop() {
  if (R?.tts) R.tts.on = false;
  bridge.ttsStop();
  CSS.highlights?.delete('tts');
  $('#rd-tts').hidden = true;
}

// ---------------- 바깥에서 부르는 것 ----------------
export function handleBack() {
  if (!R) return false;
  if (R.tts?.on) { ttsStop(); return true; }
  if (!document.getSelection().isCollapsed) { document.getSelection().removeAllRanges(); hideSelPop(); return true; }
  if (!$('#note-pop').hidden) { hideNotePop(); return true; }
  return false;
}

export function onAppPause() { if (R) saveProgress(); }
export function onAppResume() { if (R) enterReaderMode(); }
export function onThemeChange() { if (R) applyTheme(); }

export function initReader(hooks) {
  H = hooks;
  bindGestures();
  // 폴드를 펴고 접거나 돌리면 크기가 바뀐다 → 같은 문장으로 다시 나눈다
  new ResizeObserver(() => R && relayout()).observe($('#rd-view'));
  addEventListener('resize', () => R && relayout());
  $('#rd-view').addEventListener('scroll', () => {
    if (!R?.scroll) return;
    clearTimeout(R.scrollT);
    R.scrollT = setTimeout(() => { R.pos = posAtScroll(); afterMove(); }, 120);
  }, { passive: true });
  document.addEventListener('selectionchange', onSelectionChange);
  $('#sel-pop').addEventListener('click', (e) => { const b = e.target.closest('[data-act]'); if (b) onSelAction(b.dataset.act); });
  $('#sel-pop').addEventListener('mousedown', (e) => e.preventDefault());
  $('#note-pop').addEventListener('click', onNotePop);
  $('#rd-back').onclick = () => H.close();
  $('#rd-search').onclick = () => openSearch();
  $('#rd-bm').onclick = toggleBookmark;
  $('#rd-set').addEventListener('click', onSettingsClick);
  $('#rd-set').addEventListener('change', onSettingsChange);
  $('#rd-nav').onclick = (e) => {
    const a = e.target.closest('[data-a]')?.dataset.a;
    if (a === 'toc') openToc();
    else if (a === 'set') toggleSettings();
    else if (a === 'bm') openNotes('bm');
    else if (a === 'notes') openNotes('hl');
    else if (a === 'tts') ttsStart();
  };
  const sl = $('#rd-slider');
  sl.oninput = () => {
    if (!R || R.scroll) return;
    $('#rd-ppage').innerHTML = `<b>${+sl.value + 1}</b> / ${R.screens}쪽`;
  };
  sl.onchange = () => {
    if (!R) return;
    if (R.scroll) {
      const v = $('#rd-view');
      v.scrollTop = (v.scrollHeight - v.clientHeight) * (+sl.value / 1000);
      return;
    }
    setScreen(+sl.value, false);
    R.pos = posAtScreen(R.screen);
    afterMove();
  };
  $('#rd-tts').onclick = ttsStop;
  window.onVolumeKey = (k) => { if (R && !R.menu) turn(k === 'down' ? 1 : -1); };
  window.onTtsError = () => { ttsStop(); toast('이 폰의 TTS(소리 내어 읽기)를 쓸 수 없어요'); };
  // 메모·검색 칸에서는 붙여넣기 같은 기본 메뉴가 필요하다
  document.addEventListener('focusin', (e) => { if (R && e.target.closest('input,textarea')) bridge.setNativeSelection(true); });
  document.addEventListener('focusout', (e) => { if (R && e.target.closest('input,textarea')) bridge.setNativeSelection(false); });
}
