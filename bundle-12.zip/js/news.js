// 번역기 소식 — 결과 쪽지(고침·그대로 둠·질문)를 보여 주고, 질문엔 앱에서 바로 답한다
//   서재 종의 빨간 숫자 = 아직 안 본 고침·그대로 둠 + 답 안 한 질문
import { db } from './db.js';
import { $, esc, toast, sheet, fmtDate } from './ui.js';
import { volName } from './books.js';
import { sendAnswer, explain } from './reports.js';

const FIX_DAYS = 30;   // 새 판의 고친 문장 표시(초록 점선)는 30일 동안
const recent = (it) => Date.now() - Date.parse(it.at || 0) < FIX_DAYS * 864e5;
const pending = (it) => (it.status === 'question' ? !it.answered : !it.read);

export async function allNews() {
  return (await db.all('news')).sort((a, b) => String(b.at).localeCompare(String(a.at)));
}

export async function renderNewsBadge() {
  const n = (await allNews()).filter(pending).length;
  const em = $('#lib-news em');
  em.textContent = n > 99 ? '99+' : String(n);
  em.hidden = !n;
}

// 읽기 화면에 표시할 고친 문장(이 권 · 30일 안)
export async function fixesFor(book) {
  const v = volName(book);
  return (await allNews()).filter((it) => it.status === 'fixed' && it.vol === v && it.after && recent(it));
}

// 권 목록의 «고친 곳 N» — 권 이름 → 수
export async function fixCounts() {
  const m = new Map();
  for (const it of await allNews()) {
    if (it.status === 'fixed' && recent(it)) m.set(it.vol, (m.get(it.vol) || 0) + 1 + (it.also || 0));
  }
  return m;
}

// 쪽지 ↔ 내 제보: id 가 없는 쪽지(화면 판 10 전에 보낸 제보)는 문장으로 맞춘다 — 쪽지 before ⊇ 제보 문장
const flat = (s) => String(s || '').replace(/\s+/g, '');
export function matchesReport(it, n) {
  if (it.report) return it.report === n.id;
  if (n.type !== 'report' || (n.vol && it.vol && n.vol !== it.vol)) return false;
  const a = flat(it.before || it.after);
  const b = flat(n.ctx?.sent || n.text);
  return a.length >= 4 && b.length >= 4 && (a.includes(b) || b.includes(a));
}

// 제보 목록의 결과 칩 — 제보 id → 쪽지
export async function resultsByReport(notes = []) {
  const items = await allNews();
  const m = new Map();
  for (const it of items) if (it.report && !m.has(it.report)) m.set(it.report, it);
  const loose = items.filter((it) => !it.report);
  for (const n of notes) {
    if (n.type !== 'report' || m.has(n.id)) continue;
    const hit = loose.find((it) => matchesReport(it, n));
    if (hit) m.set(n.id, hit);
  }
  return m;
}

export function resultChip(n, res) {
  if (res?.status === 'fixed') return '<span class="rchip c-ok">고침 ✓</span>';
  if (res?.status === 'kept') return `<span class="rchip c-keep">그대로 둠${res.why ? ' · ' + esc(res.why.slice(0, 24)) : ''}</span>`;
  if (res?.status === 'question') return res.answered ? '<span class="rchip c-keep">답함</span>' : '<span class="rchip c-q">질문 있음</span>';
  if (n.sentAt) return '<span class="rchip c-wait">보냄 · 처리 기다림</span>';
  return '';
}

function card(it, books) {
  const loc = `${esc(it.vol)}${it.chap ? ' · ' + esc(it.chap) : ''}`;
  const date = `<span class="nd">${fmtDate(Date.parse(it.at))}</span>`;
  if (it.status === 'question') {
    const done = it.answered;
    return `<div class="ncard q${done ? ' done' : ''}" data-id="${esc(it.id)}">
      <div class="loc">${loc} ${date}</div>
      ${it.before ? `<div class="qt">${esc(it.before)}</div>` : ''}
      <div class="ask">${esc(it.question)}</div>
      ${done ? `<div class="ans">답함: ${esc([done.choice, done.text].filter(Boolean).join(' / '))}</div>`
        : `<div class="btns">${(it.choices || []).map((c, i) => `<button class="nb${i === 0 ? ' p' : ''}" data-a="choice" data-i="${i}">${esc(c)}</button>`).join('')}<button class="nb" data-a="write">직접 쓰기</button></div>`}
    </div>`;
  }
  const mine = (it.report ? books.mine.has(it.report) : books.reps?.some((n) => matchesReport(it, n))) ? ' · 내 제보' : '';
  if (it.status === 'fixed') {
    return `<div class="ncard" data-id="${esc(it.id)}">
      <div class="loc">${loc}${it.also ? ` · 같은 병 ${it.also}곳 더` : ''}${mine} ${date}</div>
      ${it.before ? `<div class="del">${esc(it.before)}</div>` : ''}
      <div class="aft">${esc(it.after)}</div>
      ${it.why ? `<div class="why">왜: ${esc(it.why)}</div>` : ''}
      ${books.byVol.has(it.vol) ? '<button class="go" data-a="go">읽기 화면에서 보기 ›</button>' : ''}
    </div>`;
  }
  return `<div class="ncard" data-id="${esc(it.id)}">
    <div class="loc">${loc} · 그대로 둠${mine} ${date}</div>
    ${it.before || it.after ? `<div class="qt">${esc(it.after || it.before)}</div>` : ''}
    ${it.why ? `<div class="why">왜: ${esc(it.why)}</div>` : ''}
  </div>`;
}

export function openNews(hooks) {
  const s = sheet({ title: '번역기 소식', cls: 'tall' });
  let list = [];
  let books = { byVol: new Map(), mine: new Set() };
  const draw = async () => {
    list = await allNews();
    const [bs, notes] = await Promise.all([db.all('books'), db.all('notes')]);
    const reps = notes.filter((n) => n.type === 'report');
    books = { byVol: new Map(bs.map((b) => [volName(b), b])), mine: new Set(reps.map((n) => n.id)), reps };
    if (!list.length) {
      s.body.innerHTML = '<div class="empty-note">아직 번역기 소식이 없어요.<br>제보를 처리하면 고친 곳과 물어볼 것이 여기 와요.</div>';
      return;
    }
    const qs = list.filter((it) => it.status === 'question' && !it.answered);
    const fixed = list.filter((it) => it.status === 'fixed');
    const kept = list.filter((it) => it.status === 'kept');
    const answered = list.filter((it) => it.status === 'question' && it.answered);
    const sec = (title, items) => (items.length ? `<div class="nsec">${title} ${items.length}</div>${items.map((it) => card(it, books)).join('')}` : '');
    s.body.innerHTML = sec('물어볼 것', qs) + sec('고친 곳', fixed) + sec('그대로 둔 것', kept) + sec('답한 질문', answered);
  };
  const markRead = async () => {
    for (const it of list) if (it.status !== 'question' && !it.read) { it.read = true; await db.put('news', it); }
    renderNewsBadge();
  };
  draw().then(markRead);
  s.body.onclick = async (e) => {
    const btn = e.target.closest('[data-a]');
    const el = e.target.closest('.ncard');
    if (!btn || !el) return;
    const it = list.find((x) => x.id === el.dataset.id);
    if (!it) return;
    const a = btn.dataset.a;
    if (a === 'go') {
      const b = books.byVol.get(it.vol);
      s.close();
      if (b) hooks.openBook(b.id, { findText: it.after, findChap: it.chap || '' });
    } else if (a === 'choice' || a === 'send') {
      const choice = a === 'choice' ? it.choices[+btn.dataset.i] : null;
      const text = a === 'send' ? el.querySelector('textarea')?.value.trim() : '';
      if (a === 'send' && !text) { toast('답을 적어 주세요'); return; }
      btn.disabled = true;
      try {
        await sendAnswer(it, choice, text);
        toast('번역기로 답을 보냈어요', 3000);
        await draw();
        renderNewsBadge();
      } catch (err) {
        btn.disabled = false;
        toast(explain(err), 3500);
      }
    } else if (a === 'write') {
      const box = el.querySelector('.btns');
      box.outerHTML = `<textarea rows="3" placeholder="번역기에 보낼 답"></textarea><div class="btns"><button class="nb p" data-a="send">보내기</button></div>`;
      el.querySelector('textarea').focus();
    }
  };
}
