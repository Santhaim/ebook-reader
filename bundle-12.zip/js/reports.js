// 번역기와 주고받는 우편함 — 비공개 GitHub 저장소(기본 Santhaim/ebook-reports)
//   제보: 앱이 main 가지 inbox/ 에 올리고, PC 번역기 세션이 ebook-reader/tools/fetch_reports.py 로 가져가 지운다.
//   고친 권: PC 가 ebook-reader/tools/push_books.py 로 books 가지에 올리고(늘 최신 판만), 앱이 열 때 바뀐 권만 받는다.
//   열쇠(fine-grained 토큰 · 이 저장소 Contents 읽기/쓰기만)는 사용자가 앱에 직접 붙여 넣는다 — 이 폰 안에만 저장.
import { db } from './db.js';
import { volName, reportText } from './books.js';
import { bridge } from './native.js';
import { importFiles } from './importer.js';

const KEY = 'ebook.reports.v1';
const API = 'https://api.github.com';
export const DEFAULT_REPO = 'Santhaim/ebook-reports';

export function inboxConf() {
  try { return JSON.parse(localStorage.getItem(KEY) || 'null'); } catch { return null; }
}
export function saveInbox(conf) { localStorage.setItem(KEY, JSON.stringify(conf)); }
export function clearInbox() { localStorage.removeItem(KEY); }

// 폰 이름: 사용자 에이전트의 모델 번호(SM-S948N = S26 울트라 · SM-F946N = 폴드5)
export function deviceName() {
  const m = navigator.userAgent.match(/;\s*(SM-[A-Z0-9]+)/);
  return m ? m[1] : 'phone';
}

async function gh(conf, method, path, body) {
  const r = await fetch(`${API}/repos/${conf.repo}/${path}`, {
    method,
    headers: {
      Authorization: `Bearer ${conf.token}`,
      Accept: 'application/vnd.github+json',
      'X-GitHub-Api-Version': '2022-11-28',
      ...(body ? { 'Content-Type': 'application/json' } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  if (!r.ok) {
    const e = new Error(`${r.status}`);
    e.status = r.status;
    throw e;
  }
  return r.status === 204 ? null : r.json();
}

const b64 = (s) => {
  let bin = '';
  for (const x of new TextEncoder().encode(s)) bin += String.fromCharCode(x);
  return btoa(bin);
};

export function explain(e) {
  if (e.status === 401) return '열쇠가 맞지 않아요(만료됐거나 잘못 붙여 넣었어요)';
  if (e.status === 403) return '열쇠에 쓰기 권한이 없어요(Contents: Read and write)';
  if (e.status === 404) return '저장소를 못 찾았어요(이름 또는 열쇠의 저장소 선택 확인)';
  return '보내지 못했어요 · 인터넷 연결을 확인해 주세요';
}

// 연결 확인 = 이 폰 이름표(devices/<모델>.json)를 써 본다 — 열쇠·저장소·쓰기 권한을 한 번에 확인
export async function testInbox(conf) {
  const path = `contents/devices/${deviceName()}.json`;
  let sha;
  try {
    sha = (await gh(conf, 'GET', path)).sha;
  } catch (e) {
    if (e.status !== 404) throw e;
  }
  const body = JSON.stringify({ device: deviceName(), app: bridge.version(), checkedAt: new Date().toISOString() }, null, 1);
  await gh(conf, 'PUT', path, { message: `연결 확인 ${deviceName()}`, content: b64(body), ...(sha ? { sha } : {}) });
}

// 아직 안 보낸 제보를 한 파일로 올리고 보냄 표시
export async function sendPending() {
  const conf = inboxConf();
  if (!conf) return { sent: 0, skipped: true };
  const [notes, books] = await Promise.all([db.all('notes'), db.all('books')]);
  const reps = notes.filter((n) => n.type === 'report' && !n.sentAt);
  if (!reps.length) return { sent: 0 };
  const bm = new Map(books.map((b) => [b.id, b]));
  const now = new Date();
  const stamp = now.toISOString().replace(/[-:]/g, '').replace(/\..+/, '').replace('T', '-');
  const name = `inbox/${stamp}-${deviceName()}-${Math.random().toString(36).slice(2, 6)}.json`;
  const items = reps.map((n) => {
    const b = bm.get(n.bookId);
    return {
      id: n.id,
      vol: b ? volName(b) : n.vol || '',
      series: b?.series || null,
      index: b?.seriesIndex ?? null,
      chap: n.chap || '',
      sentence: n.ctx?.sent || n.text,
      picked: n.text,
      prev: n.ctx?.prev || '',
      next: n.ctx?.next || '',
      note: n.note || '',
      at: new Date(n.at).toISOString(),
      pos: n.a,
    };
  });
  const doc = { device: deviceName(), sentAt: now.toISOString(), count: items.length, text: reportText(reps, bm), items };
  await gh(conf, 'PUT', `contents/${name}`, { message: `제보 ${items.length}건 (${deviceName()})`, content: b64(JSON.stringify(doc, null, 1)) });
  for (const n of reps) {
    n.sentAt = now.getTime();
    await db.put('notes', n);
  }
  return { sent: reps.length, ids: reps.map((n) => n.id), at: now.getTime() };
}

async function ghRaw(conf, path) {
  const r = await fetch(`${API}/repos/${conf.repo}/${path}`, {
    headers: { Authorization: `Bearer ${conf.token}`, Accept: 'application/vnd.github.raw', 'X-GitHub-Api-Version': '2022-11-28' },
    cache: 'no-store',
  });
  if (!r.ok) {
    const e = new Error(`${r.status}`);
    e.status = r.status;
    throw e;
  }
  return r;
}

const stampOf = (d) => d.toISOString().replace(/[-:]/g, '').replace(/\..+/, '').replace('T', '-');

// 결과 쪽지 받기 — 번역기가 replies/ 에 남긴 쪽지(고침·그대로 둠·질문)를 news 에 담는다. 받은 파일 이름은 폰마다 기억.
const SEEN_KEY = 'ebook.replies.seen';
export async function fetchReplies() {
  const conf = inboxConf();
  if (!conf) return { added: 0, questions: 0 };
  let list;
  try {
    list = await gh(conf, 'GET', 'contents/replies');
  } catch (e) {
    if (e.status === 404) return { added: 0, questions: 0 };
    throw e;
  }
  let seen;
  try { seen = new Set(JSON.parse(localStorage.getItem(SEEN_KEY) || '[]')); } catch { seen = new Set(); }
  const fresh = list.filter((f) => f.type === 'file' && f.name.endsWith('.json') && !seen.has(f.name)).sort((a, b) => a.name.localeCompare(b.name));
  let added = 0;
  let questions = 0;
  for (const f of fresh) {
    const doc = await (await ghRaw(conf, `contents/${f.path}`)).json();
    for (const it of doc.items || []) {
      if (!it.id) continue;
      const old = await db.get('news', it.id);
      await db.put('news', { ...it, file: f.name, at: doc.at || new Date().toISOString(), read: old?.read || false, answered: old?.answered || null });
      added++;
      if (it.status === 'question' && !old?.answered) questions++;
    }
    seen.add(f.name);
  }
  localStorage.setItem(SEEN_KEY, JSON.stringify([...seen].slice(-500)));
  return { added, questions };
}

// 질문에 답하기 — answers/ 에 올리면 PC 지키미가 번역기 세션을 깨운다
export async function sendAnswer(item, choice, text) {
  const conf = inboxConf();
  if (!conf) throw Object.assign(new Error('no-inbox'), { status: 0 });
  const now = new Date();
  const doc = {
    device: deviceName(),
    at: now.toISOString(),
    items: [{ reply: item.id, report: item.report || null, vol: item.vol, chap: item.chap || '', question: item.question || '', choice: choice || null, text: text || '' }],
  };
  const name = `answers/${stampOf(now)}-${deviceName()}-${Math.random().toString(36).slice(2, 6)}.json`;
  await gh(conf, 'PUT', `contents/${name}`, { message: `질문에 답 (${deviceName()})`, content: b64(JSON.stringify(doc, null, 1)) });
  item.answered = { choice: choice || null, text: text || '', at: now.getTime() };
  item.read = true;
  await db.put('news', item);
}

// 고친 권 받기 — books/index.json 과 내 서재를 견줘 «내용이 바뀐 권»과 새 권만 받아 넣는다(새 판으로 바꿔 끼움)
//   견주는 값 = 내용 해시(수정 시각은 뺀 것 · push_books.py 가 계산) → 같은 판을 다시 받지 않는다
export async function fetchBookUpdates() {
  const conf = inboxConf();
  if (!conf) return null;
  let idx;
  try {
    idx = await (await ghRaw(conf, 'contents/books/index.json?ref=books')).json();
  } catch (e) {
    if (e.status === 404) return { none: true };
    throw e;
  }
  const local = await db.all('books');
  const byId = new Map(local.map((b) => [b.id, b]));
  const want = (idx.books || []).filter((e) => {
    const b = e.series && e.index != null ? byId.get(`s:${e.series}|${e.index}`) : local.find((x) => x.fileName === e.file);
    return !b || b.chash !== e.hash;
  });
  if (!want.length) return { added: [], replaced: [], same: [], failed: [] };
  const files = [];
  const meta = {};
  for (const e of want) {
    const blob = await (await ghRaw(conf, `contents/${e.path}?ref=books`)).blob();
    files.push(new File([blob], e.file, { type: 'application/epub+zip' }));
    meta[e.file] = { chash: e.hash };
  }
  return importFiles(files, null, meta);
}
