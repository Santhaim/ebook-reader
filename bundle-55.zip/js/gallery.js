// 그림 모아보기(화면 판 53 · 11-27 사용자 «추천 방향으로»): 묶음마다 부 표지·인물 그림
//   묶음 화면 «그림»(부 표지 줄 + 인물 그림판) · 인물을 누르면 카드(소개·나오는 권·다른 모습) · 읽는 중 위 막대 «이 권의 인물»
//   자료 = 우편함 gallery 가지(권의 books 가지와 따로 · tools/push_gallery.py):
//     gallery/index.json → 묶음 이름 → 묶음 꾸러미(<해시>.json: parts·people·cast) → 그림(img/<해시>.webp)
//   받은 꾸러미·그림은 이름(내용 해시)으로 따로 담아 둔다(ebook-gallery DB) — 같은 것을 다시 안 받고, 인터넷이 없어도 한 번 본 것은 보인다
//   🔴 앱 코드라 책 이름을 쓰지 않는다 — 묶음 이름은 우편함 목록에서만 온다
import { inboxConf, mailRaw } from './reports.js';
import { $$, esc, sheet } from './ui.js';
import { openZoom } from './zoom.js';

const REF = '?ref=gallery';
const IDX_KEY = 'ebook.gallery.idx';   // 마지막으로 받은 목록(인터넷이 없을 때)

// 꾸러미·그림 담기 — 서재 DB(ebook)와 따로(판 번호를 안 올려 옛 화면 판이 떠도 서재 DB 는 그대로)
const store = (() => {
  let opening = null;
  const open = () => (opening ||= new Promise((resolve, reject) => {
    const r = indexedDB.open('ebook-gallery', 1);
    r.onupgradeneeded = () => r.result.createObjectStore('files');
    r.onsuccess = () => resolve(r.result);
    r.onerror = () => reject(r.error);
  }));
  const run = async (mode, fn) => {
    const req = fn((await open()).transaction('files', mode).objectStore('files'));
    return new Promise((resolve, reject) => { req.onsuccess = () => resolve(req.result); req.onerror = () => reject(req.error); });
  };
  return {
    get: (k) => run('readonly', (s) => s.get(k)).catch(() => null),
    put: (k, v) => run('readwrite', (s) => s.put(v, k)).catch(() => {}),
  };
})();

// ---------- 목록·꾸러미 ----------
let idx = null;
let idxAt = 0;
let idxP = null;
function cachedIdx() {
  try { return JSON.parse(localStorage.getItem(IDX_KEY) || 'null'); } catch { return null; }
}
// 목록은 1분에 한 번만 다시 본다(묶음 화면을 오갈 때마다 받지 않게)
function loadIndex() {
  if (!inboxConf()) return Promise.resolve(null);
  if (idx && Date.now() - idxAt < 60e3) return Promise.resolve(idx);
  idxP ||= (async () => {
    try {
      idx = await (await mailRaw(`contents/gallery/index.json${REF}`, 20e3)).json();
      idxAt = Date.now();
      try { localStorage.setItem(IDX_KEY, JSON.stringify(idx)); } catch { /* 저장 못 해도 이번엔 씀 */ }
    } catch (e) {
      if (e.status === 404) { idx = { series: {} }; idxAt = Date.now(); }   // 그림 가지가 아직 없음
      else idx ||= cachedIdx();                                          // 인터넷이 없으면 마지막 목록
    }
    return idx;
  })().finally(() => { idxP = null; });
  return idxP;
}

const docs = new Map();   // 묶음 이름 → 꾸러미
export const peekGallery = (series) => docs.get(series) || null;

// 묶음의 꾸러미(없으면 null) — 꾸러미 파일 이름이 그대로면 담아 둔 것을 쓴다
export async function seriesGallery(series) {
  if (!series) return null;
  const ix = await loadIndex();
  const ent = ix?.series?.[series];
  if (!ent) { if (ix) docs.delete(series); return docs.get(series) || null; }
  const cur = docs.get(series);
  if (cur?._doc === ent.doc) return cur;
  let text = await store.get(ent.doc);
  if (!text) {
    text = await (await mailRaw(`contents/gallery/${ent.doc}${REF}`, 30e3)).text();
    await store.put(ent.doc, text);
  }
  const doc = JSON.parse(text);
  doc._doc = ent.doc;
  docs.set(series, doc);
  return doc;
}

// ---------- 그림 ----------
const urls = new Map();
const pending = new Map();
function imgUrl(rel) {
  if (urls.has(rel)) return Promise.resolve(urls.get(rel));
  if (!pending.has(rel)) {
    pending.set(rel, (async () => {
      let blob = await store.get(rel);
      if (!blob) {
        const b = await (await mailRaw(`contents/gallery/${rel}${REF}`, 60e3)).blob();
        blob = new Blob([b], { type: 'image/webp' });
        await store.put(rel, blob);
      }
      const u = URL.createObjectURL(blob);
      urls.set(rel, u);
      return u;
    })().finally(() => pending.delete(rel)));
  }
  return pending.get(rel);
}
// 이미 받은 그림은 처음부터 src 를 넣어 그린다(빈 칸이 한 번 비치지 않게) · 나머지는 4장씩 받아 채운다(위에서부터)
const imgTag = (rel, cls = '') => `<img class="${cls}" data-g="${esc(rel)}"${urls.has(rel) ? ` src="${urls.get(rel)}"` : ''} alt="">`;
function fillImgs(root) {
  const list = $$('img[data-g]', root).filter((im) => !im.getAttribute('src'));
  let i = 0;
  const next = async () => {
    while (i < list.length) {
      const im = list[i++];
      try { im.src = await imgUrl(im.dataset.g); } catch { im.classList.add('miss'); }
    }
  };
  for (let k = 0; k < 4; k++) next();
}

// ---------- 그리기 ----------
const span = (a, b) => (!a ? '' : !b || a === b ? `${a}권` : `${a}~${b}권`);
const partName = (p) => (p.n ? `${p.n}부` : '외전');
// 같은 이름이 여러 모습이면(한 사람의 시기별 그림) 칸 밑에 권 범위를 단다
const dupNames = (people) => {
  const n = new Map();
  for (const p of people) n.set(p.name, (n.get(p.name) || 0) + 1);
  return new Set([...n].filter(([, c]) => c > 1).map(([k]) => k));
};

// ---------- 스포일러 가리기(화면 판 54 · 11-27 사용자 «그림 탭에 스포일러성 정보가 좀 있어») ----------
//   켜면(처음 값) 그 묶음에서 읽은 데까지(읽은 자리가 있는 권 중 가장 뒤 · 읽는 중이면 그 권까지) 나온 인물·모습·부 표지만 보인다
//   — 더 뒤 권에서 처음 나오는 사람·모습(예: 같은 사람의 뒷날 모습)은 «N명 · M권부터»로만 · 나오는 권 칩·권 범위도 읽은 데까지
const GUARD_KEY = 'ebook.gallery.guard';
export function guardOn() {
  try { return localStorage.getItem(GUARD_KEY) !== '0'; } catch { return true; }
}
function setGuard(on) {
  try { localStorage.setItem(GUARD_KEY, on ? '1' : '0'); } catch { /* 이번만 */ }
}
const limitOf = (ctx) => (guardOn() ? Math.max(1, ctx.reached || 0) : Infinity);
const spanUpTo = (p, lim) => (p.to && p.to > lim ? `${p.from}권부터` : span(p.from, p.to));
// 보이는 이름 = 긴 이름(성까지 붙은 풀네임) · 없으면 부르는 이름(화면 판 55 · 11-27 사용자 «풀네임이 나오면 좋을 듯») — 모습 묶기는 그대로 p.name
const shown = (p) => p.full || p.name;
const capOf = (p, lim) => [shown(p), p.form, spanUpTo(p, lim)].filter(Boolean).join(' · ');

function faceTile(p, dup, lim) {
  return `<button class="g-face" data-id="${esc(p.id)}">${imgTag(p.img)}<b>${esc(shown(p))}</b>${dup.has(p.name) ? `<span>${spanUpTo(p, lim)}</span>` : ''}</button>`;
}

// 크게 보기 여러 장(옆으로 넘기기) — 인물은 이름도
function zoomPeople(people, id, lim) {
  const i = Math.max(0, people.findIndex((p) => p.id === id));
  openZoom(null, { items: people.map((p) => ({ get: () => imgUrl(p.img), caption: capOf(p, lim) })), index: i });
}

// 묶음 화면 «그림» — ctx = { volId(권 번호) → 폰에 있는 권 id | null, openBook(id), reached(읽은 데까지 권), onLeave? }
export function renderGallery(el, doc, ctx) {
  const lim = limitOf(ctx);
  const parts = (doc.parts || []).filter((p) => (p.from || 1) <= lim);
  const people = doc.people.filter((p) => (p.from || 1) <= lim);
  const hidParts = (doc.parts || []).length - parts.length;
  const hidPeople = doc.people.length - people.length;
  const later = Math.min(...doc.people.filter((p) => (p.from || 1) > lim).map((p) => p.from));
  const dup = dupNames(people);
  const on = guardOn();
  el.innerHTML = `<div class="g-lbl">${on ? `읽은 데까지(${lim}권) 나온 것만 보여요` : '모든 권의 그림을 보여요'}<button class="g-guard${on ? ' on' : ''}">${on ? '스포일러 가림' : '다 보임'}</button></div>
    ${parts.length || hidParts ? `<div class="g-lbl">부 표지 <em>${parts.length}</em>${hidParts ? `<span>뒤의 ${hidParts}부는 읽은 뒤에</span>` : ''}</div>
    <div class="g-strip">${parts.map((p, i) => `<button class="g-part" data-pi="${i}">${imgTag(p.img)}<b>${partName(p)}</b><span>${esc(p.name || spanUpTo(p, lim))}</span></button>`).join('')}</div>` : ''}
    <div class="g-lbl">인물 <em>${people.length}</em><span>처음 나온 차례</span></div>
    <div class="g-grid">${people.map((p) => faceTile(p, dup, lim)).join('')}${hidPeople ? `<div class="g-hid"><b>${hidPeople}명</b><span>${later}권부터 나와요</span></div>` : ''}</div>`;
  fillImgs(el);
  el.onclick = (e) => {
    if (e.target.closest('.g-guard')) { setGuard(!on); renderGallery(el, doc, ctx); return; }
    const pt = e.target.closest('.g-part');
    if (pt) { openParts(parts, +pt.dataset.pi, ctx, lim); return; }
    const f = e.target.closest('.g-face');
    if (f) openPerson(doc, f.dataset.id, ctx);
  };
}

// 부 표지 = 크게 보기(옆으로 = 다른 부) + 그 장의 «N권부터 읽기»(그 권이 폰에 있을 때)
function openParts(parts, i, ctx, lim) {
  openZoom(null, {
    index: i,
    items: parts.map((p) => {
      const id = ctx.volId(p.from);
      return {
        get: () => imgUrl(p.img),
        caption: [partName(p), p.name, spanUpTo(p, lim)].filter(Boolean).join(' · '),
        action: id ? { label: `${partName(p)} · ${p.from}권부터 읽기`, fn: () => { ctx.onLeave?.(); ctx.openBook(id); } } : null,
      };
    }),
  });
}
// 묶음 위 큰 표지를 눌렀을 때도 부 표지끼리 넘기게(그림 꾸러미가 있을 때 · library.js) — n = 지금 부(0 = 첫 부)
export function zoomPartsAt(doc, n, ctx) {
  const lim = limitOf(ctx);
  const parts = (doc.parts || []).filter((p) => (p.from || 1) <= lim);
  if (!parts.length) return false;
  openParts(parts, Math.max(0, parts.findIndex((p) => p.n === n)), ctx, lim);
  return true;
}

// 인물 카드 — 그림(누르면 크게 · 옆으로 = 다른 인물) · 긴 이름·모습 · 소개 · 나오는 권(누르면 그 권) · 다른 모습
export function openPerson(doc, id, ctx) {
  const lim = limitOf(ctx);
  const seen = doc.people.filter((p) => (p.from || 1) <= lim || p.id === id);
  let cur = doc.people.find((x) => x.id === id);
  if (!cur) return;
  const s = sheet({ title: shown(cur), cls: 'g-card' });
  const draw = () => {
    const q = cur;
    const others = seen.filter((x) => x.name === q.name && x.id !== q.id);
    const vols = (q.vols || []).filter((v) => v <= lim);
    const more = (q.vols || []).length - vols.length;
    s.el.querySelector('.sheet-head b').textContent = shown(q);
    s.body.innerHTML = `<div class="gc-top"><button class="gc-face" aria-label="그림 크게 보기">${imgTag(q.img)}</button>
      <div class="gc-who">${q.form ? `<div class="gc-form">${esc(q.form)}</div>` : ''}
        <div class="gc-span">${spanUpTo(q, lim)}</div></div></div>
      ${q.role ? `<p class="gc-role">${esc(q.role)}</p>` : ''}
      ${vols.length ? `<div class="g-lbl">나오는 권 <em>${vols.length}</em>${more ? '<span>읽은 데까지</span>' : ''}</div><div class="gc-vols">${vols.map((v) => {
        const has = !!ctx.volId(v);
        return `<button class="gc-v${has ? '' : ' off'}" data-v="${v}"${has ? '' : ' disabled'}>${v}</button>`;
      }).join('')}${more ? `<span class="gc-more">뒤로 ${more}권 더</span>` : ''}</div>` : ''}
      ${others.length ? `<div class="g-lbl">다른 모습</div><div class="gc-others">${others.map((o) => `<button class="gc-o" data-id="${esc(o.id)}">${imgTag(o.img)}<span>${spanUpTo(o, lim)}</span></button>`).join('')}</div>` : ''}`;
    s.body.scrollTop = 0;
    fillImgs(s.body);
  };
  draw();
  s.body.onclick = (e) => {
    const v = e.target.closest('.gc-v');
    if (v) {
      const vid = ctx.volId(+v.dataset.v);
      if (vid) { s.close(); ctx.onLeave?.(); ctx.openBook(vid); }
      return;
    }
    const o = e.target.closest('.gc-o');
    if (o) { cur = doc.people.find((x) => x.id === o.dataset.id) || cur; draw(); return; }
    if (e.target.closest('.gc-face')) zoomPeople(seen, cur.id, lim);
  };
}

// 읽는 중 «이 권의 인물» — 권 끝 «이 권의 인물» 쪽과 같은 사람들 · 맨 밑 «모든 그림 보기» = 묶음 «그림»과 같은 판(시트로)
export function castOf(doc, vol) {
  return (doc?.cast?.[String(vol)] || []).map((id) => doc.people.find((p) => p.id === id)).filter(Boolean);
}
export function openCast(doc, vol, ctx) {
  const list = castOf(doc, vol);
  const lim = limitOf(ctx);
  const dup = dupNames(list);
  const s = sheet({ title: `이 권의 인물 · ${vol}권`, cls: 'g-castsheet' });
  s.body.innerHTML = `<div class="g-grid g-cast">${list.map((p) => faceTile(p, dup, lim)).join('')}</div>
    <button class="btn ghost g-all">모든 그림 보기</button>`;
  fillImgs(s.body);
  const leave = { ...ctx, onLeave: () => { s.close(); ctx.onLeave?.(); } };
  s.body.onclick = (e) => {
    const f = e.target.closest('.g-face');
    if (f) { openPerson(doc, f.dataset.id, leave); return; }
    if (e.target.closest('.g-all')) {
      const all = sheet({ title: '그림', cls: 'tall g-allsheet' });
      renderGallery(all.body, doc, { ...leave, onLeave: () => { all.close(); leave.onLeave(); } });
    }
  };
}
