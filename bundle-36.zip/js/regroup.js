// 권을 다시 묶을 때(예: «25장 = 1권» → «30장 = 1권») 읽던 자리·다 읽음·형광펜·메모·책갈피·제보를 «같은 장»으로 옮긴다.
//   앱은 권을 «묶음+권 번호»로 알아봐서, 다시 묶으면 같은 번호에 다른 장이 들어온다 → 옛 자리를 그대로 두면 엉뚱한 장이 열린다(스포일러).
//   장 열쇠 = 부 + 장 번호(«제N장» — 제목을 고쳐도 같다) · 장 아닌 이름(부 제목·총결)은 부 + 이름
//     장 번호를 부마다 1부터 다시 매긴 권(10-31 독자 «부가 바뀔 때마다 1장부터» · 원문은 책 전체로 이어 셈)은 목차의 원래 번호(data-n · book.nums)로
//     — 옛 판 «제1747장»과 새 판 «제1장»이 같은 열쇠(그냥 보이는 번호로 하면 옛 3부 180장이 새 3부 180장 = 다른 권으로 간다)
//     이름 없는 쪽: 맨 앞(표지·소개)은 «다음 장의 몇째 앞» · 장 뒤에 이어진 쪽은 «앞 장의 몇째 뒤» — 새 판에 없으면 가까운 쪽·그 장 첫머리로
//   고친 권을 넣기 «전»에 바뀔 권·없어질 권의 상태를 장 열쇠로 적어 두고(localStorage — 넣다가 앱이 꺼져도 다음에 이어서),
//   넣은 «뒤»에 지금 서재의 권 자리로 풀어 쓴다. 다시 묶지 않은 보통 새 판도 같은 길로 간다(같은 장 → 같은 자리).
//   없어질 권은 그 장들이 다른 권에 다 있고 못 옮긴 메모·자리가 없을 때만 지운다(덜 보낸 목록이 와도 잃는 게 없게).
import { readEpub } from './epub.js';
import { db } from './db.js';

const PENDING = 'ebook.moves.v1';
const flat = (s) => String(s || '').replace(/\s+/g, '');
export const partOf = (b) => +((b?.subtitle || '').match(/(\d+)\s*부/) || [])[1] || 0;

// spine 마다 «그 쪽의» 장 이름(목차 · 목차가 없는 책은 첫 제목) — 없으면 ''
export async function spineLabels(ep) {
  if (ep.toc.length) return ep.spine.map((_, s) => ep.toc.find((t) => t.s === s)?.label || '');
  const out = [];
  const d = document.createElement('div');
  for (let s = 0; s < ep.spine.length; s++) {
    d.innerHTML = (await ep.chapter(s)).html;
    out.push(d.querySelector('h1,h2,h3')?.textContent.trim() || '');
  }
  return out;
}

// spine 마다 «그 쪽의» 원래 장 번호(목차 data-n) — 다시 매긴 번호가 없는 책은 null
export function spineNums(ep) {
  if (!ep.toc.some((t) => t.n)) return null;
  return ep.spine.map((_, s) => ep.toc.find((t) => t.s === s)?.n || null);
}

async function labelsOf(book) {
  if (Array.isArray(book.labels)) return { labels: book.labels, nums: book.nums };
  const file = await db.get('files', book.id);
  if (!file) return null;
  const ep = await readEpub(await file.arrayBuffer());
  return { labels: await spineLabels(ep), nums: spineNums(ep) };
}

// spine 마다 장 열쇠 · nums = 원래 장 번호(있으면 보이는 번호 대신)
export function sectionKeys(part, labels, nums) {
  const own = labels.map((l, i) => {
    const t = flat(l);
    if (!t) return null;
    const n = nums?.[i] || (t.match(/^제(\d+)장/) || [])[1];
    return `${part}|${n ? `${+n}장` : t}`;
  });
  const seen = new Map();
  const keys = [];
  let prev = null;
  let k = 0;
  own.forEach((x, i) => {
    if (x) {
      const n = seen.get(x) || 0;
      seen.set(x, n + 1);
      prev = n ? `${x}@${n}` : x;
      k = 0;
      keys.push(prev);
    } else if (prev) keys.push(`${prev}#${++k}`);
    else {
      const j = own.findIndex((y, n) => n > i && y);
      keys.push(j < 0 ? `${part}|빈${i}` : `${own[j]}<${j - i}`);
    }
  });
  return keys;
}

// 이름 없는 쪽의 열쇠(새 판에 없을 수 있다 — 표지를 빼고 만든 판 등)
const soft = (key) => /[<#]\d+$|\|빈\d+$/.test(key);

function load() {
  try { return JSON.parse(localStorage.getItem(PENDING) || 'null'); } catch { return null; }
}
export const hasPendingMoves = () => !!load();

const clampS = (s, n) => Math.min(Math.max(0, s | 0), n - 1);
// 그 쪽의 장 이름(이름 없는 쪽이면 앞 장 · 읽기 화면 R.label 과 같게) — 읽던 자리·메모 목록에 보이는 «제N장 …»
const labelAt = (b, s) => { for (let i = s; i >= 0; i--) if (b?.labels?.[i]) return b.labels[i]; return ''; };

// 바뀔 권(old)·없어질 권(gone)의 지금 상태를 장 열쇠로 적어 둔다 · into = 이번에 들어올 권 id(새 권 포함)
//   이미 적어 둔 권(앞서 하다 끊긴 것)은 다시 적지 않는다 — 그 사이 일부가 새 판으로 바뀌었어도 옛 판 기준 그대로
export async function noteMoves(old, gone, into) {
  const m = load() || { ids: [], gone: [], into: [], keys: {}, read: {}, cur: [], notes: [] };
  for (const id of into) if (!m.into.includes(id)) m.into.push(id);
  const goneIds = new Set(gone.map((b) => b.id));
  for (const b of [...old, ...gone]) {
    if (m.ids.includes(b.id)) continue;
    m.ids.push(b.id);
    if (goneIds.has(b.id)) m.gone.push(b.id);
    const [p, notes] = await Promise.all([db.get('progress', b.id), db.notesOf(b.id)]);
    const info = (p && (p.done || p.pos)) || notes.length ? await labelsOf(b) : null;
    if (!info?.labels?.length) { m.keys[b.id] = null; continue; }   // 남길 게 없거나 파일이 없는 권
    const keys = sectionKeys(partOf(b), info.labels, info.nums);
    m.keys[b.id] = keys;
    const read = (k) => { m.read[k] = Math.max(m.read[k] || 0, p.at || 1); };
    if (p?.done) keys.forEach(read);
    else if (p?.pos) {
      const s = clampS(p.pos.s, keys.length);
      keys.slice(0, s).forEach(read);
      m.cur.push({ from: b.id, s0: s, key: keys[s], b: p.pos.toc ? 0 : p.pos.b || 0, o: p.pos.toc ? 0 : p.pos.o || 0, at: p.at || 1, pct: p.pct || 0 });
    }
    const at = (x) => x && { key: keys[clampS(x.s, keys.length)], b: x.b || 0, o: x.o || 0 };
    for (const n of notes) m.notes.push({ id: n.id, from: b.id, a: at(n.a), z: at(n.b) });
  }
  localStorage.setItem(PENDING, JSON.stringify(m));
}

// 적어 둔 상태를 지금 서재의 권 자리로 풀어 쓴다 → { moved: 옮긴 메모 수, removed: 지운 권 id }
export async function applyMoves() {
  const m = load();
  if (!m) return null;
  const byId = new Map((await db.all('books')).map((b) => [b.id, b]));
  // 권의 장 열쇠: 이번에 넣은 권은 책 정보의 labels(지금 파일 기준) · 못 바꾼 옛 권은 적어 둔 열쇠
  const keysOf = (b) => (Array.isArray(b.labels) ? sectionKeys(partOf(b), b.labels, b.nums) : m.keys[b.id] || null);
  const gone = new Set(m.gone);
  const targets = [...new Set([...m.into, ...m.ids])].map((id) => byId.get(id)).filter(Boolean);
  const table = (list) => {
    const t = new Map();
    for (const b of list) (keysOf(b) || []).forEach((k, s) => { if (!t.has(k)) t.set(k, { id: b.id, s }); });
    return t;
  };
  const stay = table(targets.filter((b) => !gone.has(b.id)));
  const find = (x, map) => {
    if (!x?.key) return null;
    let hit = map.get(x.key);
    if (hit) return { ...hit, b: x.b, o: x.o };
    const lead = x.key.match(/^(.*)<(\d+)$/);
    for (let d = lead ? +lead[2] - 1 : 0; lead && d > 0; d--) if ((hit = map.get(`${lead[1]}<${d}`))) return { ...hit, b: 0, o: 0 };
    hit = soft(x.key) && map.get(x.key.replace(/[<#]\d+$/, ''));
    return hit ? { ...hit, b: 0, o: 0 } : null;
  };
  // 없어질 권: 이름 있는 장이 다 남는 권에 있고, 못 옮긴 메모·읽던 자리가 없으면 지운다 · 아니면 그대로 둔다
  const stuck = new Set([...m.notes, ...m.cur].filter((x) => gone.has(x.from) && !find(x.a || x, stay)).map((x) => x.from));
  const drop = new Set([...gone].filter((id) => byId.has(id) && !stuck.has(id) && (m.keys[id] || []).every((k) => soft(k) || stay.has(k))));
  const keep = targets.filter((b) => !drop.has(b.id));
  const all = new Map([...table(keep), ...stay]);   // 남는 권 먼저(같은 장이 둘이면 새 권으로)

  // 읽은 정도: 옛 판에서 다 읽은 장·읽던 자리를 권마다 다시 센다
  const known = new Set(Object.values(m.keys).flat().filter(Boolean));
  const cur = m.cur.map((c) => ({ ...c, to: find(c, all) })).filter((c) => c.to);
  for (const b of keep) {
    const keys = keysOf(b);
    if (!keys) continue;
    let need = 0;
    let got = 0;
    let last = 0;
    let first = -1;
    keys.forEach((k, s) => {
      if (soft(k) && !known.has(k)) return;   // 새 판에만 있는 이름 없는 쪽(표지 등)은 셈에서 뺀다
      need++;
      if (k in m.read) { got++; last = Math.max(last, m.read[k]); } else if (first < 0) first = s;
    });
    const c = cur.filter((x) => x.to.id === b.id).sort((x, y) => y.at - x.at)[0];
    const label = (s) => labelAt(b, s);
    const near = (s) => Math.round((1000 * s) / keys.length) / 10;   // 장 수로 어림한 % — 책을 열면 글자 수로 다시 센다
    let p = null;
    if (c) {
      const same = c.from === b.id && c.s0 === c.to.s;
      p = { id: b.id, pos: { s: c.to.s, b: c.to.b, o: c.to.o }, pct: same ? c.pct : near(c.to.s), done: false, at: c.at, chap: label(c.to.s) };
    } else if (need && got === need) p = { id: b.id, pos: { s: keys.length - 1, b: 0, o: 0, end: 1 }, pct: 100, done: true, at: last, chap: label(keys.length - 1) };   // 다 읽은 권 = 마지막 쪽(end · 읽기 화면이 맨 끝 쪽으로 연다 — 마지막 장 첫머리면 장 하나만큼 앞이었다 10-31)
    else if (got) p = { id: b.id, pos: { s: first, b: 0, o: 0 }, pct: near(first), done: false, at: last, chap: label(first) };
    if (p) await db.put('progress', p);
    else await db.del('progress', b.id);
  }

  // 형광펜·메모·책갈피·제보 — 같은 장 같은 문단·글자 자리로(끝이 다른 권으로 갔으면 시작 장 안에서 같은 길이)
  let moved = 0;
  for (const x of m.notes) {
    const n = await db.get('notes', x.id);
    const a = n && find(x.a, all);
    if (!a) continue;
    let z = x.z && find(x.z, all);
    if (x.z && (!z || z.id !== a.id)) z = { ...a, o: a.o + (n.text || '').length };
    if (n.bookId !== a.id || n.a?.s !== a.s) moved++;
    n.bookId = a.id;
    n.a = { s: a.s, b: a.b, o: a.o };
    if (n.b && z) n.b = { s: z.s, b: z.b, o: z.o };
    const lab = labelAt(byId.get(a.id), a.s);
    if (lab) n.chap = lab;   // 장 번호를 다시 매긴 권이면 메모 목록의 «제N장»도 새 번호로(10-31)
    await db.put('notes', n);
  }
  for (const id of drop) await db.removeBook(id);
  localStorage.removeItem(PENDING);
  return { moved, removed: [...drop] };
}
